# WordPress MySQL database migration
#
# Generated: Monday 24. April 2023 15:15 UTC
# Hostname: localhost
# Database: `labb2-carolina`
# URL: //localhost/labb2-carolina
# Path: C:\\MAMP\\htdocs\\labb2-carolina
# Tables: wp_actionscheduler_actions, wp_actionscheduler_claims, wp_actionscheduler_groups, wp_actionscheduler_logs, wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users, wp_wc_admin_note_actions, wp_wc_admin_notes, wp_wc_category_lookup, wp_wc_customer_lookup, wp_wc_download_log, wp_wc_order_coupon_lookup, wp_wc_order_product_lookup, wp_wc_order_stats, wp_wc_order_tax_lookup, wp_wc_product_attributes_lookup, wp_wc_product_download_directories, wp_wc_product_meta_lookup, wp_wc_rate_limits, wp_wc_reserved_stock, wp_wc_tax_rate_classes, wp_wc_webhooks, wp_woocommerce_api_keys, wp_woocommerce_attribute_taxonomies, wp_woocommerce_downloadable_product_permissions, wp_woocommerce_log, wp_woocommerce_order_itemmeta, wp_woocommerce_order_items, wp_woocommerce_payment_tokenmeta, wp_woocommerce_payment_tokens, wp_woocommerce_sessions, wp_woocommerce_shipping_zone_locations, wp_woocommerce_shipping_zone_methods, wp_woocommerce_shipping_zones, wp_woocommerce_tax_rate_locations, wp_woocommerce_tax_rates
# Table Prefix: wp_
# Post Types: revision, attachment, nav_menu_item, page, post, product, product_variation
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_actionscheduler_actions`
#

DROP TABLE IF EXISTS `wp_actionscheduler_actions`;


#
# Table structure of table `wp_actionscheduler_actions`
#

CREATE TABLE `wp_actionscheduler_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `scheduled_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  `args` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schedule` longtext COLLATE utf8mb4_unicode_520_ci,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `attempts` int(11) NOT NULL DEFAULT '0',
  `last_attempt_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `extended_args` varchar(8000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `hook` (`hook`),
  KEY `status` (`status`),
  KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  KEY `args` (`args`),
  KEY `group_id` (`group_id`),
  KEY `last_attempt_gmt` (`last_attempt_gmt`),
  KEY `claim_id_status_scheduled_date_gmt` (`claim_id`,`status`,`scheduled_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_actions`
#
INSERT INTO `wp_actionscheduler_actions` ( `action_id`, `hook`, `status`, `scheduled_date_gmt`, `scheduled_date_local`, `args`, `schedule`, `group_id`, `attempts`, `last_attempt_gmt`, `last_attempt_local`, `claim_id`, `extended_args`) VALUES
(6, 'action_scheduler/migration_hook', 'complete', '2023-04-19 07:41:05', '2023-04-19 09:41:05', '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681890065;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681890065;s:19:"scheduled_timestamp";i:1681890065;s:9:"timestamp";i:1681890065;}', 1, 1, '2023-04-19 07:41:11', '2023-04-19 09:41:11', 0, NULL),
(7, 'woocommerce_cleanup_draft_orders', 'complete', '2023-04-19 07:40:07', '2023-04-19 09:40:07', '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1681890007;s:18:"\0*\0first_timestamp";i:1681890007;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1681890007;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1681890007;s:15:"first_timestamp";i:1681890007;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1681890007;s:19:"interval_in_seconds";i:86400;}', 0, 1, '2023-04-19 07:41:11', '2023-04-19 09:41:11', 0, NULL),
(8, 'woocommerce_cleanup_draft_orders', 'complete', '2023-04-20 07:41:11', '2023-04-20 09:41:11', '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1681976471;s:18:"\0*\0first_timestamp";i:1681890007;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1681976471;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1681976471;s:15:"first_timestamp";i:1681890007;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1681976471;s:19:"interval_in_seconds";i:86400;}', 0, 1, '2023-04-20 09:22:13', '2023-04-20 11:22:13', 0, NULL),
(9, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 07:48:24', '2023-04-19 09:48:24', '[12,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681890504;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681890504;s:19:"scheduled_timestamp";i:1681890504;s:9:"timestamp";i:1681890504;}', 2, 1, '2023-04-19 07:49:28', '2023-04-19 09:49:28', 0, NULL),
(10, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 08:19:59', '2023-04-19 10:19:59', '[22,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681892399;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681892399;s:19:"scheduled_timestamp";i:1681892399;s:9:"timestamp";i:1681892399;}', 2, 1, '2023-04-19 08:20:03', '2023-04-19 10:20:03', 0, NULL),
(11, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 08:27:15', '2023-04-19 10:27:15', '[22,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681892835;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681892835;s:19:"scheduled_timestamp";i:1681892835;s:9:"timestamp";i:1681892835;}', 2, 1, '2023-04-19 08:28:14', '2023-04-19 10:28:14', 0, NULL),
(12, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 08:29:51', '2023-04-19 10:29:51', '[22,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681892991;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681892991;s:19:"scheduled_timestamp";i:1681892991;s:9:"timestamp";i:1681892991;}', 2, 1, '2023-04-19 08:30:03', '2023-04-19 10:30:03', 0, NULL),
(13, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 08:32:58', '2023-04-19 10:32:58', '[22,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681893178;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681893178;s:19:"scheduled_timestamp";i:1681893178;s:9:"timestamp";i:1681893178;}', 2, 1, '2023-04-19 08:33:02', '2023-04-19 10:33:02', 0, NULL),
(14, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 08:34:13', '2023-04-19 10:34:13', '[22,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681893253;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681893253;s:19:"scheduled_timestamp";i:1681893253;s:9:"timestamp";i:1681893253;}', 2, 1, '2023-04-19 08:34:16', '2023-04-19 10:34:16', 0, NULL),
(15, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 08:37:25', '2023-04-19 10:37:25', '[23,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681893445;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681893445;s:19:"scheduled_timestamp";i:1681893445;s:9:"timestamp";i:1681893445;}', 2, 1, '2023-04-19 08:38:39', '2023-04-19 10:38:39', 0, NULL),
(16, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 08:37:25', '2023-04-19 10:37:25', '[24,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681893445;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681893445;s:19:"scheduled_timestamp";i:1681893445;s:9:"timestamp";i:1681893445;}', 2, 1, '2023-04-19 08:38:39', '2023-04-19 10:38:39', 0, NULL),
(17, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 08:37:25', '2023-04-19 10:37:25', '[25,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681893445;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681893445;s:19:"scheduled_timestamp";i:1681893445;s:9:"timestamp";i:1681893445;}', 2, 1, '2023-04-19 08:38:39', '2023-04-19 10:38:39', 0, NULL),
(18, 'adjust_download_permissions', 'complete', '2023-04-19 08:37:25', '2023-04-19 10:37:25', '[22]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681893445;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681893445;s:19:"scheduled_timestamp";i:1681893445;s:9:"timestamp";i:1681893445;}', 0, 1, '2023-04-19 08:38:39', '2023-04-19 10:38:39', 0, NULL),
(19, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 08:37:25', '2023-04-19 10:37:25', '[22,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681893445;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681893445;s:19:"scheduled_timestamp";i:1681893445;s:9:"timestamp";i:1681893445;}', 2, 1, '2023-04-19 08:38:39', '2023-04-19 10:38:39', 0, NULL),
(20, 'adjust_download_permissions', 'complete', '2023-04-19 08:38:40', '2023-04-19 10:38:40', '[22]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681893520;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681893520;s:19:"scheduled_timestamp";i:1681893520;s:9:"timestamp";i:1681893520;}', 0, 1, '2023-04-19 08:38:40', '2023-04-19 10:38:40', 0, NULL),
(21, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 08:38:40', '2023-04-19 10:38:40', '[23,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681893520;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681893520;s:19:"scheduled_timestamp";i:1681893520;s:9:"timestamp";i:1681893520;}', 2, 1, '2023-04-19 08:38:40', '2023-04-19 10:38:40', 0, NULL),
(22, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 08:38:40', '2023-04-19 10:38:40', '[24,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681893520;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681893520;s:19:"scheduled_timestamp";i:1681893520;s:9:"timestamp";i:1681893520;}', 2, 1, '2023-04-19 08:38:40', '2023-04-19 10:38:40', 0, NULL),
(23, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 08:38:40', '2023-04-19 10:38:40', '[25,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681893520;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681893520;s:19:"scheduled_timestamp";i:1681893520;s:9:"timestamp";i:1681893520;}', 2, 1, '2023-04-19 08:38:40', '2023-04-19 10:38:40', 0, NULL),
(24, 'adjust_download_permissions', 'complete', '2023-04-19 08:40:43', '2023-04-19 10:40:43', '[22]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681893643;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681893643;s:19:"scheduled_timestamp";i:1681893643;s:9:"timestamp";i:1681893643;}', 0, 1, '2023-04-19 08:41:20', '2023-04-19 10:41:20', 0, NULL),
(25, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 08:40:43', '2023-04-19 10:40:43', '[23,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681893643;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681893643;s:19:"scheduled_timestamp";i:1681893643;s:9:"timestamp";i:1681893643;}', 2, 1, '2023-04-19 08:41:20', '2023-04-19 10:41:20', 0, NULL),
(26, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 08:40:43', '2023-04-19 10:40:43', '[24,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681893643;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681893643;s:19:"scheduled_timestamp";i:1681893643;s:9:"timestamp";i:1681893643;}', 2, 1, '2023-04-19 08:41:20', '2023-04-19 10:41:20', 0, NULL),
(27, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 08:40:43', '2023-04-19 10:40:43', '[25,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681893643;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681893643;s:19:"scheduled_timestamp";i:1681893643;s:9:"timestamp";i:1681893643;}', 2, 1, '2023-04-19 08:41:20', '2023-04-19 10:41:20', 0, NULL),
(28, 'adjust_download_permissions', 'complete', '2023-04-19 08:41:21', '2023-04-19 10:41:21', '[22]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681893681;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681893681;s:19:"scheduled_timestamp";i:1681893681;s:9:"timestamp";i:1681893681;}', 0, 1, '2023-04-19 08:41:21', '2023-04-19 10:41:21', 0, NULL),
(29, 'adjust_download_permissions', 'complete', '2023-04-19 08:43:19', '2023-04-19 10:43:19', '[22]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681893799;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681893799;s:19:"scheduled_timestamp";i:1681893799;s:9:"timestamp";i:1681893799;}', 0, 1, '2023-04-19 08:44:08', '2023-04-19 10:44:08', 0, NULL),
(30, 'adjust_download_permissions', 'complete', '2023-04-19 08:44:09', '2023-04-19 10:44:09', '[22]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681893849;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681893849;s:19:"scheduled_timestamp";i:1681893849;s:9:"timestamp";i:1681893849;}', 0, 1, '2023-04-19 08:45:38', '2023-04-19 10:45:38', 0, NULL),
(31, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 08:44:09', '2023-04-19 10:44:09', '[22,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681893849;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681893849;s:19:"scheduled_timestamp";i:1681893849;s:9:"timestamp";i:1681893849;}', 2, 1, '2023-04-19 08:45:38', '2023-04-19 10:45:38', 0, NULL),
(32, 'wc_schedule_update_product_default_cat', 'complete', '2023-04-19 08:47:07', '2023-04-19 10:47:07', '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681894027;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681894027;s:19:"scheduled_timestamp";i:1681894027;s:9:"timestamp";i:1681894027;}', 3, 1, '2023-04-19 08:48:38', '2023-04-19 10:48:38', 0, NULL),
(33, 'wc_schedule_update_product_default_cat', 'complete', '2023-04-19 08:47:10', '2023-04-19 10:47:10', '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681894030;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681894030;s:19:"scheduled_timestamp";i:1681894030;s:9:"timestamp";i:1681894030;}', 3, 1, '2023-04-19 08:48:38', '2023-04-19 10:48:38', 0, NULL),
(34, 'woocommerce_admin/stored_state_setup_for_products/async/run_remote_notifications', 'failed', '2023-04-19 08:55:44', '2023-04-19 08:55:44', '[]', 'O:28:"ActionScheduler_NullSchedule":0:{}', 0, 1, '2023-04-19 08:55:45', '2023-04-19 10:55:45', 0, NULL),
(35, 'adjust_download_permissions', 'complete', '2023-04-19 08:55:46', '2023-04-19 10:55:46', '[22]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681894546;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681894546;s:19:"scheduled_timestamp";i:1681894546;s:9:"timestamp";i:1681894546;}', 0, 1, '2023-04-19 08:55:51', '2023-04-19 10:55:51', 0, NULL),
(36, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 08:55:46', '2023-04-19 10:55:46', '[22,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681894546;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681894546;s:19:"scheduled_timestamp";i:1681894546;s:9:"timestamp";i:1681894546;}', 2, 1, '2023-04-19 08:55:51', '2023-04-19 10:55:51', 0, NULL),
(37, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 09:39:04', '2023-04-19 11:39:04', '[26,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681897144;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681897144;s:19:"scheduled_timestamp";i:1681897144;s:9:"timestamp";i:1681897144;}', 2, 1, '2023-04-19 09:40:10', '2023-04-19 11:40:10', 0, NULL),
(38, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 09:46:10', '2023-04-19 11:46:10', '[29,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681897570;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681897570;s:19:"scheduled_timestamp";i:1681897570;s:9:"timestamp";i:1681897570;}', 2, 1, '2023-04-19 09:46:10', '2023-04-19 11:46:10', 0, NULL),
(39, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 09:46:14', '2023-04-19 11:46:14', '[29,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681897574;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681897574;s:19:"scheduled_timestamp";i:1681897574;s:9:"timestamp";i:1681897574;}', 2, 1, '2023-04-19 09:46:16', '2023-04-19 11:46:16', 0, NULL),
(40, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 09:46:25', '2023-04-19 11:46:25', '[30,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681897585;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681897585;s:19:"scheduled_timestamp";i:1681897585;s:9:"timestamp";i:1681897585;}', 2, 1, '2023-04-19 09:47:03', '2023-04-19 11:47:03', 0, NULL),
(41, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 09:46:25', '2023-04-19 11:46:25', '[31,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681897585;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681897585;s:19:"scheduled_timestamp";i:1681897585;s:9:"timestamp";i:1681897585;}', 2, 1, '2023-04-19 09:47:03', '2023-04-19 11:47:03', 0, NULL),
(42, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 09:46:25', '2023-04-19 11:46:25', '[32,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681897585;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681897585;s:19:"scheduled_timestamp";i:1681897585;s:9:"timestamp";i:1681897585;}', 2, 1, '2023-04-19 09:47:03', '2023-04-19 11:47:03', 0, NULL),
(43, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 09:46:25', '2023-04-19 11:46:25', '[33,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681897585;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681897585;s:19:"scheduled_timestamp";i:1681897585;s:9:"timestamp";i:1681897585;}', 2, 1, '2023-04-19 09:47:03', '2023-04-19 11:47:03', 0, NULL),
(44, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 09:46:25', '2023-04-19 11:46:25', '[34,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681897585;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681897585;s:19:"scheduled_timestamp";i:1681897585;s:9:"timestamp";i:1681897585;}', 2, 1, '2023-04-19 09:47:03', '2023-04-19 11:47:03', 0, NULL),
(45, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 09:46:25', '2023-04-19 11:46:25', '[35,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681897585;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681897585;s:19:"scheduled_timestamp";i:1681897585;s:9:"timestamp";i:1681897585;}', 2, 1, '2023-04-19 09:47:03', '2023-04-19 11:47:03', 0, NULL),
(46, 'adjust_download_permissions', 'complete', '2023-04-19 09:46:25', '2023-04-19 11:46:25', '[29]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681897585;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681897585;s:19:"scheduled_timestamp";i:1681897585;s:9:"timestamp";i:1681897585;}', 0, 1, '2023-04-19 09:47:03', '2023-04-19 11:47:03', 0, NULL),
(47, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 09:46:25', '2023-04-19 11:46:25', '[29,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681897585;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681897585;s:19:"scheduled_timestamp";i:1681897585;s:9:"timestamp";i:1681897585;}', 2, 1, '2023-04-19 09:47:03', '2023-04-19 11:47:03', 0, NULL),
(48, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 09:46:49', '2023-04-19 11:46:49', '[30,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681897609;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681897609;s:19:"scheduled_timestamp";i:1681897609;s:9:"timestamp";i:1681897609;}', 2, 1, '2023-04-19 09:47:03', '2023-04-19 11:47:03', 0, NULL),
(49, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 09:46:49', '2023-04-19 11:46:49', '[31,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681897609;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681897609;s:19:"scheduled_timestamp";i:1681897609;s:9:"timestamp";i:1681897609;}', 2, 1, '2023-04-19 09:47:03', '2023-04-19 11:47:03', 0, NULL),
(50, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 09:46:49', '2023-04-19 11:46:49', '[32,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681897609;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681897609;s:19:"scheduled_timestamp";i:1681897609;s:9:"timestamp";i:1681897609;}', 2, 1, '2023-04-19 09:47:03', '2023-04-19 11:47:03', 0, NULL),
(51, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 09:46:49', '2023-04-19 11:46:49', '[33,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681897609;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681897609;s:19:"scheduled_timestamp";i:1681897609;s:9:"timestamp";i:1681897609;}', 2, 1, '2023-04-19 09:47:03', '2023-04-19 11:47:03', 0, NULL),
(52, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 09:46:49', '2023-04-19 11:46:49', '[34,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681897609;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681897609;s:19:"scheduled_timestamp";i:1681897609;s:9:"timestamp";i:1681897609;}', 2, 1, '2023-04-19 09:47:03', '2023-04-19 11:47:03', 0, NULL),
(53, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 09:46:49', '2023-04-19 11:46:49', '[35,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681897609;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681897609;s:19:"scheduled_timestamp";i:1681897609;s:9:"timestamp";i:1681897609;}', 2, 1, '2023-04-19 09:47:03', '2023-04-19 11:47:03', 0, NULL),
(54, 'adjust_download_permissions', 'complete', '2023-04-19 09:51:57', '2023-04-19 11:51:57', '[29]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681897917;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681897917;s:19:"scheduled_timestamp";i:1681897917;s:9:"timestamp";i:1681897917;}', 0, 1, '2023-04-19 09:52:03', '2023-04-19 11:52:03', 0, NULL),
(55, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 09:51:57', '2023-04-19 11:51:57', '[30,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681897917;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681897917;s:19:"scheduled_timestamp";i:1681897917;s:9:"timestamp";i:1681897917;}', 2, 1, '2023-04-19 09:52:03', '2023-04-19 11:52:03', 0, NULL),
(56, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 09:51:57', '2023-04-19 11:51:57', '[31,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681897917;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681897917;s:19:"scheduled_timestamp";i:1681897917;s:9:"timestamp";i:1681897917;}', 2, 1, '2023-04-19 09:52:03', '2023-04-19 11:52:03', 0, NULL),
(57, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 09:51:57', '2023-04-19 11:51:57', '[32,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681897917;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681897917;s:19:"scheduled_timestamp";i:1681897917;s:9:"timestamp";i:1681897917;}', 2, 1, '2023-04-19 09:52:03', '2023-04-19 11:52:03', 0, NULL),
(58, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 09:51:57', '2023-04-19 11:51:57', '[33,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681897917;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681897917;s:19:"scheduled_timestamp";i:1681897917;s:9:"timestamp";i:1681897917;}', 2, 1, '2023-04-19 09:52:03', '2023-04-19 11:52:03', 0, NULL),
(59, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 09:51:57', '2023-04-19 11:51:57', '[34,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681897917;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681897917;s:19:"scheduled_timestamp";i:1681897917;s:9:"timestamp";i:1681897917;}', 2, 1, '2023-04-19 09:52:03', '2023-04-19 11:52:03', 0, NULL),
(60, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 09:51:57', '2023-04-19 11:51:57', '[35,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681897917;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681897917;s:19:"scheduled_timestamp";i:1681897917;s:9:"timestamp";i:1681897917;}', 2, 1, '2023-04-19 09:52:03', '2023-04-19 11:52:03', 0, NULL),
(61, 'adjust_download_permissions', 'complete', '2023-04-19 09:53:48', '2023-04-19 11:53:48', '[29]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681898028;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681898028;s:19:"scheduled_timestamp";i:1681898028;s:9:"timestamp";i:1681898028;}', 0, 1, '2023-04-19 09:54:03', '2023-04-19 11:54:03', 0, NULL),
(62, 'adjust_download_permissions', 'complete', '2023-04-19 09:54:23', '2023-04-19 11:54:23', '[29]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681898063;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681898063;s:19:"scheduled_timestamp";i:1681898063;s:9:"timestamp";i:1681898063;}', 0, 1, '2023-04-19 09:55:03', '2023-04-19 11:55:03', 0, NULL),
(63, 'adjust_download_permissions', 'complete', '2023-04-19 09:55:18', '2023-04-19 11:55:18', '[29]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681898118;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681898118;s:19:"scheduled_timestamp";i:1681898118;s:9:"timestamp";i:1681898118;}', 0, 1, '2023-04-19 09:56:03', '2023-04-19 11:56:03', 0, NULL),
(64, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 09:55:18', '2023-04-19 11:55:18', '[29,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681898118;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681898118;s:19:"scheduled_timestamp";i:1681898118;s:9:"timestamp";i:1681898118;}', 2, 1, '2023-04-19 09:56:03', '2023-04-19 11:56:03', 0, NULL),
(65, 'adjust_download_permissions', 'complete', '2023-04-19 09:56:25', '2023-04-19 11:56:25', '[29]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681898185;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681898185;s:19:"scheduled_timestamp";i:1681898185;s:9:"timestamp";i:1681898185;}', 0, 1, '2023-04-19 09:57:03', '2023-04-19 11:57:03', 0, NULL),
(66, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 10:03:06', '2023-04-19 12:03:06', '[36,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681898586;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681898586;s:19:"scheduled_timestamp";i:1681898586;s:9:"timestamp";i:1681898586;}', 2, 1, '2023-04-19 10:04:05', '2023-04-19 12:04:05', 0, NULL),
(67, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 10:06:34', '2023-04-19 12:06:34', '[36,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681898794;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681898794;s:19:"scheduled_timestamp";i:1681898794;s:9:"timestamp";i:1681898794;}', 2, 1, '2023-04-19 10:07:09', '2023-04-19 12:07:09', 0, NULL),
(68, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 10:08:18', '2023-04-19 12:08:18', '[37,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681898898;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681898898;s:19:"scheduled_timestamp";i:1681898898;s:9:"timestamp";i:1681898898;}', 2, 1, '2023-04-19 10:09:09', '2023-04-19 12:09:09', 0, NULL),
(69, 'adjust_download_permissions', 'complete', '2023-04-19 10:08:18', '2023-04-19 12:08:18', '[36]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681898898;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681898898;s:19:"scheduled_timestamp";i:1681898898;s:9:"timestamp";i:1681898898;}', 0, 1, '2023-04-19 10:09:09', '2023-04-19 12:09:09', 0, NULL),
(70, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 10:08:18', '2023-04-19 12:08:18', '[36,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681898898;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681898898;s:19:"scheduled_timestamp";i:1681898898;s:9:"timestamp";i:1681898898;}', 2, 1, '2023-04-19 10:09:09', '2023-04-19 12:09:09', 0, NULL),
(71, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 10:08:30', '2023-04-19 12:08:30', '[37,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681898910;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681898910;s:19:"scheduled_timestamp";i:1681898910;s:9:"timestamp";i:1681898910;}', 2, 1, '2023-04-19 10:09:09', '2023-04-19 12:09:09', 0, NULL),
(72, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 10:08:34', '2023-04-19 12:08:34', '[37,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681898914;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681898914;s:19:"scheduled_timestamp";i:1681898914;s:9:"timestamp";i:1681898914;}', 2, 1, '2023-04-19 10:09:09', '2023-04-19 12:09:09', 0, NULL),
(73, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 10:08:41', '2023-04-19 12:08:41', '[38,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681898921;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681898921;s:19:"scheduled_timestamp";i:1681898921;s:9:"timestamp";i:1681898921;}', 2, 1, '2023-04-19 10:09:09', '2023-04-19 12:09:09', 0, NULL),
(74, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 10:08:41', '2023-04-19 12:08:41', '[39,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681898921;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681898921;s:19:"scheduled_timestamp";i:1681898921;s:9:"timestamp";i:1681898921;}', 2, 1, '2023-04-19 10:09:09', '2023-04-19 12:09:09', 0, NULL),
(75, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 10:08:41', '2023-04-19 12:08:41', '[40,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681898921;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681898921;s:19:"scheduled_timestamp";i:1681898921;s:9:"timestamp";i:1681898921;}', 2, 1, '2023-04-19 10:09:09', '2023-04-19 12:09:09', 0, NULL),
(76, 'adjust_download_permissions', 'complete', '2023-04-19 10:13:54', '2023-04-19 12:13:54', '[36]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681899234;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681899234;s:19:"scheduled_timestamp";i:1681899234;s:9:"timestamp";i:1681899234;}', 0, 1, '2023-04-19 10:14:10', '2023-04-19 12:14:10', 0, NULL),
(77, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 10:13:54', '2023-04-19 12:13:54', '[38,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681899234;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681899234;s:19:"scheduled_timestamp";i:1681899234;s:9:"timestamp";i:1681899234;}', 2, 1, '2023-04-19 10:14:10', '2023-04-19 12:14:10', 0, NULL),
(78, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 10:13:54', '2023-04-19 12:13:54', '[39,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681899234;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681899234;s:19:"scheduled_timestamp";i:1681899234;s:9:"timestamp";i:1681899234;}', 2, 1, '2023-04-19 10:14:10', '2023-04-19 12:14:10', 0, NULL),
(79, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 10:13:54', '2023-04-19 12:13:54', '[40,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681899234;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681899234;s:19:"scheduled_timestamp";i:1681899234;s:9:"timestamp";i:1681899234;}', 2, 1, '2023-04-19 10:14:10', '2023-04-19 12:14:10', 0, NULL),
(80, 'adjust_download_permissions', 'complete', '2023-04-19 10:14:53', '2023-04-19 12:14:53', '[36]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681899293;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681899293;s:19:"scheduled_timestamp";i:1681899293;s:9:"timestamp";i:1681899293;}', 0, 1, '2023-04-19 10:15:09', '2023-04-19 12:15:09', 0, NULL),
(81, 'adjust_download_permissions', 'complete', '2023-04-19 10:15:10', '2023-04-19 12:15:10', '[36]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681899310;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681899310;s:19:"scheduled_timestamp";i:1681899310;s:9:"timestamp";i:1681899310;}', 0, 1, '2023-04-19 10:16:01', '2023-04-19 12:16:01', 0, NULL),
(82, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 10:15:10', '2023-04-19 12:15:10', '[36,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681899310;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681899310;s:19:"scheduled_timestamp";i:1681899310;s:9:"timestamp";i:1681899310;}', 2, 1, '2023-04-19 10:16:01', '2023-04-19 12:16:01', 0, NULL),
(83, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 12:10:50', '2023-04-19 14:10:50', '[45,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681906250;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681906250;s:19:"scheduled_timestamp";i:1681906250;s:9:"timestamp";i:1681906250;}', 2, 1, '2023-04-19 12:11:09', '2023-04-19 14:11:09', 0, NULL),
(84, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 12:18:19', '2023-04-19 14:18:19', '[45,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681906699;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681906699;s:19:"scheduled_timestamp";i:1681906699;s:9:"timestamp";i:1681906699;}', 2, 1, '2023-04-19 12:19:05', '2023-04-19 14:19:05', 0, NULL),
(85, 'woocommerce_cleanup_draft_orders', 'complete', '2023-04-21 09:22:13', '2023-04-21 11:22:13', '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1682068933;s:18:"\0*\0first_timestamp";i:1681890007;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1682068933;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1682068933;s:15:"first_timestamp";i:1681890007;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1682068933;s:19:"interval_in_seconds";i:86400;}', 0, 1, '2023-04-21 09:25:46', '2023-04-21 11:25:46', 0, NULL),
(86, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 12:58:11', '2023-04-20 14:58:11', '[45,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681995491;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681995491;s:19:"scheduled_timestamp";i:1681995491;s:9:"timestamp";i:1681995491;}', 2, 1, '2023-04-20 12:59:04', '2023-04-20 14:59:04', 0, NULL),
(87, 'adjust_download_permissions', 'complete', '2023-04-20 13:56:53', '2023-04-20 15:56:53', '[22]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681999013;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681999013;s:19:"scheduled_timestamp";i:1681999013;s:9:"timestamp";i:1681999013;}', 0, 1, '2023-04-20 13:57:04', '2023-04-20 15:57:04', 0, NULL),
(88, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 13:56:53', '2023-04-20 15:56:53', '[22,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681999013;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681999013;s:19:"scheduled_timestamp";i:1681999013;s:9:"timestamp";i:1681999013;}', 2, 1, '2023-04-20 13:57:04', '2023-04-20 15:57:04', 0, NULL),
(89, 'adjust_download_permissions', 'complete', '2023-04-20 13:58:19', '2023-04-20 15:58:19', '[29]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681999099;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681999099;s:19:"scheduled_timestamp";i:1681999099;s:9:"timestamp";i:1681999099;}', 0, 1, '2023-04-20 14:02:25', '2023-04-20 16:02:25', 0, NULL),
(90, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 13:58:23', '2023-04-20 15:58:23', '[29,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681999103;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681999103;s:19:"scheduled_timestamp";i:1681999103;s:9:"timestamp";i:1681999103;}', 2, 1, '2023-04-20 14:02:25', '2023-04-20 16:02:25', 0, NULL),
(91, 'action_scheduler/migration_hook', 'complete', '2023-04-21 09:13:51', '2023-04-21 11:13:51', '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682068431;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682068431;s:19:"scheduled_timestamp";i:1682068431;s:9:"timestamp";i:1682068431;}', 1, 1, '2023-04-21 09:13:52', '2023-04-21 11:13:52', 0, NULL),
(92, 'action_scheduler/migration_hook', 'failed', '2023-04-21 09:14:52', '2023-04-21 11:14:52', '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682068492;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682068492;s:19:"scheduled_timestamp";i:1682068492;s:9:"timestamp";i:1682068492;}', 1, 1, '2023-04-21 09:15:04', '2023-04-21 11:15:04', 0, NULL),
(93, 'woocommerce_cleanup_draft_orders', 'complete', '2023-04-22 09:25:46', '2023-04-22 11:25:46', '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1682155546;s:18:"\0*\0first_timestamp";i:1681890007;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1682155546;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1682155546;s:15:"first_timestamp";i:1681890007;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1682155546;s:19:"interval_in_seconds";i:86400;}', 0, 1, '2023-04-23 17:59:09', '2023-04-23 19:59:09', 0, NULL),
(94, 'woocommerce_cleanup_draft_orders', 'pending', '2023-04-24 17:59:09', '2023-04-24 19:59:09', '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1682359149;s:18:"\0*\0first_timestamp";i:1681890007;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1682359149;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1682359149;s:15:"first_timestamp";i:1681890007;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1682359149;s:19:"interval_in_seconds";i:86400;}', 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(95, 'action_scheduler/migration_hook', 'complete', '2023-04-23 19:36:10', '2023-04-23 21:36:10', '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682278570;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682278570;s:19:"scheduled_timestamp";i:1682278570;s:9:"timestamp";i:1682278570;}', 1, 1, '2023-04-23 19:36:30', '2023-04-23 21:36:30', 0, NULL),
(96, 'action_scheduler/migration_hook', 'complete', '2023-04-23 19:42:17', '2023-04-23 21:42:17', '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682278937;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682278937;s:19:"scheduled_timestamp";i:1682278937;s:9:"timestamp";i:1682278937;}', 1, 1, '2023-04-24 12:47:16', '2023-04-24 14:47:16', 0, NULL) ;

#
# End of data contents of table `wp_actionscheduler_actions`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_claims`
#

DROP TABLE IF EXISTS `wp_actionscheduler_claims`;


#
# Table structure of table `wp_actionscheduler_claims`
#

CREATE TABLE `wp_actionscheduler_claims` (
  `claim_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date_created_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`claim_id`),
  KEY `date_created_gmt` (`date_created_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_claims`
#

#
# End of data contents of table `wp_actionscheduler_claims`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_groups`
#

DROP TABLE IF EXISTS `wp_actionscheduler_groups`;


#
# Table structure of table `wp_actionscheduler_groups`
#

CREATE TABLE `wp_actionscheduler_groups` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_groups`
#
INSERT INTO `wp_actionscheduler_groups` ( `group_id`, `slug`) VALUES
(1, 'action-scheduler-migration'),
(2, 'woocommerce-db-updates'),
(3, 'wc_update_product_default_cat') ;

#
# End of data contents of table `wp_actionscheduler_groups`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_logs`
#

DROP TABLE IF EXISTS `wp_actionscheduler_logs`;


#
# Table structure of table `wp_actionscheduler_logs`
#

CREATE TABLE `wp_actionscheduler_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint(20) unsigned NOT NULL,
  `message` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `log_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=272 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_logs`
#
INSERT INTO `wp_actionscheduler_logs` ( `log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(1, 6, 'åtgärd skapad', '2023-04-19 07:40:05', '2023-04-19 09:40:05'),
(2, 7, 'åtgärd skapad', '2023-04-19 07:40:07', '2023-04-19 09:40:07'),
(3, 7, 'åtgärden startades via WP Cron', '2023-04-19 07:41:11', '2023-04-19 09:41:11'),
(4, 7, 'åtgärden slutförd via WP Cron', '2023-04-19 07:41:11', '2023-04-19 09:41:11'),
(5, 8, 'åtgärd skapad', '2023-04-19 07:41:11', '2023-04-19 09:41:11'),
(6, 6, 'åtgärden startades via WP Cron', '2023-04-19 07:41:11', '2023-04-19 09:41:11'),
(7, 6, 'åtgärden slutförd via WP Cron', '2023-04-19 07:41:11', '2023-04-19 09:41:11'),
(8, 9, 'åtgärd skapad', '2023-04-19 07:48:23', '2023-04-19 09:48:23'),
(9, 9, 'åtgärden startades via WP Cron', '2023-04-19 07:49:27', '2023-04-19 09:49:27'),
(10, 9, 'åtgärden slutförd via WP Cron', '2023-04-19 07:49:28', '2023-04-19 09:49:28'),
(11, 10, 'åtgärd skapad', '2023-04-19 08:19:58', '2023-04-19 10:19:58'),
(12, 10, 'åtgärden startades via WP Cron', '2023-04-19 08:20:03', '2023-04-19 10:20:03'),
(13, 10, 'åtgärden slutförd via WP Cron', '2023-04-19 08:20:03', '2023-04-19 10:20:03'),
(14, 11, 'åtgärd skapad', '2023-04-19 08:27:14', '2023-04-19 10:27:14'),
(15, 11, 'åtgärden startades via WP Cron', '2023-04-19 08:28:14', '2023-04-19 10:28:14'),
(16, 11, 'åtgärden slutförd via WP Cron', '2023-04-19 08:28:14', '2023-04-19 10:28:14'),
(17, 12, 'åtgärd skapad', '2023-04-19 08:29:50', '2023-04-19 10:29:50'),
(18, 12, 'åtgärden startades via WP Cron', '2023-04-19 08:30:03', '2023-04-19 10:30:03'),
(19, 12, 'åtgärden slutförd via WP Cron', '2023-04-19 08:30:03', '2023-04-19 10:30:03'),
(20, 13, 'åtgärd skapad', '2023-04-19 08:32:57', '2023-04-19 10:32:57'),
(21, 13, 'åtgärden startades via WP Cron', '2023-04-19 08:33:02', '2023-04-19 10:33:02'),
(22, 13, 'åtgärden slutförd via WP Cron', '2023-04-19 08:33:02', '2023-04-19 10:33:02'),
(23, 14, 'åtgärd skapad', '2023-04-19 08:34:12', '2023-04-19 10:34:12'),
(24, 14, 'åtgärden startades via Async Request', '2023-04-19 08:34:16', '2023-04-19 10:34:16'),
(25, 14, 'åtgärden slutförd via Async Request', '2023-04-19 08:34:16', '2023-04-19 10:34:16'),
(26, 15, 'åtgärd skapad', '2023-04-19 08:37:24', '2023-04-19 10:37:24'),
(27, 16, 'åtgärd skapad', '2023-04-19 08:37:24', '2023-04-19 10:37:24'),
(28, 17, 'åtgärd skapad', '2023-04-19 08:37:24', '2023-04-19 10:37:24'),
(29, 18, 'åtgärd skapad', '2023-04-19 08:37:24', '2023-04-19 10:37:24'),
(30, 19, 'åtgärd skapad', '2023-04-19 08:37:24', '2023-04-19 10:37:24'),
(31, 15, 'åtgärden startades via WP Cron', '2023-04-19 08:38:39', '2023-04-19 10:38:39'),
(32, 15, 'åtgärden slutförd via WP Cron', '2023-04-19 08:38:39', '2023-04-19 10:38:39'),
(33, 16, 'åtgärden startades via WP Cron', '2023-04-19 08:38:39', '2023-04-19 10:38:39'),
(34, 16, 'åtgärden slutförd via WP Cron', '2023-04-19 08:38:39', '2023-04-19 10:38:39'),
(35, 17, 'åtgärden startades via WP Cron', '2023-04-19 08:38:39', '2023-04-19 10:38:39'),
(36, 17, 'åtgärden slutförd via WP Cron', '2023-04-19 08:38:39', '2023-04-19 10:38:39'),
(37, 18, 'åtgärden startades via WP Cron', '2023-04-19 08:38:39', '2023-04-19 10:38:39'),
(38, 18, 'åtgärden slutförd via WP Cron', '2023-04-19 08:38:39', '2023-04-19 10:38:39'),
(39, 19, 'åtgärden startades via WP Cron', '2023-04-19 08:38:39', '2023-04-19 10:38:39'),
(40, 19, 'åtgärden slutförd via WP Cron', '2023-04-19 08:38:39', '2023-04-19 10:38:39'),
(41, 20, 'åtgärd skapad', '2023-04-19 08:38:39', '2023-04-19 10:38:39'),
(42, 21, 'åtgärd skapad', '2023-04-19 08:38:39', '2023-04-19 10:38:39'),
(43, 22, 'åtgärd skapad', '2023-04-19 08:38:39', '2023-04-19 10:38:39'),
(44, 23, 'åtgärd skapad', '2023-04-19 08:38:39', '2023-04-19 10:38:39'),
(45, 20, 'åtgärden startades via Async Request', '2023-04-19 08:38:40', '2023-04-19 10:38:40'),
(46, 20, 'åtgärden slutförd via Async Request', '2023-04-19 08:38:40', '2023-04-19 10:38:40'),
(47, 21, 'åtgärden startades via Async Request', '2023-04-19 08:38:40', '2023-04-19 10:38:40'),
(48, 21, 'åtgärden slutförd via Async Request', '2023-04-19 08:38:40', '2023-04-19 10:38:40'),
(49, 22, 'åtgärden startades via Async Request', '2023-04-19 08:38:40', '2023-04-19 10:38:40'),
(50, 22, 'åtgärden slutförd via Async Request', '2023-04-19 08:38:40', '2023-04-19 10:38:40'),
(51, 23, 'åtgärden startades via Async Request', '2023-04-19 08:38:40', '2023-04-19 10:38:40'),
(52, 23, 'åtgärden slutförd via Async Request', '2023-04-19 08:38:40', '2023-04-19 10:38:40'),
(53, 24, 'åtgärd skapad', '2023-04-19 08:40:42', '2023-04-19 10:40:42'),
(54, 25, 'åtgärd skapad', '2023-04-19 08:40:42', '2023-04-19 10:40:42'),
(55, 26, 'åtgärd skapad', '2023-04-19 08:40:42', '2023-04-19 10:40:42'),
(56, 27, 'åtgärd skapad', '2023-04-19 08:40:42', '2023-04-19 10:40:42'),
(57, 24, 'åtgärden startades via WP Cron', '2023-04-19 08:41:20', '2023-04-19 10:41:20'),
(58, 24, 'åtgärden slutförd via WP Cron', '2023-04-19 08:41:20', '2023-04-19 10:41:20'),
(59, 25, 'åtgärden startades via WP Cron', '2023-04-19 08:41:20', '2023-04-19 10:41:20'),
(60, 25, 'åtgärden slutförd via WP Cron', '2023-04-19 08:41:20', '2023-04-19 10:41:20'),
(61, 26, 'åtgärden startades via WP Cron', '2023-04-19 08:41:20', '2023-04-19 10:41:20'),
(62, 26, 'åtgärden slutförd via WP Cron', '2023-04-19 08:41:20', '2023-04-19 10:41:20'),
(63, 27, 'åtgärden startades via WP Cron', '2023-04-19 08:41:20', '2023-04-19 10:41:20'),
(64, 27, 'åtgärden slutförd via WP Cron', '2023-04-19 08:41:20', '2023-04-19 10:41:20'),
(65, 28, 'åtgärd skapad', '2023-04-19 08:41:20', '2023-04-19 10:41:20'),
(66, 28, 'åtgärden startades via Async Request', '2023-04-19 08:41:21', '2023-04-19 10:41:21'),
(67, 28, 'åtgärden slutförd via Async Request', '2023-04-19 08:41:21', '2023-04-19 10:41:21'),
(68, 29, 'åtgärd skapad', '2023-04-19 08:43:18', '2023-04-19 10:43:18'),
(69, 29, 'åtgärden startades via WP Cron', '2023-04-19 08:44:08', '2023-04-19 10:44:08'),
(70, 29, 'åtgärden slutförd via WP Cron', '2023-04-19 08:44:08', '2023-04-19 10:44:08'),
(71, 30, 'åtgärd skapad', '2023-04-19 08:44:08', '2023-04-19 10:44:08'),
(72, 31, 'åtgärd skapad', '2023-04-19 08:44:08', '2023-04-19 10:44:08'),
(73, 30, 'åtgärden startades via WP Cron', '2023-04-19 08:45:37', '2023-04-19 10:45:37'),
(74, 30, 'åtgärden slutförd via WP Cron', '2023-04-19 08:45:38', '2023-04-19 10:45:38'),
(75, 31, 'åtgärden startades via WP Cron', '2023-04-19 08:45:38', '2023-04-19 10:45:38'),
(76, 31, 'åtgärden slutförd via WP Cron', '2023-04-19 08:45:38', '2023-04-19 10:45:38'),
(77, 32, 'åtgärd skapad', '2023-04-19 08:47:07', '2023-04-19 10:47:07'),
(78, 33, 'åtgärd skapad', '2023-04-19 08:47:10', '2023-04-19 10:47:10'),
(79, 32, 'åtgärden startades via WP Cron', '2023-04-19 08:48:38', '2023-04-19 10:48:38'),
(80, 32, 'åtgärden slutförd via WP Cron', '2023-04-19 08:48:38', '2023-04-19 10:48:38'),
(81, 33, 'åtgärden startades via WP Cron', '2023-04-19 08:48:38', '2023-04-19 10:48:38'),
(82, 33, 'åtgärden slutförd via WP Cron', '2023-04-19 08:48:38', '2023-04-19 10:48:38'),
(83, 34, 'åtgärd skapad', '2023-04-19 08:55:44', '2023-04-19 10:55:44'),
(84, 35, 'åtgärd skapad', '2023-04-19 08:55:45', '2023-04-19 10:55:45'),
(85, 36, 'åtgärd skapad', '2023-04-19 08:55:45', '2023-04-19 10:55:45'),
(86, 34, 'åtgärden startades via Async Request', '2023-04-19 08:55:45', '2023-04-19 10:55:45'),
(87, 34, 'åtgärden misslyckades via Async Request: Den schemalagda åtgärden för woocommerce_admin/stored_state_setup_for_products/async/run_remote_notifications kommer inte att utföras eftersom inga återanrop har registrerats.', '2023-04-19 08:55:45', '2023-04-19 10:55:45'),
(88, 35, 'åtgärden startades via Async Request', '2023-04-19 08:55:51', '2023-04-19 10:55:51'),
(89, 35, 'åtgärden slutförd via Async Request', '2023-04-19 08:55:51', '2023-04-19 10:55:51'),
(90, 36, 'åtgärden startades via Async Request', '2023-04-19 08:55:51', '2023-04-19 10:55:51'),
(91, 36, 'åtgärden slutförd via Async Request', '2023-04-19 08:55:51', '2023-04-19 10:55:51'),
(92, 37, 'åtgärd skapad', '2023-04-19 09:39:03', '2023-04-19 11:39:03'),
(93, 37, 'åtgärden startades via WP Cron', '2023-04-19 09:40:10', '2023-04-19 11:40:10'),
(94, 37, 'åtgärden slutförd via WP Cron', '2023-04-19 09:40:10', '2023-04-19 11:40:10'),
(95, 38, 'åtgärd skapad', '2023-04-19 09:46:09', '2023-04-19 11:46:09'),
(96, 38, 'åtgärden startades via Async Request', '2023-04-19 09:46:10', '2023-04-19 11:46:10'),
(97, 38, 'åtgärden slutförd via Async Request', '2023-04-19 09:46:10', '2023-04-19 11:46:10'),
(98, 39, 'åtgärd skapad', '2023-04-19 09:46:13', '2023-04-19 11:46:13'),
(99, 39, 'åtgärden startades via Async Request', '2023-04-19 09:46:16', '2023-04-19 11:46:16'),
(100, 39, 'åtgärden slutförd via Async Request', '2023-04-19 09:46:16', '2023-04-19 11:46:16') ;
INSERT INTO `wp_actionscheduler_logs` ( `log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(101, 40, 'åtgärd skapad', '2023-04-19 09:46:24', '2023-04-19 11:46:24'),
(102, 41, 'åtgärd skapad', '2023-04-19 09:46:24', '2023-04-19 11:46:24'),
(103, 42, 'åtgärd skapad', '2023-04-19 09:46:24', '2023-04-19 11:46:24'),
(104, 43, 'åtgärd skapad', '2023-04-19 09:46:24', '2023-04-19 11:46:24'),
(105, 44, 'åtgärd skapad', '2023-04-19 09:46:24', '2023-04-19 11:46:24'),
(106, 45, 'åtgärd skapad', '2023-04-19 09:46:24', '2023-04-19 11:46:24'),
(107, 46, 'åtgärd skapad', '2023-04-19 09:46:24', '2023-04-19 11:46:24'),
(108, 47, 'åtgärd skapad', '2023-04-19 09:46:24', '2023-04-19 11:46:24'),
(109, 48, 'åtgärd skapad', '2023-04-19 09:46:48', '2023-04-19 11:46:48'),
(110, 49, 'åtgärd skapad', '2023-04-19 09:46:48', '2023-04-19 11:46:48'),
(111, 50, 'åtgärd skapad', '2023-04-19 09:46:48', '2023-04-19 11:46:48'),
(112, 51, 'åtgärd skapad', '2023-04-19 09:46:48', '2023-04-19 11:46:48'),
(113, 52, 'åtgärd skapad', '2023-04-19 09:46:48', '2023-04-19 11:46:48'),
(114, 53, 'åtgärd skapad', '2023-04-19 09:46:48', '2023-04-19 11:46:48'),
(115, 40, 'åtgärden startades via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(116, 40, 'åtgärden slutförd via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(117, 41, 'åtgärden startades via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(118, 41, 'åtgärden slutförd via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(119, 42, 'åtgärden startades via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(120, 42, 'åtgärden slutförd via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(121, 43, 'åtgärden startades via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(122, 43, 'åtgärden slutförd via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(123, 44, 'åtgärden startades via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(124, 44, 'åtgärden slutförd via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(125, 45, 'åtgärden startades via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(126, 45, 'åtgärden slutförd via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(127, 46, 'åtgärden startades via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(128, 46, 'åtgärden slutförd via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(129, 47, 'åtgärden startades via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(130, 47, 'åtgärden slutförd via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(131, 48, 'åtgärden startades via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(132, 48, 'åtgärden slutförd via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(133, 49, 'åtgärden startades via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(134, 49, 'åtgärden slutförd via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(135, 50, 'åtgärden startades via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(136, 50, 'åtgärden slutförd via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(137, 51, 'åtgärden startades via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(138, 51, 'åtgärden slutförd via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(139, 52, 'åtgärden startades via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(140, 52, 'åtgärden slutförd via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(141, 53, 'åtgärden startades via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(142, 53, 'åtgärden slutförd via WP Cron', '2023-04-19 09:47:03', '2023-04-19 11:47:03'),
(143, 54, 'åtgärd skapad', '2023-04-19 09:51:56', '2023-04-19 11:51:56'),
(144, 55, 'åtgärd skapad', '2023-04-19 09:51:56', '2023-04-19 11:51:56'),
(145, 56, 'åtgärd skapad', '2023-04-19 09:51:56', '2023-04-19 11:51:56'),
(146, 57, 'åtgärd skapad', '2023-04-19 09:51:56', '2023-04-19 11:51:56'),
(147, 58, 'åtgärd skapad', '2023-04-19 09:51:56', '2023-04-19 11:51:56'),
(148, 59, 'åtgärd skapad', '2023-04-19 09:51:56', '2023-04-19 11:51:56'),
(149, 60, 'åtgärd skapad', '2023-04-19 09:51:56', '2023-04-19 11:51:56'),
(150, 54, 'åtgärden startades via WP Cron', '2023-04-19 09:52:03', '2023-04-19 11:52:03'),
(151, 54, 'åtgärden slutförd via WP Cron', '2023-04-19 09:52:03', '2023-04-19 11:52:03'),
(152, 55, 'åtgärden startades via WP Cron', '2023-04-19 09:52:03', '2023-04-19 11:52:03'),
(153, 55, 'åtgärden slutförd via WP Cron', '2023-04-19 09:52:03', '2023-04-19 11:52:03'),
(154, 56, 'åtgärden startades via WP Cron', '2023-04-19 09:52:03', '2023-04-19 11:52:03'),
(155, 56, 'åtgärden slutförd via WP Cron', '2023-04-19 09:52:03', '2023-04-19 11:52:03'),
(156, 57, 'åtgärden startades via WP Cron', '2023-04-19 09:52:03', '2023-04-19 11:52:03'),
(157, 57, 'åtgärden slutförd via WP Cron', '2023-04-19 09:52:03', '2023-04-19 11:52:03'),
(158, 58, 'åtgärden startades via WP Cron', '2023-04-19 09:52:03', '2023-04-19 11:52:03'),
(159, 58, 'åtgärden slutförd via WP Cron', '2023-04-19 09:52:03', '2023-04-19 11:52:03'),
(160, 59, 'åtgärden startades via WP Cron', '2023-04-19 09:52:03', '2023-04-19 11:52:03'),
(161, 59, 'åtgärden slutförd via WP Cron', '2023-04-19 09:52:03', '2023-04-19 11:52:03'),
(162, 60, 'åtgärden startades via WP Cron', '2023-04-19 09:52:03', '2023-04-19 11:52:03'),
(163, 60, 'åtgärden slutförd via WP Cron', '2023-04-19 09:52:03', '2023-04-19 11:52:03'),
(164, 61, 'åtgärd skapad', '2023-04-19 09:53:47', '2023-04-19 11:53:47'),
(165, 61, 'åtgärden startades via WP Cron', '2023-04-19 09:54:03', '2023-04-19 11:54:03'),
(166, 61, 'åtgärden slutförd via WP Cron', '2023-04-19 09:54:03', '2023-04-19 11:54:03'),
(167, 62, 'åtgärd skapad', '2023-04-19 09:54:22', '2023-04-19 11:54:22'),
(168, 62, 'åtgärden startades via WP Cron', '2023-04-19 09:55:03', '2023-04-19 11:55:03'),
(169, 62, 'åtgärden slutförd via WP Cron', '2023-04-19 09:55:03', '2023-04-19 11:55:03'),
(170, 63, 'åtgärd skapad', '2023-04-19 09:55:17', '2023-04-19 11:55:17'),
(171, 64, 'åtgärd skapad', '2023-04-19 09:55:17', '2023-04-19 11:55:17'),
(172, 63, 'åtgärden startades via WP Cron', '2023-04-19 09:56:03', '2023-04-19 11:56:03'),
(173, 63, 'åtgärden slutförd via WP Cron', '2023-04-19 09:56:03', '2023-04-19 11:56:03'),
(174, 64, 'åtgärden startades via WP Cron', '2023-04-19 09:56:03', '2023-04-19 11:56:03'),
(175, 64, 'åtgärden slutförd via WP Cron', '2023-04-19 09:56:03', '2023-04-19 11:56:03'),
(176, 65, 'åtgärd skapad', '2023-04-19 09:56:24', '2023-04-19 11:56:24'),
(177, 65, 'åtgärden startades via WP Cron', '2023-04-19 09:57:03', '2023-04-19 11:57:03'),
(178, 65, 'åtgärden slutförd via WP Cron', '2023-04-19 09:57:03', '2023-04-19 11:57:03'),
(179, 66, 'åtgärd skapad', '2023-04-19 10:03:05', '2023-04-19 12:03:05'),
(180, 66, 'åtgärden startades via WP Cron', '2023-04-19 10:04:05', '2023-04-19 12:04:05'),
(181, 66, 'åtgärden slutförd via WP Cron', '2023-04-19 10:04:05', '2023-04-19 12:04:05'),
(182, 67, 'åtgärd skapad', '2023-04-19 10:06:34', '2023-04-19 12:06:34'),
(183, 67, 'åtgärden startades via WP Cron', '2023-04-19 10:07:09', '2023-04-19 12:07:09'),
(184, 67, 'åtgärden slutförd via WP Cron', '2023-04-19 10:07:09', '2023-04-19 12:07:09'),
(185, 68, 'åtgärd skapad', '2023-04-19 10:08:17', '2023-04-19 12:08:17'),
(186, 69, 'åtgärd skapad', '2023-04-19 10:08:17', '2023-04-19 12:08:17'),
(187, 70, 'åtgärd skapad', '2023-04-19 10:08:17', '2023-04-19 12:08:17'),
(188, 71, 'åtgärd skapad', '2023-04-19 10:08:29', '2023-04-19 12:08:29'),
(189, 72, 'åtgärd skapad', '2023-04-19 10:08:33', '2023-04-19 12:08:33'),
(190, 73, 'åtgärd skapad', '2023-04-19 10:08:40', '2023-04-19 12:08:40'),
(191, 74, 'åtgärd skapad', '2023-04-19 10:08:40', '2023-04-19 12:08:40'),
(192, 75, 'åtgärd skapad', '2023-04-19 10:08:40', '2023-04-19 12:08:40'),
(193, 68, 'åtgärden startades via WP Cron', '2023-04-19 10:09:09', '2023-04-19 12:09:09'),
(194, 68, 'åtgärden slutförd via WP Cron', '2023-04-19 10:09:09', '2023-04-19 12:09:09'),
(195, 69, 'åtgärden startades via WP Cron', '2023-04-19 10:09:09', '2023-04-19 12:09:09'),
(196, 69, 'åtgärden slutförd via WP Cron', '2023-04-19 10:09:09', '2023-04-19 12:09:09'),
(197, 70, 'åtgärden startades via WP Cron', '2023-04-19 10:09:09', '2023-04-19 12:09:09'),
(198, 70, 'åtgärden slutförd via WP Cron', '2023-04-19 10:09:09', '2023-04-19 12:09:09'),
(199, 71, 'åtgärden startades via WP Cron', '2023-04-19 10:09:09', '2023-04-19 12:09:09'),
(200, 71, 'åtgärden slutförd via WP Cron', '2023-04-19 10:09:09', '2023-04-19 12:09:09') ;
INSERT INTO `wp_actionscheduler_logs` ( `log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(201, 72, 'åtgärden startades via WP Cron', '2023-04-19 10:09:09', '2023-04-19 12:09:09'),
(202, 72, 'åtgärden slutförd via WP Cron', '2023-04-19 10:09:09', '2023-04-19 12:09:09'),
(203, 73, 'åtgärden startades via WP Cron', '2023-04-19 10:09:09', '2023-04-19 12:09:09'),
(204, 73, 'åtgärden slutförd via WP Cron', '2023-04-19 10:09:09', '2023-04-19 12:09:09'),
(205, 74, 'åtgärden startades via WP Cron', '2023-04-19 10:09:09', '2023-04-19 12:09:09'),
(206, 74, 'åtgärden slutförd via WP Cron', '2023-04-19 10:09:09', '2023-04-19 12:09:09'),
(207, 75, 'åtgärden startades via WP Cron', '2023-04-19 10:09:09', '2023-04-19 12:09:09'),
(208, 75, 'åtgärden slutförd via WP Cron', '2023-04-19 10:09:09', '2023-04-19 12:09:09'),
(209, 76, 'åtgärd skapad', '2023-04-19 10:13:53', '2023-04-19 12:13:53'),
(210, 77, 'åtgärd skapad', '2023-04-19 10:13:53', '2023-04-19 12:13:53'),
(211, 78, 'åtgärd skapad', '2023-04-19 10:13:53', '2023-04-19 12:13:53'),
(212, 79, 'åtgärd skapad', '2023-04-19 10:13:53', '2023-04-19 12:13:53'),
(213, 76, 'åtgärden startades via WP Cron', '2023-04-19 10:14:10', '2023-04-19 12:14:10'),
(214, 76, 'åtgärden slutförd via WP Cron', '2023-04-19 10:14:10', '2023-04-19 12:14:10'),
(215, 77, 'åtgärden startades via WP Cron', '2023-04-19 10:14:10', '2023-04-19 12:14:10'),
(216, 77, 'åtgärden slutförd via WP Cron', '2023-04-19 10:14:10', '2023-04-19 12:14:10'),
(217, 78, 'åtgärden startades via WP Cron', '2023-04-19 10:14:10', '2023-04-19 12:14:10'),
(218, 78, 'åtgärden slutförd via WP Cron', '2023-04-19 10:14:10', '2023-04-19 12:14:10'),
(219, 79, 'åtgärden startades via WP Cron', '2023-04-19 10:14:10', '2023-04-19 12:14:10'),
(220, 79, 'åtgärden slutförd via WP Cron', '2023-04-19 10:14:10', '2023-04-19 12:14:10'),
(221, 80, 'åtgärd skapad', '2023-04-19 10:14:52', '2023-04-19 12:14:52'),
(222, 80, 'åtgärden startades via WP Cron', '2023-04-19 10:15:09', '2023-04-19 12:15:09'),
(223, 80, 'åtgärden slutförd via WP Cron', '2023-04-19 10:15:09', '2023-04-19 12:15:09'),
(224, 81, 'åtgärd skapad', '2023-04-19 10:15:09', '2023-04-19 12:15:09'),
(225, 82, 'åtgärd skapad', '2023-04-19 10:15:09', '2023-04-19 12:15:09'),
(226, 81, 'åtgärden startades via Async Request', '2023-04-19 10:16:01', '2023-04-19 12:16:01'),
(227, 81, 'åtgärden slutförd via Async Request', '2023-04-19 10:16:01', '2023-04-19 12:16:01'),
(228, 82, 'åtgärden startades via Async Request', '2023-04-19 10:16:01', '2023-04-19 12:16:01'),
(229, 82, 'åtgärden slutförd via Async Request', '2023-04-19 10:16:01', '2023-04-19 12:16:01'),
(230, 83, 'åtgärd skapad', '2023-04-19 12:10:49', '2023-04-19 14:10:49'),
(231, 83, 'åtgärden startades via WP Cron', '2023-04-19 12:11:09', '2023-04-19 14:11:09'),
(232, 83, 'åtgärden slutförd via WP Cron', '2023-04-19 12:11:09', '2023-04-19 14:11:09'),
(233, 84, 'åtgärd skapad', '2023-04-19 12:18:18', '2023-04-19 14:18:18'),
(234, 84, 'åtgärden startades via WP Cron', '2023-04-19 12:19:05', '2023-04-19 14:19:05'),
(235, 84, 'åtgärden slutförd via WP Cron', '2023-04-19 12:19:05', '2023-04-19 14:19:05'),
(236, 8, 'åtgärden startades via WP Cron', '2023-04-20 09:22:13', '2023-04-20 11:22:13'),
(237, 8, 'åtgärden slutförd via WP Cron', '2023-04-20 09:22:13', '2023-04-20 11:22:13'),
(238, 85, 'åtgärd skapad', '2023-04-20 09:22:13', '2023-04-20 11:22:13'),
(239, 86, 'åtgärd skapad', '2023-04-20 12:58:10', '2023-04-20 14:58:10'),
(240, 86, 'åtgärden startades via WP Cron', '2023-04-20 12:59:04', '2023-04-20 14:59:04'),
(241, 86, 'åtgärden slutförd via WP Cron', '2023-04-20 12:59:04', '2023-04-20 14:59:04'),
(242, 87, 'åtgärd skapad', '2023-04-20 13:56:52', '2023-04-20 15:56:52'),
(243, 88, 'åtgärd skapad', '2023-04-20 13:56:52', '2023-04-20 15:56:52'),
(244, 87, 'åtgärden startades via WP Cron', '2023-04-20 13:57:03', '2023-04-20 15:57:03'),
(245, 87, 'åtgärden slutförd via WP Cron', '2023-04-20 13:57:04', '2023-04-20 15:57:04'),
(246, 88, 'åtgärden startades via WP Cron', '2023-04-20 13:57:04', '2023-04-20 15:57:04'),
(247, 88, 'åtgärden slutförd via WP Cron', '2023-04-20 13:57:04', '2023-04-20 15:57:04'),
(248, 89, 'åtgärd skapad', '2023-04-20 13:58:18', '2023-04-20 15:58:18'),
(249, 90, 'åtgärd skapad', '2023-04-20 13:58:22', '2023-04-20 15:58:22'),
(250, 89, 'åtgärden startades via WP Cron', '2023-04-20 14:02:25', '2023-04-20 16:02:25'),
(251, 89, 'åtgärden slutförd via WP Cron', '2023-04-20 14:02:25', '2023-04-20 16:02:25'),
(252, 90, 'åtgärden startades via WP Cron', '2023-04-20 14:02:25', '2023-04-20 16:02:25'),
(253, 90, 'åtgärden slutförd via WP Cron', '2023-04-20 14:02:25', '2023-04-20 16:02:25'),
(254, 91, 'åtgärd skapad', '2023-04-21 09:12:51', '2023-04-21 11:12:51'),
(255, 91, 'åtgärden startades via WP Cron', '2023-04-21 09:13:51', '2023-04-21 11:13:51'),
(256, 91, 'åtgärden slutförd via WP Cron', '2023-04-21 09:13:52', '2023-04-21 11:13:52'),
(257, 92, 'åtgärd skapad', '2023-04-21 09:13:52', '2023-04-21 11:13:52'),
(258, 92, 'åtgärden startades via WP Cron', '2023-04-21 09:15:04', '2023-04-21 11:15:04'),
(259, 92, 'åtgärden misslyckades via WP Cron: Den schemalagda åtgärden för action_scheduler/migration_hook kommer inte att utföras eftersom inga återanrop har registrerats.', '2023-04-21 09:15:04', '2023-04-21 11:15:04'),
(260, 85, 'åtgärden startades via WP Cron', '2023-04-21 09:25:46', '2023-04-21 11:25:46'),
(261, 85, 'åtgärden slutförd via WP Cron', '2023-04-21 09:25:46', '2023-04-21 11:25:46'),
(262, 93, 'åtgärd skapad', '2023-04-21 09:25:46', '2023-04-21 11:25:46'),
(263, 93, 'åtgärden startades via WP Cron', '2023-04-23 17:59:08', '2023-04-23 19:59:08'),
(264, 93, 'åtgärden slutförd via WP Cron', '2023-04-23 17:59:09', '2023-04-23 19:59:09'),
(265, 94, 'åtgärd skapad', '2023-04-23 17:59:09', '2023-04-23 19:59:09'),
(266, 95, 'åtgärd skapad', '2023-04-23 19:35:10', '2023-04-23 21:35:10'),
(267, 95, 'åtgärden startades via WP Cron', '2023-04-23 19:36:29', '2023-04-23 21:36:29'),
(268, 95, 'åtgärden slutförd via WP Cron', '2023-04-23 19:36:30', '2023-04-23 21:36:30'),
(269, 96, 'åtgärd skapad', '2023-04-23 19:41:17', '2023-04-23 21:41:17'),
(270, 96, 'åtgärden startades via WP Cron', '2023-04-24 12:47:16', '2023-04-24 14:47:16'),
(271, 96, 'åtgärden slutförd via WP Cron', '2023-04-24 12:47:16', '2023-04-24 14:47:16') ;

#
# End of data contents of table `wp_actionscheduler_logs`
# --------------------------------------------------------



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10)),
  KEY `woo_idx_comment_type` (`comment_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'En kommentarsförfattare', 'wapuu@wordpress.example', 'https://sv.wordpress.org/', '', '2023-04-19 09:26:53', '2023-04-19 07:26:53', 'Hej, det här är en kommentar.\nFör att komma igång med granskning, redigering och borttagning av kommentarer, gå till vyn ”Kommentarer” i adminpanelen.\nKommentarsförfattares profilbilder kommer från <a href="https://sv.gravatar.com/">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=1859 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/labb2-carolina', 'yes'),
(2, 'home', 'http://localhost/labb2-carolina', 'yes'),
(3, 'blogname', 'Labb2-carolina', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'henrikutbildare@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'j F Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'Y-m-d H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:159:{s:24:"^wc-auth/v([1]{1})/(.*)?";s:63:"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]";s:22:"^wc-api/v([1-3]{1})/?$";s:51:"index.php?wc-api-version=$matches[1]&wc-api-route=/";s:24:"^wc-api/v([1-3]{1})(.*)?";s:61:"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]";s:8:"butik/?$";s:27:"index.php?post_type=product";s:38:"butik/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:33:"butik/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:25:"butik/page/([0-9]{1,})/?$";s:45:"index.php?post_type=product&paged=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:32:"category/(.+?)/wc-api(/(.*))?/?$";s:54:"index.php?category_name=$matches[1]&wc-api=$matches[3]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:29:"tag/([^/]+)/wc-api(/(.*))?/?$";s:44:"index.php?tag=$matches[1]&wc-api=$matches[3]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:55:"produkt-kategori/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:50:"produkt-kategori/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:31:"produkt-kategori/(.+?)/embed/?$";s:44:"index.php?product_cat=$matches[1]&embed=true";s:43:"produkt-kategori/(.+?)/page/?([0-9]{1,})/?$";s:51:"index.php?product_cat=$matches[1]&paged=$matches[2]";s:25:"produkt-kategori/(.+?)/?$";s:33:"index.php?product_cat=$matches[1]";s:55:"produktetikett/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:50:"produktetikett/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:31:"produktetikett/([^/]+)/embed/?$";s:44:"index.php?product_tag=$matches[1]&embed=true";s:43:"produktetikett/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?product_tag=$matches[1]&paged=$matches[2]";s:25:"produktetikett/([^/]+)/?$";s:33:"index.php?product_tag=$matches[1]";s:35:"produkt/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"produkt/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"produkt/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"produkt/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"produkt/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"produkt/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"produkt/([^/]+)/embed/?$";s:40:"index.php?product=$matches[1]&embed=true";s:28:"produkt/([^/]+)/trackback/?$";s:34:"index.php?product=$matches[1]&tb=1";s:48:"produkt/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:43:"produkt/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:36:"produkt/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&paged=$matches[2]";s:43:"produkt/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&cpage=$matches[2]";s:33:"produkt/([^/]+)/wc-api(/(.*))?/?$";s:48:"index.php?product=$matches[1]&wc-api=$matches[3]";s:39:"produkt/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:50:"produkt/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:32:"produkt/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?product=$matches[1]&page=$matches[2]";s:24:"produkt/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"produkt/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"produkt/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"produkt/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"produkt/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"produkt/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=6&cpage=$matches[1]";s:17:"wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:26:"comments/wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:29:"search/(.+)/wc-api(/(.*))?/?$";s:42:"index.php?s=$matches[1]&wc-api=$matches[3]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:32:"author/([^/]+)/wc-api(/(.*))?/?$";s:52:"index.php?author_name=$matches[1]&wc-api=$matches[3]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:54:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:82:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:41:"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:66:"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:28:"([0-9]{4})/wc-api(/(.*))?/?$";s:45:"index.php?year=$matches[1]&wc-api=$matches[3]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:25:"(.?.+?)/wc-api(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&wc-api=$matches[3]";s:28:"(.?.+?)/order-pay(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&order-pay=$matches[3]";s:33:"(.?.+?)/order-received(/(.*))?/?$";s:57:"index.php?pagename=$matches[1]&order-received=$matches[3]";s:25:"(.?.+?)/orders(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&orders=$matches[3]";s:29:"(.?.+?)/view-order(/(.*))?/?$";s:53:"index.php?pagename=$matches[1]&view-order=$matches[3]";s:28:"(.?.+?)/downloads(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&downloads=$matches[3]";s:31:"(.?.+?)/edit-account(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-account=$matches[3]";s:31:"(.?.+?)/edit-address(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-address=$matches[3]";s:34:"(.?.+?)/payment-methods(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&payment-methods=$matches[3]";s:32:"(.?.+?)/lost-password(/(.*))?/?$";s:56:"index.php?pagename=$matches[1]&lost-password=$matches[3]";s:34:"(.?.+?)/customer-logout(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&customer-logout=$matches[3]";s:37:"(.?.+?)/add-payment-method(/(.*))?/?$";s:61:"index.php?pagename=$matches[1]&add-payment-method=$matches[3]";s:40:"(.?.+?)/delete-payment-method(/(.*))?/?$";s:64:"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]";s:45:"(.?.+?)/set-default-payment-method(/(.*))?/?$";s:69:"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]";s:31:".?.+?/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:25:"([^/]+)/wc-api(/(.*))?/?$";s:45:"index.php?name=$matches[1]&wc-api=$matches[3]";s:31:"[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:"[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:3:{i:0;s:29:"labb2-plugin/labb2-plugin.php";i:1;s:27:"woocommerce/woocommerce.php";i:2;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'storefront', 'yes'),
(41, 'stylesheet', 'storefront-child', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '53496', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '0', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', 'Europe/Stockholm', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '6', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1697441213', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '53496', 'yes'),
(100, 'wp_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:114:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:8:"customer";a:2:{s:4:"name";s:8:"Customer";s:12:"capabilities";a:1:{s:4:"read";b:1;}}s:12:"shop_manager";a:2:{s:4:"name";s:12:"Shop manager";s:12:"capabilities";a:92:{s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:4:"read";b:1;s:18:"read_private_pages";b:1;s:18:"read_private_posts";b:1;s:10:"edit_posts";b:1;s:10:"edit_pages";b:1;s:20:"edit_published_posts";b:1;s:20:"edit_published_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"edit_private_posts";b:1;s:17:"edit_others_posts";b:1;s:17:"edit_others_pages";b:1;s:13:"publish_posts";b:1;s:13:"publish_pages";b:1;s:12:"delete_posts";b:1;s:12:"delete_pages";b:1;s:20:"delete_private_pages";b:1;s:20:"delete_private_posts";b:1;s:22:"delete_published_pages";b:1;s:22:"delete_published_posts";b:1;s:19:"delete_others_posts";b:1;s:19:"delete_others_pages";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:17:"moderate_comments";b:1;s:12:"upload_files";b:1;s:6:"export";b:1;s:6:"import";b:1;s:10:"list_users";b:1;s:18:"edit_theme_options";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;}}}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'fresh_site', '0', 'yes'),
(102, 'WPLANG', 'sv_SE', 'yes'),
(103, 'user_count', '1', 'no'),
(104, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:159:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Senaste inläggen</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:231:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Senaste kommentarer</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:143:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Arkiv</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Kategorier</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'sidebars_widgets', 'a:8:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:8:"header-1";a:0:{}s:8:"footer-1";a:0:{}s:8:"footer-2";a:0:{}s:8:"footer-3";a:0:{}s:8:"footer-4";a:0:{}s:13:"array_version";i:3;}', 'yes'),
(106, 'cron', 'a:18:{i:1682349362;a:1:{s:26:"action_scheduler_run_queue";a:1:{s:32:"0d04ed39571b55704c122d726248bbac";a:3:{s:8:"schedule";s:12:"every_minute";s:4:"args";a:1:{i:0;s:7:"WP Cron";}s:8:"interval";i:60;}}}i:1682350014;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1682350805;a:1:{s:33:"wc_admin_process_orders_milestone";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1682350812;a:1:{s:29:"wc_admin_unsnooze_admin_notes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1682351349;a:1:{s:32:"woocommerce_cancel_unpaid_orders";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1682364414;a:4:{s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1682364429;a:1:{s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1682373600;a:1:{s:27:"woocommerce_scheduled_sales";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1682386804;a:1:{s:28:"woocommerce_cleanup_sessions";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1682407614;a:1:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1682407629;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1682407630;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1682408404;a:1:{s:14:"wc_admin_daily";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1682408414;a:2:{s:33:"woocommerce_cleanup_personal_data";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:30:"woocommerce_tracker_send_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1682419204;a:2:{s:24:"woocommerce_cleanup_logs";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:31:"woocommerce_cleanup_rate_limits";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1682580414;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1683186064;a:1:{s:25:"woocommerce_geoip_updater";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:11:"fifteendays";s:4:"args";a:0:{}s:8:"interval";i:1296000;}}}s:7:"version";i:2;}', 'yes'),
(107, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(118, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(120, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(122, 'recovery_keys', 'a:1:{s:22:"XGjjZOUXxwV4Fe82uKfXFx";a:2:{s:10:"hashed_key";s:34:"$P$BoFSjUjLpZ5ZFJPm862KxVf/yOBKCo.";s:10:"created_at";i:1682345364;}}', 'yes'),
(123, 'theme_mods_twentytwentythree', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1681890401;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(124, 'https_detection_errors', 'a:1:{s:20:"https_request_failed";a:1:{i:0;s:28:"HTTPS-begäran misslyckades.";}}', 'yes'),
(141, 'can_compress_scripts', '0', 'no'),
(156, 'finished_updating_comment_type', '1', 'yes'),
(157, 'recently_activated', 'a:1:{s:29:"labb2-plugin/labb2-plugin.php";i:1682278877;}', 'yes'),
(164, 'action_scheduler_hybrid_store_demarkation', '5', 'yes'),
(165, 'schema-ActionScheduler_StoreSchema', '6.0.1681890002', 'yes'),
(166, 'schema-ActionScheduler_LoggerSchema', '3.0.1681890002', 'yes'),
(169, 'woocommerce_schema_version', '430', 'yes'),
(170, 'woocommerce_store_address', 'Någon Gata 1337', 'yes'),
(171, 'woocommerce_store_address_2', '', 'yes'),
(172, 'woocommerce_store_city', 'Någonstans', 'yes'),
(173, 'woocommerce_default_country', 'SE', 'yes'),
(174, 'woocommerce_store_postcode', '66666', 'yes'),
(175, 'woocommerce_allowed_countries', 'all', 'yes'),
(176, 'woocommerce_all_except_countries', 'a:0:{}', 'yes'),
(177, 'woocommerce_specific_allowed_countries', 'a:0:{}', 'yes'),
(178, 'woocommerce_ship_to_countries', '', 'yes'),
(179, 'woocommerce_specific_ship_to_countries', 'a:0:{}', 'yes'),
(180, 'woocommerce_default_customer_address', 'base', 'yes'),
(181, 'woocommerce_calc_taxes', 'yes', 'yes'),
(182, 'woocommerce_enable_coupons', 'yes', 'yes'),
(183, 'woocommerce_calc_discounts_sequentially', 'no', 'no'),
(184, 'woocommerce_currency', 'SEK', 'yes'),
(185, 'woocommerce_currency_pos', 'right_space', 'yes'),
(186, 'woocommerce_price_thousand_sep', '', 'yes'),
(187, 'woocommerce_price_decimal_sep', ',', 'yes'),
(188, 'woocommerce_price_num_decimals', '0', 'yes'),
(189, 'woocommerce_shop_page_id', '6', 'yes'),
(190, 'woocommerce_cart_redirect_after_add', 'no', 'yes'),
(191, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes'),
(192, 'woocommerce_placeholder_image', '5', 'yes'),
(193, 'woocommerce_weight_unit', 'kg', 'yes'),
(194, 'woocommerce_dimension_unit', 'cm', 'yes'),
(195, 'woocommerce_enable_reviews', 'yes', 'yes'),
(196, 'woocommerce_review_rating_verification_label', 'yes', 'no'),
(197, 'woocommerce_review_rating_verification_required', 'no', 'no'),
(198, 'woocommerce_enable_review_rating', 'yes', 'yes'),
(199, 'woocommerce_review_rating_required', 'yes', 'no'),
(200, 'woocommerce_manage_stock', 'yes', 'yes'),
(201, 'woocommerce_hold_stock_minutes', '60', 'no'),
(202, 'woocommerce_notify_low_stock', 'yes', 'no'),
(203, 'woocommerce_notify_no_stock', 'yes', 'no'),
(204, 'woocommerce_stock_email_recipient', 'henrikutbildare@gmail.com', 'no'),
(205, 'woocommerce_notify_low_stock_amount', '2', 'no'),
(206, 'woocommerce_notify_no_stock_amount', '0', 'yes'),
(207, 'woocommerce_hide_out_of_stock_items', 'no', 'yes'),
(208, 'woocommerce_stock_format', '', 'yes'),
(209, 'woocommerce_file_download_method', 'force', 'no'),
(210, 'woocommerce_downloads_redirect_fallback_allowed', 'no', 'no'),
(211, 'woocommerce_downloads_require_login', 'no', 'no'),
(212, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no'),
(213, 'woocommerce_downloads_deliver_inline', '', 'no'),
(214, 'woocommerce_downloads_add_hash_to_filename', 'yes', 'yes'),
(215, 'woocommerce_attribute_lookup_enabled', 'no', 'yes'),
(216, 'woocommerce_attribute_lookup_direct_updates', 'no', 'yes'),
(217, 'woocommerce_prices_include_tax', 'yes', 'yes'),
(218, 'woocommerce_tax_based_on', 'shipping', 'yes'),
(219, 'woocommerce_shipping_tax_class', 'inherit', 'yes'),
(220, 'woocommerce_tax_round_at_subtotal', 'no', 'yes'),
(221, 'woocommerce_tax_classes', '', 'yes'),
(222, 'woocommerce_tax_display_shop', 'incl', 'yes'),
(223, 'woocommerce_tax_display_cart', 'incl', 'yes'),
(224, 'woocommerce_price_display_suffix', '', 'yes'),
(225, 'woocommerce_tax_total_display', 'itemized', 'no'),
(226, 'woocommerce_enable_shipping_calc', 'yes', 'no'),
(227, 'woocommerce_shipping_cost_requires_address', 'no', 'yes'),
(228, 'woocommerce_ship_to_destination', 'billing', 'no'),
(229, 'woocommerce_shipping_debug_mode', 'no', 'yes'),
(230, 'woocommerce_enable_guest_checkout', 'yes', 'no'),
(231, 'woocommerce_enable_checkout_login_reminder', 'no', 'no'),
(232, 'woocommerce_enable_signup_and_login_from_checkout', 'no', 'no'),
(233, 'woocommerce_enable_myaccount_registration', 'no', 'no'),
(234, 'woocommerce_registration_generate_username', 'yes', 'no'),
(235, 'woocommerce_registration_generate_password', 'yes', 'no'),
(236, 'woocommerce_erasure_request_removes_order_data', 'no', 'no'),
(237, 'woocommerce_erasure_request_removes_download_data', 'no', 'no'),
(238, 'woocommerce_allow_bulk_remove_personal_data', 'no', 'no'),
(239, 'woocommerce_registration_privacy_policy_text', 'Dina personuppgifter kommer användas för att förbättra din upplevelse på webbplatsen, hantera åtkomst till ditt konto och för andra ändamål som beskrivs i vår [privacy_policy].', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(240, 'woocommerce_checkout_privacy_policy_text', 'Dina personuppgifter kommer användas för att behandla din beställning, förbättra din upplevelse på webbplatsen och för andra ändamål som beskrivs i vår [privacy_policy].', 'yes'),
(241, 'woocommerce_delete_inactive_accounts', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:6:"months";}', 'no'),
(242, 'woocommerce_trash_pending_orders', '', 'no'),
(243, 'woocommerce_trash_failed_orders', '', 'no'),
(244, 'woocommerce_trash_cancelled_orders', '', 'no'),
(245, 'woocommerce_anonymize_completed_orders', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:6:"months";}', 'no'),
(246, 'woocommerce_email_from_name', 'Labb2-carolina', 'no'),
(247, 'woocommerce_email_from_address', 'henrikutbildare@gmail.com', 'no'),
(248, 'woocommerce_email_header_image', '', 'no'),
(249, 'woocommerce_email_footer_text', '{site_title} &mdash; Built with {WooCommerce}', 'no'),
(250, 'woocommerce_email_base_color', '#7f54b3', 'no'),
(251, 'woocommerce_email_background_color', '#f7f7f7', 'no'),
(252, 'woocommerce_email_body_background_color', '#ffffff', 'no'),
(253, 'woocommerce_email_text_color', '#3c3c3c', 'no'),
(254, 'woocommerce_merchant_email_notifications', 'no', 'no'),
(255, 'woocommerce_cart_page_id', '7', 'no'),
(256, 'woocommerce_checkout_page_id', '8', 'no'),
(257, 'woocommerce_myaccount_page_id', '9', 'no'),
(258, 'woocommerce_terms_page_id', '', 'no'),
(259, 'woocommerce_force_ssl_checkout', 'no', 'yes'),
(260, 'woocommerce_unforce_ssl_checkout', 'no', 'yes'),
(261, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes'),
(262, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes'),
(263, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes'),
(264, 'woocommerce_myaccount_delete_payment_method_endpoint', 'delete-payment-method', 'yes'),
(265, 'woocommerce_myaccount_set_default_payment_method_endpoint', 'set-default-payment-method', 'yes'),
(266, 'woocommerce_myaccount_orders_endpoint', 'orders', 'yes'),
(267, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes'),
(268, 'woocommerce_myaccount_downloads_endpoint', 'downloads', 'yes'),
(269, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes'),
(270, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes'),
(271, 'woocommerce_myaccount_payment_methods_endpoint', 'payment-methods', 'yes'),
(272, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes'),
(273, 'woocommerce_logout_endpoint', 'customer-logout', 'yes'),
(274, 'woocommerce_api_enabled', 'no', 'yes'),
(275, 'woocommerce_allow_tracking', 'no', 'no'),
(276, 'woocommerce_show_marketplace_suggestions', 'yes', 'no'),
(277, 'woocommerce_analytics_enabled', 'yes', 'yes'),
(278, 'woocommerce_navigation_enabled', 'no', 'yes'),
(279, 'woocommerce_new_product_management_enabled', 'no', 'yes'),
(280, 'woocommerce_feature_custom_order_tables_enabled', 'no', 'yes'),
(281, 'woocommerce_single_image_width', '600', 'yes'),
(282, 'woocommerce_thumbnail_image_width', '300', 'yes'),
(283, 'woocommerce_checkout_highlight_required_fields', 'yes', 'yes'),
(284, 'woocommerce_demo_store', 'no', 'no'),
(285, 'wc_downloads_approved_directories_mode', 'enabled', 'yes'),
(286, 'woocommerce_permalinks', 'a:5:{s:12:"product_base";s:8:"/produkt";s:13:"category_base";s:16:"produkt-kategori";s:8:"tag_base";s:14:"produktetikett";s:14:"attribute_base";s:0:"";s:22:"use_verbose_page_rules";b:0;}', 'yes'),
(287, 'current_theme_supports_woocommerce', 'yes', 'yes'),
(288, 'woocommerce_queue_flush_rewrite_rules', 'no', 'yes'),
(291, 'default_product_cat', '15', 'yes'),
(292, 'woocommerce_refund_returns_page_id', '10', 'yes'),
(295, 'woocommerce_paypal_settings', 'a:23:{s:7:"enabled";s:2:"no";s:5:"title";s:6:"PayPal";s:11:"description";s:69:"Betala via PayPal; du kan betala med ditt kort utan ett PayPal-konto.";s:5:"email";s:25:"henrikutbildare@gmail.com";s:8:"advanced";s:0:"";s:8:"testmode";s:2:"no";s:5:"debug";s:2:"no";s:16:"ipn_notification";s:3:"yes";s:14:"receiver_email";s:25:"henrikutbildare@gmail.com";s:14:"identity_token";s:0:"";s:14:"invoice_prefix";s:3:"WC-";s:13:"send_shipping";s:3:"yes";s:16:"address_override";s:2:"no";s:13:"paymentaction";s:4:"sale";s:9:"image_url";s:0:"";s:11:"api_details";s:0:"";s:12:"api_username";s:0:"";s:12:"api_password";s:0:"";s:13:"api_signature";s:0:"";s:20:"sandbox_api_username";s:0:"";s:20:"sandbox_api_password";s:0:"";s:21:"sandbox_api_signature";s:0:"";s:12:"_should_load";s:2:"no";}', 'yes'),
(296, 'woocommerce_version', '7.6.0', 'yes'),
(297, 'woocommerce_db_version', '7.6.0', 'yes'),
(298, 'woocommerce_admin_install_timestamp', '1681890004', 'yes'),
(299, 'woocommerce_inbox_variant_assignment', '4', 'yes'),
(304, 'action_scheduler_lock_async-request-runner', '1682349320', 'yes'),
(305, 'woocommerce_admin_notices', 'a:1:{i:0;s:20:"no_secure_connection";}', 'yes'),
(306, 'woocommerce_maxmind_geolocation_settings', 'a:1:{s:15:"database_prefix";s:32:"GbKLwLokJhmXhfPTBQajqoG54oKnjw0u";}', 'yes'),
(308, 'widget_woocommerce_widget_cart', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(309, 'widget_woocommerce_layered_nav_filters', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(310, 'widget_woocommerce_layered_nav', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(311, 'widget_woocommerce_price_filter', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(312, 'widget_woocommerce_product_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(313, 'widget_woocommerce_product_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(314, 'widget_woocommerce_product_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(315, 'widget_woocommerce_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(316, 'widget_woocommerce_recently_viewed_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(317, 'widget_woocommerce_top_rated_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(318, 'widget_woocommerce_recent_reviews', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(319, 'widget_woocommerce_rating_filter', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(333, 'wc_remote_inbox_notifications_stored_state', 'O:8:"stdClass":2:{s:22:"there_were_no_products";b:1;s:22:"there_are_now_products";b:1;}', 'no'),
(334, 'wc_blocks_db_schema_version', '260', 'yes'),
(348, 'woocommerce_task_list_tracked_completed_tasks', 'a:7:{i:0;s:8:"purchase";i:1;s:13:"store_details";i:2;s:8:"shipping";i:3;s:8:"products";i:4;s:15:"review-shipping";i:5;s:3:"tax";i:6;s:8:"payments";}', 'yes'),
(362, 'woocommerce_onboarding_profile', 'a:11:{s:18:"is_agree_marketing";b:0;s:11:"store_email";s:35:"carolinaisabellaandersson@gmail.com";s:20:"is_store_country_set";b:1;s:8:"industry";a:2:{i:0;a:1:{s:4:"slug";s:27:"fashion-apparel-accessories";}i:1;a:1:{s:4:"slug";s:13:"health-beauty";}}s:13:"product_types";a:2:{i:0;s:8:"physical";i:1;s:9:"downloads";}s:13:"product_count";s:4:"1-10";s:14:"selling_venues";s:2:"no";s:19:"business_extensions";a:0:{}s:12:"setup_client";b:0;s:5:"theme";s:10:"storefront";s:9:"completed";b:1;}', 'yes'),
(364, 'woocommerce_task_list_dismissed_tasks', 'a:0:{}', 'yes'),
(371, 'current_theme', 'Storefront-ChildTheme', 'yes'),
(372, 'theme_switched', '', 'yes'),
(373, 'theme_mods_storefront', 'a:3:{s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1682277740;s:4:"data";a:7:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:8:"header-1";a:0:{}s:8:"footer-1";a:0:{}s:8:"footer-2";a:0:{}s:8:"footer-3";a:0:{}s:8:"footer-4";a:0:{}}}}', 'yes'),
(374, 'woocommerce_catalog_rows', '4', 'yes'),
(375, 'woocommerce_catalog_columns', '3', 'yes'),
(376, 'woocommerce_maybe_regenerate_images_hash', '27acde77266b4d2a3491118955cb3f66', 'yes'),
(378, 'storefront_nux_fresh_site', '0', 'yes'),
(388, 'woocommerce_admin_created_default_shipping_zones', 'yes', 'yes'),
(390, 'woocommerce_task_list_prompt_shown', '1', 'yes'),
(442, 'woocommerce_ces_product_feedback_shown', '1', 'yes'),
(846, 'product_cat_children', 'a:2:{i:22;a:2:{i:0;i:24;i:1;i:25;}i:23;a:2:{i:0;i:26;i:1;i:27;}}', 'yes'),
(880, 'storefront_nux_guided_tour', '1', 'yes'),
(884, 'theme_mods_storefront-child', 'a:3:{s:18:"custom_css_post_id";i:-1;s:18:"nav_menu_locations";a:1:{s:9:"undermeny";i:37;}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1682277704;s:4:"data";a:7:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:8:"header-1";a:0:{}s:8:"footer-1";a:0:{}s:8:"footer-2";a:0:{}s:8:"footer-3";a:0:{}s:8:"footer-4";a:0:{}}}}', 'yes'),
(980, 'woocommerce_admin_reviewed_default_shipping_zones', 'yes', 'yes'),
(1030, 'woocommerce_free_shipping_4_settings', 'a:4:{s:5:"title";s:9:"Fri frakt";s:8:"requires";s:10:"min_amount";s:10:"min_amount";s:3:"299";s:16:"ignore_discounts";s:2:"no";}', 'yes'),
(1051, 'woocommerce_flat_rate_7_settings', 'a:8:{s:5:"title";s:9:"Fast pris";s:10:"tax_status";s:7:"taxable";s:4:"cost";s:2:"49";s:11:"class_costs";s:0:"";s:13:"class_cost_37";s:1:"0";s:13:"class_cost_36";s:2:"79";s:13:"no_class_cost";s:0:"";s:4:"type";s:5:"order";}', 'yes'),
(1209, 'woocommerce_cod_settings', 'a:6:{s:7:"enabled";s:3:"yes";s:5:"title";s:19:"Betala vid leverans";s:11:"description";s:28:"Betala kontant vid leverans.";s:12:"instructions";s:28:"Betala kontant vid leverans.";s:18:"enable_for_methods";a:0:{}s:18:"enable_for_virtual";s:3:"yes";}', 'yes'),
(1210, 'woocommerce_gateway_order', 'a:3:{s:4:"bacs";i:0;s:6:"cheque";i:1;s:3:"cod";i:2;}', 'yes'),
(1265, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(1625, 'action_scheduler_migration_status', 'complete', 'yes'),
(1787, 'recovery_mode_email_last_sent', '1682345364', 'yes'),
(1834, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1682349352;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=517 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_wp_attached_file', 'woocommerce-placeholder.png'),
(4, 5, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1200;s:6:"height";i:1200;s:4:"file";s:27:"woocommerce-placeholder.png";s:8:"filesize";i:102644;s:5:"sizes";a:7:{s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:35:"woocommerce-placeholder-324x324.png";s:5:"width";i:324;s:6:"height";i:324;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:28117;s:9:"uncropped";b:0;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:35:"woocommerce-placeholder-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:2314;}s:18:"woocommerce_single";a:5:{s:4:"file";s:35:"woocommerce-placeholder-416x416.png";s:5:"width";i:416;s:6:"height";i:416;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:46064;}s:6:"medium";a:5:{s:4:"file";s:35:"woocommerce-placeholder-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:12560;}s:5:"large";a:5:{s:4:"file";s:37:"woocommerce-placeholder-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:92182;}s:9:"thumbnail";a:5:{s:4:"file";s:35:"woocommerce-placeholder-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:4228;}s:12:"medium_large";a:5:{s:4:"file";s:35:"woocommerce-placeholder-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:58715;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(5, 11, '_wp_attached_file', '2023/04/hoodie-with-logo-2.jpg'),
(6, 11, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:801;s:6:"height";i:801;s:4:"file";s:30:"2023/04/hoodie-with-logo-2.jpg";s:8:"filesize";i:46969;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:30:"hoodie-with-logo-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8271;}s:9:"thumbnail";a:5:{s:4:"file";s:30:"hoodie-with-logo-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3125;}s:12:"medium_large";a:5:{s:4:"file";s:30:"hoodie-with-logo-2-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:30256;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:30:"hoodie-with-logo-2-324x324.jpg";s:5:"width";i:324;s:6:"height";i:324;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9250;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:30:"hoodie-with-logo-2-416x416.jpg";s:5:"width";i:416;s:6:"height";i:416;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:13136;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:30:"hoodie-with-logo-2-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1920;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(7, 11, '_wc_attachment_source', 'https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/hoodie-with-logo-2.jpg'),
(8, 12, '_regular_price', '45'),
(9, 12, 'total_sales', '0'),
(10, 12, '_tax_status', 'taxable'),
(11, 12, '_tax_class', ''),
(12, 12, '_manage_stock', 'no'),
(13, 12, '_backorders', 'no'),
(14, 12, '_sold_individually', 'no'),
(15, 12, '_virtual', 'no'),
(16, 12, '_downloadable', 'no'),
(17, 12, '_download_limit', '0'),
(18, 12, '_download_expiry', '0'),
(19, 12, '_thumbnail_id', '11'),
(20, 12, '_stock', NULL),
(21, 12, '_stock_status', 'instock'),
(22, 12, '_wc_average_rating', '0'),
(23, 12, '_wc_review_count', '0'),
(24, 12, '_product_attributes', 'a:1:{s:8:"pa_color";a:6:{s:4:"name";s:8:"pa_color";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}}'),
(25, 12, '_product_version', '7.6.0'),
(26, 12, '_price', '45'),
(27, 12, '_wpcom_is_markdown', '1'),
(28, 12, '_edit_lock', '1681891438:1'),
(31, 14, '_wp_attached_file', '2023/04/handel_2kg.png'),
(32, 14, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1400;s:6:"height";i:1400;s:4:"file";s:22:"2023/04/handel_2kg.png";s:8:"filesize";i:535037;s:5:"sizes";a:7:{s:6:"medium";a:5:{s:4:"file";s:22:"handel_2kg-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:39799;}s:5:"large";a:5:{s:4:"file";s:24:"handel_2kg-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:324232;}s:9:"thumbnail";a:5:{s:4:"file";s:22:"handel_2kg-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:12402;}s:12:"medium_large";a:5:{s:4:"file";s:22:"handel_2kg-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:307459;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:22:"handel_2kg-324x324.png";s:5:"width";i:324;s:6:"height";i:324;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:64512;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:22:"handel_2kg-416x416.png";s:5:"width";i:416;s:6:"height";i:416;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:98816;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:22:"handel_2kg-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:6027;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(33, 15, '_wp_attached_file', '2023/04/hantel_4kg.png'),
(34, 15, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1400;s:6:"height";i:1400;s:4:"file";s:22:"2023/04/hantel_4kg.png";s:8:"filesize";i:504002;s:5:"sizes";a:7:{s:6:"medium";a:5:{s:4:"file";s:22:"hantel_4kg-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:41002;}s:5:"large";a:5:{s:4:"file";s:24:"hantel_4kg-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:308611;}s:9:"thumbnail";a:5:{s:4:"file";s:22:"hantel_4kg-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:13241;}s:12:"medium_large";a:5:{s:4:"file";s:22:"hantel_4kg-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:299992;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:22:"hantel_4kg-324x324.png";s:5:"width";i:324;s:6:"height";i:324;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:64369;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:22:"hantel_4kg-416x416.png";s:5:"width";i:416;s:6:"height";i:416;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:98422;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:22:"hantel_4kg-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:6403;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(35, 16, '_wp_attached_file', '2023/04/hantel_5kg.png'),
(36, 16, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1400;s:6:"height";i:1400;s:4:"file";s:22:"2023/04/hantel_5kg.png";s:8:"filesize";i:533423;s:5:"sizes";a:7:{s:6:"medium";a:5:{s:4:"file";s:22:"hantel_5kg-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:43186;}s:5:"large";a:5:{s:4:"file";s:24:"hantel_5kg-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:316065;}s:9:"thumbnail";a:5:{s:4:"file";s:22:"hantel_5kg-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:14039;}s:12:"medium_large";a:5:{s:4:"file";s:22:"hantel_5kg-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:306097;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:22:"hantel_5kg-324x324.png";s:5:"width";i:324;s:6:"height";i:324;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:66176;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:22:"hantel_5kg-416x416.png";s:5:"width";i:416;s:6:"height";i:416;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:100919;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:22:"hantel_5kg-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:6808;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(37, 17, '_wp_attached_file', '2023/04/presentkort.png'),
(38, 17, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:750;s:6:"height";i:750;s:4:"file";s:23:"2023/04/presentkort.png";s:8:"filesize";i:136986;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:23:"presentkort-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:30259;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"presentkort-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:10535;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:23:"presentkort-324x324.png";s:5:"width";i:324;s:6:"height";i:324;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:44452;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:23:"presentkort-416x416.png";s:5:"width";i:416;s:6:"height";i:416;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:69409;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:23:"presentkort-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:5803;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(43, 20, '_wp_attached_file', '2023/04/yogamatta.png'),
(44, 20, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1400;s:6:"height";i:1400;s:4:"file";s:21:"2023/04/yogamatta.png";s:8:"filesize";i:1399465;s:5:"sizes";a:7:{s:6:"medium";a:5:{s:4:"file";s:21:"yogamatta-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:77953;}s:5:"large";a:5:{s:4:"file";s:23:"yogamatta-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:800250;}s:9:"thumbnail";a:5:{s:4:"file";s:21:"yogamatta-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:21018;}s:12:"medium_large";a:5:{s:4:"file";s:21:"yogamatta-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:572047;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:21:"yogamatta-324x324.png";s:5:"width";i:324;s:6:"height";i:324;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:105623;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:21:"yogamatta-416x416.png";s:5:"width";i:416;s:6:"height";i:416;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:172853;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:21:"yogamatta-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:9796;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(45, 21, '_wp_attached_file', '2023/04/yogamatta_pink.png'),
(46, 21, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1400;s:6:"height";i:1400;s:4:"file";s:26:"2023/04/yogamatta_pink.png";s:8:"filesize";i:1317118;s:5:"sizes";a:7:{s:6:"medium";a:5:{s:4:"file";s:26:"yogamatta_pink-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:77176;}s:5:"large";a:5:{s:4:"file";s:28:"yogamatta_pink-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:720790;}s:9:"thumbnail";a:5:{s:4:"file";s:26:"yogamatta_pink-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:20741;}s:12:"medium_large";a:5:{s:4:"file";s:26:"yogamatta_pink-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:528217;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:26:"yogamatta_pink-324x324.png";s:5:"width";i:324;s:6:"height";i:324;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:104598;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:26:"yogamatta_pink-416x416.png";s:5:"width";i:416;s:6:"height";i:416;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:168683;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:26:"yogamatta_pink-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:9659;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(47, 22, '_edit_last', '1'),
(48, 22, '_edit_lock', '1681998872:1'),
(51, 22, 'total_sales', '0'),
(52, 22, '_tax_status', 'taxable'),
(53, 22, '_tax_class', ''),
(54, 22, '_manage_stock', 'no'),
(55, 22, '_backorders', 'no'),
(56, 22, '_sold_individually', 'no'),
(57, 22, '_virtual', 'no'),
(58, 22, '_downloadable', 'no'),
(59, 22, '_download_limit', '-1'),
(60, 22, '_download_expiry', '-1'),
(61, 22, '_stock', NULL),
(62, 22, '_stock_status', 'instock'),
(63, 22, '_wc_average_rating', '0'),
(64, 22, '_wc_review_count', '0'),
(65, 22, '_product_version', '7.6.0'),
(67, 22, '_product_attributes', 'a:1:{s:10:"pa_storlek";a:6:{s:4:"name";s:10:"pa_storlek";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}}'),
(68, 23, '_variation_description', ''),
(69, 23, 'total_sales', '0'),
(70, 23, '_tax_status', 'taxable'),
(71, 23, '_tax_class', 'parent'),
(72, 23, '_manage_stock', 'yes'),
(73, 23, '_backorders', 'no'),
(74, 23, '_sold_individually', 'no'),
(75, 23, '_virtual', 'no'),
(76, 23, '_downloadable', 'no'),
(77, 23, '_download_limit', '-1'),
(78, 23, '_download_expiry', '-1'),
(79, 23, '_stock', '10'),
(80, 23, '_stock_status', 'instock'),
(81, 23, '_wc_average_rating', '0'),
(82, 23, '_wc_review_count', '0'),
(83, 23, 'attribute_pa_storlek', 'large'),
(84, 23, '_product_version', '7.6.0'),
(85, 24, '_variation_description', ''),
(86, 24, 'total_sales', '0'),
(87, 24, '_tax_status', 'taxable'),
(88, 24, '_tax_class', 'parent'),
(89, 24, '_manage_stock', 'yes'),
(90, 24, '_backorders', 'no'),
(91, 24, '_sold_individually', 'no'),
(92, 24, '_virtual', 'no'),
(93, 24, '_downloadable', 'no'),
(94, 24, '_download_limit', '-1'),
(95, 24, '_download_expiry', '-1'),
(96, 24, '_stock', '10'),
(97, 24, '_stock_status', 'instock'),
(98, 24, '_wc_average_rating', '0'),
(99, 24, '_wc_review_count', '0'),
(100, 24, 'attribute_pa_storlek', 'medium'),
(101, 24, '_product_version', '7.6.0'),
(102, 25, '_variation_description', ''),
(103, 25, 'total_sales', '0'),
(104, 25, '_tax_status', 'taxable'),
(105, 25, '_tax_class', 'parent'),
(106, 25, '_manage_stock', 'yes'),
(107, 25, '_backorders', 'no'),
(108, 25, '_sold_individually', 'no'),
(109, 25, '_virtual', 'no') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(110, 25, '_downloadable', 'no'),
(111, 25, '_download_limit', '-1'),
(112, 25, '_download_expiry', '-1'),
(113, 25, '_stock', '10'),
(114, 25, '_stock_status', 'instock'),
(115, 25, '_wc_average_rating', '0'),
(116, 25, '_wc_review_count', '0'),
(117, 25, 'attribute_pa_storlek', 'small'),
(118, 25, '_product_version', '7.6.0'),
(119, 23, '_regular_price', '399'),
(120, 23, '_thumbnail_id', '0'),
(121, 23, '_price', '399'),
(122, 24, '_regular_price', '399'),
(123, 24, '_thumbnail_id', '0'),
(124, 24, '_price', '399'),
(125, 25, '_regular_price', '399'),
(126, 25, '_thumbnail_id', '0'),
(127, 25, '_price', '399'),
(131, 23, '_sku', 'yogatights-large'),
(132, 24, '_sku', 'yogatights-medium'),
(133, 25, '_sku', 'yogatights-small'),
(134, 22, '_price', '399'),
(135, 26, '_edit_last', '1'),
(136, 26, '_edit_lock', '1681996406:1'),
(137, 20, '_wp_attachment_image_alt', 'yogamatta'),
(138, 26, '_thumbnail_id', '20'),
(139, 26, '_sku', 'yogamatta'),
(140, 26, '_regular_price', '499'),
(141, 26, 'total_sales', '0'),
(142, 26, '_tax_status', 'taxable'),
(143, 26, '_tax_class', ''),
(144, 26, '_manage_stock', 'yes'),
(145, 26, '_backorders', 'no'),
(146, 26, '_sold_individually', 'no'),
(147, 26, '_virtual', 'no'),
(148, 26, '_downloadable', 'no'),
(149, 26, '_download_limit', '-1'),
(150, 26, '_download_expiry', '-1'),
(151, 26, '_stock', '5'),
(152, 26, '_stock_status', 'instock'),
(153, 26, '_wc_average_rating', '0'),
(154, 26, '_wc_review_count', '0'),
(155, 26, '_product_version', '7.6.0'),
(156, 26, '_price', '499'),
(157, 29, '_edit_last', '1'),
(158, 29, '_edit_lock', '1681998961:1'),
(159, 29, 'total_sales', '0'),
(160, 29, '_tax_status', 'taxable'),
(161, 29, '_tax_class', ''),
(162, 29, '_manage_stock', 'no'),
(163, 29, '_backorders', 'no'),
(164, 29, '_sold_individually', 'no'),
(165, 29, '_virtual', 'no'),
(166, 29, '_downloadable', 'no'),
(167, 29, '_download_limit', '-1'),
(168, 29, '_download_expiry', '-1'),
(169, 29, '_stock', NULL),
(170, 29, '_stock_status', 'instock'),
(171, 29, '_wc_average_rating', '0'),
(172, 29, '_wc_review_count', '0'),
(173, 29, '_product_attributes', 'a:2:{s:7:"pa_farg";a:6:{s:4:"name";s:7:"pa_farg";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}s:10:"pa_storlek";a:6:{s:4:"name";s:10:"pa_storlek";s:5:"value";s:0:"";s:8:"position";i:1;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}}'),
(174, 29, '_product_version', '7.6.0'),
(175, 30, '_variation_description', ''),
(176, 30, 'total_sales', '0'),
(177, 30, '_tax_status', 'taxable'),
(178, 30, '_tax_class', 'parent'),
(179, 30, '_manage_stock', 'yes'),
(180, 30, '_backorders', 'no'),
(181, 30, '_sold_individually', 'no'),
(182, 30, '_virtual', 'no'),
(183, 30, '_downloadable', 'no'),
(184, 30, '_download_limit', '-1'),
(185, 30, '_download_expiry', '-1'),
(186, 30, '_stock', '10'),
(187, 30, '_stock_status', 'instock'),
(188, 30, '_wc_average_rating', '0'),
(189, 30, '_wc_review_count', '0'),
(190, 30, 'attribute_pa_storlek', 'large'),
(191, 30, 'attribute_pa_farg', 'rosa'),
(192, 30, '_product_version', '7.6.0'),
(193, 31, '_variation_description', ''),
(194, 31, 'total_sales', '0'),
(195, 31, '_tax_status', 'taxable'),
(196, 31, '_tax_class', 'parent'),
(197, 31, '_manage_stock', 'yes'),
(198, 31, '_backorders', 'no'),
(199, 31, '_sold_individually', 'no'),
(200, 31, '_virtual', 'no'),
(201, 31, '_downloadable', 'no'),
(202, 31, '_download_limit', '-1'),
(203, 31, '_download_expiry', '-1'),
(204, 31, '_stock', '13'),
(205, 31, '_stock_status', 'instock'),
(206, 31, '_wc_average_rating', '0'),
(207, 31, '_wc_review_count', '0'),
(208, 31, 'attribute_pa_storlek', 'medium'),
(209, 31, 'attribute_pa_farg', 'rosa'),
(210, 31, '_product_version', '7.6.0'),
(211, 32, '_variation_description', ''),
(212, 32, 'total_sales', '0') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(213, 32, '_tax_status', 'taxable'),
(214, 32, '_tax_class', 'parent'),
(215, 32, '_manage_stock', 'yes'),
(216, 32, '_backorders', 'no'),
(217, 32, '_sold_individually', 'no'),
(218, 32, '_virtual', 'no'),
(219, 32, '_downloadable', 'no'),
(220, 32, '_download_limit', '-1'),
(221, 32, '_download_expiry', '-1'),
(222, 32, '_stock', '10'),
(223, 32, '_stock_status', 'instock'),
(224, 32, '_wc_average_rating', '0'),
(225, 32, '_wc_review_count', '0'),
(226, 32, 'attribute_pa_storlek', 'small'),
(227, 32, 'attribute_pa_farg', 'rosa'),
(228, 32, '_product_version', '7.6.0'),
(229, 33, '_variation_description', ''),
(230, 33, 'total_sales', '0'),
(231, 33, '_tax_status', 'taxable'),
(232, 33, '_tax_class', 'parent'),
(233, 33, '_manage_stock', 'yes'),
(234, 33, '_backorders', 'no'),
(235, 33, '_sold_individually', 'no'),
(236, 33, '_virtual', 'no'),
(237, 33, '_downloadable', 'no'),
(238, 33, '_download_limit', '-1'),
(239, 33, '_download_expiry', '-1'),
(240, 33, '_stock', '10'),
(241, 33, '_stock_status', 'instock'),
(242, 33, '_wc_average_rating', '0'),
(243, 33, '_wc_review_count', '0'),
(244, 33, 'attribute_pa_storlek', 'large'),
(245, 33, 'attribute_pa_farg', 'svart'),
(246, 33, '_product_version', '7.6.0'),
(247, 34, '_variation_description', ''),
(248, 34, 'total_sales', '0'),
(249, 34, '_tax_status', 'taxable'),
(250, 34, '_tax_class', 'parent'),
(251, 34, '_manage_stock', 'yes'),
(252, 34, '_backorders', 'no'),
(253, 34, '_sold_individually', 'no'),
(254, 34, '_virtual', 'no'),
(255, 34, '_downloadable', 'no'),
(256, 34, '_download_limit', '-1'),
(257, 34, '_download_expiry', '-1'),
(258, 34, '_stock', '10'),
(259, 34, '_stock_status', 'instock'),
(260, 34, '_wc_average_rating', '0'),
(261, 34, '_wc_review_count', '0'),
(262, 34, 'attribute_pa_storlek', 'medium'),
(263, 34, 'attribute_pa_farg', 'svart'),
(264, 34, '_product_version', '7.6.0'),
(265, 35, '_variation_description', ''),
(266, 35, 'total_sales', '0'),
(267, 35, '_tax_status', 'taxable'),
(268, 35, '_tax_class', 'parent'),
(269, 35, '_manage_stock', 'yes'),
(270, 35, '_backorders', 'no'),
(271, 35, '_sold_individually', 'no'),
(272, 35, '_virtual', 'no'),
(273, 35, '_downloadable', 'no'),
(274, 35, '_download_limit', '-1'),
(275, 35, '_download_expiry', '-1'),
(276, 35, '_stock', '10'),
(277, 35, '_stock_status', 'instock'),
(278, 35, '_wc_average_rating', '0'),
(279, 35, '_wc_review_count', '0'),
(280, 35, 'attribute_pa_storlek', 'small'),
(281, 35, 'attribute_pa_farg', 'svart'),
(282, 35, '_product_version', '7.6.0'),
(283, 30, '_regular_price', '399'),
(284, 30, '_thumbnail_id', '47'),
(285, 30, '_price', '299'),
(286, 31, '_regular_price', '399'),
(287, 31, '_thumbnail_id', '47'),
(288, 31, '_price', '299'),
(289, 32, '_regular_price', '399'),
(290, 32, '_thumbnail_id', '47'),
(291, 32, '_price', '299'),
(292, 33, '_regular_price', '399'),
(294, 33, '_price', '399'),
(295, 34, '_regular_price', '399'),
(297, 34, '_price', '399'),
(298, 35, '_regular_price', '399'),
(300, 35, '_price', '399'),
(302, 30, '_sku', 'traningstopp-rosa-large'),
(303, 30, '_sale_price', '299'),
(304, 31, '_sku', 'traningstopp-rosa-medium'),
(305, 31, '_sale_price', '299'),
(306, 32, '_sku', 'traningstopp-rosa-small'),
(307, 32, '_sale_price', '299'),
(308, 33, '_sku', 'traningstopp-svart-large'),
(309, 34, '_sku', 'traningstopp-svart-medium'),
(310, 35, '_sku', 'traningstopp-svart-small'),
(314, 29, '_default_attributes', 'a:2:{s:7:"pa_farg";s:4:"rosa";s:10:"pa_storlek";s:5:"small";}'),
(323, 36, '_edit_last', '1'),
(324, 36, '_edit_lock', '1681996152:1'),
(325, 36, 'total_sales', '0'),
(326, 36, '_tax_status', 'taxable'),
(327, 36, '_tax_class', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(328, 36, '_manage_stock', 'no'),
(329, 36, '_backorders', 'no'),
(330, 36, '_sold_individually', 'no'),
(331, 36, '_virtual', 'no'),
(332, 36, '_downloadable', 'no'),
(333, 36, '_download_limit', '-1'),
(334, 36, '_download_expiry', '-1'),
(335, 36, '_stock', NULL),
(336, 36, '_stock_status', 'instock'),
(337, 36, '_wc_average_rating', '0'),
(338, 36, '_wc_review_count', '0'),
(339, 36, '_product_version', '7.6.0'),
(340, 36, '_product_attributes', 'a:1:{s:7:"pa_vikt";a:6:{s:4:"name";s:7:"pa_vikt";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}}'),
(358, 38, '_variation_description', ''),
(359, 38, 'total_sales', '0'),
(360, 38, '_tax_status', 'taxable'),
(361, 38, '_tax_class', 'parent'),
(362, 38, '_manage_stock', 'yes'),
(363, 38, '_backorders', 'no'),
(364, 38, '_sold_individually', 'no'),
(365, 38, '_virtual', 'no'),
(366, 38, '_downloadable', 'no'),
(367, 38, '_download_limit', '-1'),
(368, 38, '_download_expiry', '-1'),
(369, 38, '_stock', '6'),
(370, 38, '_stock_status', 'instock'),
(371, 38, '_wc_average_rating', '0'),
(372, 38, '_wc_review_count', '0'),
(373, 38, 'attribute_pa_vikt', '2kg'),
(374, 38, '_product_version', '7.6.0'),
(375, 39, '_variation_description', ''),
(376, 39, 'total_sales', '0'),
(377, 39, '_tax_status', 'taxable'),
(378, 39, '_tax_class', 'parent'),
(379, 39, '_manage_stock', 'yes'),
(380, 39, '_backorders', 'no'),
(381, 39, '_sold_individually', 'no'),
(382, 39, '_virtual', 'no'),
(383, 39, '_downloadable', 'no'),
(384, 39, '_download_limit', '-1'),
(385, 39, '_download_expiry', '-1'),
(386, 39, '_stock', '10'),
(387, 39, '_stock_status', 'instock'),
(388, 39, '_wc_average_rating', '0'),
(389, 39, '_wc_review_count', '0'),
(390, 39, 'attribute_pa_vikt', '4kg'),
(391, 39, '_product_version', '7.6.0'),
(392, 40, '_variation_description', ''),
(393, 40, 'total_sales', '0'),
(394, 40, '_tax_status', 'taxable'),
(395, 40, '_tax_class', 'parent'),
(396, 40, '_manage_stock', 'yes'),
(397, 40, '_backorders', 'no'),
(398, 40, '_sold_individually', 'no'),
(399, 40, '_virtual', 'no'),
(400, 40, '_downloadable', 'no'),
(401, 40, '_download_limit', '-1'),
(402, 40, '_download_expiry', '-1'),
(403, 40, '_stock', '8'),
(404, 40, '_stock_status', 'instock'),
(405, 40, '_wc_average_rating', '0'),
(406, 40, '_wc_review_count', '0'),
(407, 40, 'attribute_pa_vikt', '5kg'),
(408, 40, '_product_version', '7.6.0'),
(409, 14, '_wp_attachment_image_alt', 'hantel 2kg'),
(410, 15, '_wp_attachment_image_alt', 'hantel 4kg'),
(411, 16, '_wp_attachment_image_alt', 'hantel 5kg'),
(412, 38, '_sku', 'hantel-2kg'),
(413, 38, '_regular_price', '149'),
(414, 38, '_thumbnail_id', '14'),
(415, 38, '_price', '149'),
(416, 39, '_sku', 'hantel-4kg'),
(417, 39, '_regular_price', '249'),
(418, 39, '_thumbnail_id', '15'),
(419, 39, '_price', '249'),
(420, 40, '_sku', 'hantel-5kg'),
(421, 40, '_regular_price', '299'),
(422, 40, '_thumbnail_id', '16'),
(423, 40, '_price', '299'),
(427, 36, '_default_attributes', 'a:1:{s:7:"pa_vikt";s:3:"2kg";}'),
(428, 36, '_price', '149'),
(429, 36, '_price', '249'),
(430, 36, '_price', '299'),
(431, 36, '_thumbnail_id', '14'),
(432, 44, '_wp_attached_file', '2023/04/Traningsschema.png'),
(433, 44, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1414;s:6:"height";i:2000;s:4:"file";s:26:"2023/04/Traningsschema.png";s:8:"filesize";i:2314129;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:26:"Traningsschema-212x300.png";s:5:"width";i:212;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:88179;}s:5:"large";a:5:{s:4:"file";s:27:"Traningsschema-724x1024.png";s:5:"width";i:724;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:729608;}s:9:"thumbnail";a:5:{s:4:"file";s:26:"Traningsschema-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:35019;}s:12:"medium_large";a:5:{s:4:"file";s:27:"Traningsschema-768x1086.png";s:5:"width";i:768;s:6:"height";i:1086;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:818028;}s:9:"1536x1536";a:5:{s:4:"file";s:28:"Traningsschema-1086x1536.png";s:5:"width";i:1086;s:6:"height";i:1536;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1521261;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:26:"Traningsschema-324x324.png";s:5:"width";i:324;s:6:"height";i:324;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:128105;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:26:"Traningsschema-416x588.png";s:5:"width";i:416;s:6:"height";i:588;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:276984;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:26:"Traningsschema-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:17561;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(434, 45, '_edit_last', '1'),
(435, 45, '_edit_lock', '1681995481:1'),
(436, 46, '_wp_attached_file', '2023/04/TraningsschemaPDF.pdf'),
(437, 46, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:474922;}'),
(438, 45, 'total_sales', '0'),
(439, 45, '_tax_status', 'taxable'),
(440, 45, '_tax_class', ''),
(441, 45, '_manage_stock', 'no'),
(442, 45, '_backorders', 'no'),
(443, 45, '_sold_individually', 'no'),
(444, 45, '_virtual', 'yes'),
(445, 45, '_downloadable', 'yes'),
(446, 45, '_download_limit', '-1'),
(447, 45, '_download_expiry', '-1') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(448, 45, '_stock', NULL),
(449, 45, '_stock_status', 'instock'),
(450, 45, '_wc_average_rating', '0'),
(451, 45, '_wc_review_count', '0'),
(452, 45, '_product_version', '7.6.0'),
(453, 44, '_wp_attachment_image_alt', 'tränings schema'),
(454, 45, '_thumbnail_id', '44'),
(455, 45, '_sku', 'traningsschema'),
(456, 45, '_regular_price', '29'),
(457, 45, '_downloadable_files', 'a:1:{s:36:"e7afd617-5528-4f7c-818a-84addddaa14c";a:4:{s:2:"id";s:36:"e7afd617-5528-4f7c-818a-84addddaa14c";s:4:"name";s:14:"traningsschema";s:4:"file";s:80:"http://localhost/labb2-carolina/wp-content/uploads/2023/04/TraningsschemaPDF.pdf";s:7:"enabled";b:1;}}'),
(458, 45, '_price', '29'),
(459, 47, '_wp_attached_file', '2023/04/topp_pink.png'),
(460, 47, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1400;s:6:"height";i:1400;s:4:"file";s:21:"2023/04/topp_pink.png";s:8:"filesize";i:1066444;s:5:"sizes";a:7:{s:6:"medium";a:5:{s:4:"file";s:21:"topp_pink-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:70069;}s:5:"large";a:5:{s:4:"file";s:23:"topp_pink-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:633841;}s:9:"thumbnail";a:5:{s:4:"file";s:21:"topp_pink-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:21023;}s:12:"medium_large";a:5:{s:4:"file";s:21:"topp_pink-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:492881;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:21:"topp_pink-324x324.png";s:5:"width";i:324;s:6:"height";i:324;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:96170;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:21:"topp_pink-416x416.png";s:5:"width";i:416;s:6:"height";i:416;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:153891;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:21:"topp_pink-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:9900;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(461, 48, '_wp_attached_file', '2023/04/topp_black.png'),
(462, 48, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1400;s:6:"height";i:1400;s:4:"file";s:22:"2023/04/topp_black.png";s:8:"filesize";i:662076;s:5:"sizes";a:7:{s:6:"medium";a:5:{s:4:"file";s:22:"topp_black-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:59624;}s:5:"large";a:5:{s:4:"file";s:24:"topp_black-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:433619;}s:9:"thumbnail";a:5:{s:4:"file";s:22:"topp_black-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:18570;}s:12:"medium_large";a:5:{s:4:"file";s:22:"topp_black-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:385957;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:22:"topp_black-324x324.png";s:5:"width";i:324;s:6:"height";i:324;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:82337;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:22:"topp_black-416x416.png";s:5:"width";i:416;s:6:"height";i:416;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:127913;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:22:"topp_black-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:8789;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(463, 49, '_wp_attached_file', '2023/04/yogatights.png'),
(464, 49, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1400;s:6:"height";i:1400;s:4:"file";s:22:"2023/04/yogatights.png";s:8:"filesize";i:740020;s:5:"sizes";a:7:{s:6:"medium";a:5:{s:4:"file";s:22:"yogatights-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:45806;}s:5:"large";a:5:{s:4:"file";s:24:"yogatights-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:346792;}s:9:"thumbnail";a:5:{s:4:"file";s:22:"yogatights-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:14876;}s:12:"medium_large";a:5:{s:4:"file";s:22:"yogatights-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:348930;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:22:"yogatights-324x324.png";s:5:"width";i:324;s:6:"height";i:324;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:71178;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:22:"yogatights-416x416.png";s:5:"width";i:416;s:6:"height";i:416;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:109729;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:22:"yogatights-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:7032;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(465, 49, '_wp_attachment_image_alt', 'yogatights'),
(466, 22, '_thumbnail_id', '49'),
(467, 47, '_wp_attachment_image_alt', 'träningstopp rosa'),
(468, 48, '_wp_attachment_image_alt', 'träningstopp svart'),
(469, 33, '_thumbnail_id', '48'),
(470, 34, '_thumbnail_id', '48'),
(471, 35, '_thumbnail_id', '48'),
(472, 29, '_price', '299'),
(473, 29, '_price', '399'),
(474, 29, '_thumbnail_id', '47'),
(475, 50, '_menu_item_type', 'taxonomy'),
(476, 50, '_menu_item_menu_item_parent', '0'),
(477, 50, '_menu_item_object_id', '22'),
(478, 50, '_menu_item_object', 'product_cat'),
(479, 50, '_menu_item_target', ''),
(480, 50, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(481, 50, '_menu_item_xfn', ''),
(482, 50, '_menu_item_url', ''),
(484, 51, '_menu_item_type', 'taxonomy'),
(485, 51, '_menu_item_menu_item_parent', '0'),
(486, 51, '_menu_item_object_id', '23'),
(487, 51, '_menu_item_object', 'product_cat'),
(488, 51, '_menu_item_target', ''),
(489, 51, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(490, 51, '_menu_item_xfn', ''),
(491, 51, '_menu_item_url', ''),
(493, 52, '_menu_item_type', 'taxonomy'),
(494, 52, '_menu_item_menu_item_parent', '0'),
(495, 52, '_menu_item_object_id', '28'),
(496, 52, '_menu_item_object', 'product_cat'),
(497, 52, '_menu_item_target', ''),
(498, 52, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(499, 52, '_menu_item_xfn', ''),
(500, 52, '_menu_item_url', ''),
(501, 54, '_edit_lock', '1682275554:1'),
(502, 53, '_edit_lock', '1682275554:1'),
(503, 55, '_edit_lock', '1682275436:1'),
(504, 2, '_wp_trash_meta_status', 'publish'),
(505, 2, '_wp_trash_meta_time', '1682275591'),
(506, 2, '_wp_desired_post_slug', 'exempelsida'),
(507, 57, '_edit_lock', '1682275474:1'),
(508, 58, '_edit_lock', '1682278746:1'),
(509, 6, '_edit_lock', '1682277778:1'),
(510, 3, '_edit_lock', '1682277683:1'),
(511, 60, '_wp_attached_file', '2023/04/sportbackground3.png'),
(512, 60, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:7837;s:6:"height";i:5225;s:4:"file";s:28:"2023/04/sportbackground3.png";s:8:"filesize";i:34911032;s:5:"sizes";a:9:{s:6:"medium";a:5:{s:4:"file";s:28:"sportbackground3-300x200.png";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:114888;}s:5:"large";a:5:{s:4:"file";s:29:"sportbackground3-1024x683.png";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1111033;}s:9:"thumbnail";a:5:{s:4:"file";s:28:"sportbackground3-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:46069;}s:12:"medium_large";a:5:{s:4:"file";s:28:"sportbackground3-768x512.png";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:651562;}s:9:"1536x1536";a:5:{s:4:"file";s:30:"sportbackground3-1536x1024.png";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:2345599;}s:9:"2048x2048";a:5:{s:4:"file";s:30:"sportbackground3-2048x1365.png";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:3989677;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:28:"sportbackground3-324x324.png";s:5:"width";i:324;s:6:"height";i:324;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:189153;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:28:"sportbackground3-416x277.png";s:5:"width";i:416;s:6:"height";i:277;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:209683;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:28:"sportbackground3-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:21873;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(513, 60, '_wp_attachment_image_alt', 'kampanjbild1'),
(514, 58, '_wp_trash_meta_status', 'publish'),
(515, 58, '_wp_trash_meta_time', '1682342077'),
(516, 58, '_wp_desired_post_slug', 'hem') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2023-04-19 09:26:53', '2023-04-19 07:26:53', '<!-- wp:paragraph -->\n<p>Välkommen till WordPress. Detta är ditt första inlägg. Du kan redigera det eller ta bort det. Sedan är det bara att börja skriva!</p>\n<!-- /wp:paragraph -->', 'Hej världen!', '', 'publish', 'open', 'open', '', 'hej-varlden', '', '', '2023-04-19 09:26:53', '2023-04-19 07:26:53', '', 0, 'http://localhost/labb2-carolina/?p=1', 0, 'post', '', 1),
(2, 1, '2023-04-19 09:26:53', '2023-04-19 07:26:53', '<!-- wp:paragraph -->\n<p>Detta är en exempelsida. Den skiljer sig från ett blogginlägg genom att den finns kvar på samma plats och kommer att visas i din webbplatsnavigering (i de flesta teman). De flesta börjar med en Om-sida som presenterar dem för potentiella besökare. Den skulle t.ex kunna ha följande innehåll:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hej där! Jag är cykelbud på dagen, blivande skådespelare på natten och detta är min blogg. Jag bor i Örebro, har en katt som heter Lurv och jag gillar Pina Coladas. (och att simma i Göta kanal).</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>... eller något liknande detta:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Företaget AB grundades 1971 och har sedan dess varit den största leverantören av grunk-manicker på den svenska marknaden. FAB finns i utkanten av Grönköping, har drygt 20&nbsp;000 anställda och läser veckobladet varje år.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Som ny WordPress-användare bör du gå till <a href="http://localhost/labb2-carolina/wp-admin/">din adminpanel</a> för att ta bort denna sida och skapa nya sidor för ditt innehåll. Lycka till!</p>\n<!-- /wp:paragraph -->', 'Exempelsida', '', 'trash', 'closed', 'open', '', 'exempelsida__trashed', '', '', '2023-04-23 20:46:31', '2023-04-23 18:46:31', '', 0, 'http://localhost/labb2-carolina/?page_id=2', 0, 'page', '', 0),
(3, 1, '2023-04-19 09:26:53', '2023-04-19 07:26:53', '<!-- wp:heading --><h2>Vilka vi är</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>Vår webbplatsadress är: http://localhost/labb2-carolina.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Kommentarer</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>När besökare lämnar kommentarer på webbplatsen samlar vi in de uppgifter som visas i kommentarsformuläret samt besökarens IP-adress och webbläsarens användaragent-sträng som hjälp för detektering av skräppost.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>En anonymiserad sträng som skapats utifrån din e-postadress (även kallat hash-värde) kan komma att sändas till tjänsten Gravatar för att avgöra om du finns registrerad där. Integritetspolicyn för tjänsten Gravatar finns på https://automattic.com/privacy/. När din kommentar har godkänts visas din profilbild offentligt tillsammans med din kommentar.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>Om du laddar upp bilder till webbplatsen bör du undvika att ladda upp bilder där EXIF-data inkluderar data från GPS-lokalisering. Besökare till webbplatsen kan ladda ned och ta fram alla positioneringsuppgifter från bilder på webbplatsen.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookie-filer</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>Om du lämnar en kommentar på vår webbplats kan du välja att spara ditt namn, din e-postadress och webbplatsadress i cookie-filer. Detta är för din bekvämlighet för att du inte ska behöva fylla i dessa uppgifter igen nästa gång du skriver en kommentar. Dessa cookie-filer gäller i ett år.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Om du besöker vår inloggningssida kommer vi att sätta en tillfällig cookie för att undersöka om din webbläsare accepterar dem. Denna cookie innehåller inga personuppgifter och den försvinner när du stänger din webbläsare.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>När du loggar in kommer vi dessutom att skapa flera cookie-filer för att spara information om din inloggning och dina val för utformning av skärmlayouten. Cookie-filer för inloggning gäller i två dagar och cookie-filer för layoutval gäller i ett år. Om du kryssar i ”Kom ihåg mig” kommer din cookie att finnas kvar i två veckor. Om du loggar ut från ditt konto kommer cookie-filerna för inloggning att tas bort.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Om du redigerar eller publicerar en artikel kommer en extra cookie-fil att sparas i din webbläsare. Denna cookie-fil innehåller inga personuppgifter utan anger endast inläggs-ID för den artikel du just redigerade och löper ut efter ett dygn.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Inbäddad innehåll från andra webbplatser</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>Artiklar på denna webbplats kan innehålla inbäddat innehåll (exempelvis videoklipp, bilder, artiklar o.s.v.). Inbäddat innehåll från andra webbplatser beter sig precis på samma sätt som om besökaren har besökt den andra webbplatsen.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Dessa webbplatser kan samla in uppgifter om dig, använda cookie-filer, bädda in ytterligare spårning från tredje part och övervaka din interaktion med sagda inbäddade innehåll, inklusive spårning av din interaktion med detta inbäddade innehåll om du har ett konto och är inloggad på webbplatsen i fråga.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Vilka vi delar dina data med</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>Om du begär återställning av lösenordet kommer din IP-adress att ingå i e-postmeddelandet om återställning.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Hur länge vi behåller era uppgifter</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>Om du skriver en kommentar kommer kommentaren och dess metadata att sparas utan tidsgräns. Anledningen till detta är att vi behöver kunna hitta och godkänna uppföljningskommentarer automatiskt och inte lägga dem i kö för granskning.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>För användare som registrerar sig på er webbplats (om sådana finns) sparar vi även de personuppgifter de anger i sin användarprofil. Alla användare kan se, redigera eller radera sina personuppgifter när som helst (med undantaget att de inte kan ändra sitt användarnamn). Även webbplatsens administratörer kan se och redigera denna information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Vilka rättigheter du har över dina data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>Om du har ett konto eller har skrivit några kommentarer på denna webbplats kan du begära en exportfil med de personuppgifter vi har om dig, inklusive alla uppgifter du har gett oss. Du kan också begära att vi tar bort alla personuppgifter vi har om dig. Detta omfattar inte eventuella uppgifter som vi är tvungna att spara av administrativa, legala eller säkerhetsändamål.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Vart dina uppgifter skickas</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>Kommentarer från besökare kanske kontrolleras via en automatiserad tjänst för detektering av skräppost.</p><!-- /wp:paragraph -->', 'Integritetspolicy', '', 'draft', 'closed', 'open', '', 'integritetspolicy', '', '', '2023-04-19 09:26:53', '2023-04-19 07:26:53', '', 0, 'http://localhost/labb2-carolina/?page_id=3', 0, 'page', '', 0),
(4, 1, '2023-04-19 09:27:10', '0000-00-00 00:00:00', '', 'Automatiskt utkast', '', 'auto-draft', 'open', 'open', '', '', '', '', '2023-04-19 09:27:10', '0000-00-00 00:00:00', '', 0, 'http://localhost/labb2-carolina/?p=4', 0, 'post', '', 0),
(5, 1, '2023-04-19 09:40:04', '2023-04-19 07:40:04', '', 'woocommerce-placeholder', '', 'inherit', 'open', 'closed', '', 'woocommerce-placeholder', '', '', '2023-04-19 09:40:04', '2023-04-19 07:40:04', '', 0, 'http://localhost/labb2-carolina/wp-content/uploads/2023/04/woocommerce-placeholder.png', 0, 'attachment', 'image/png', 0),
(6, 1, '2023-04-19 09:40:04', '2023-04-19 07:40:04', '', 'Butik', '', 'publish', 'closed', 'closed', '', 'butik', '', '', '2023-04-19 09:40:04', '2023-04-19 07:40:04', '', 0, 'http://localhost/labb2-carolina/butik/', 0, 'page', '', 0),
(7, 1, '2023-04-19 09:40:04', '2023-04-19 07:40:04', '<!-- wp:shortcode -->[woocommerce_cart]<!-- /wp:shortcode -->', 'Varukorg', '', 'publish', 'closed', 'closed', '', 'varukorg', '', '', '2023-04-19 09:40:04', '2023-04-19 07:40:04', '', 0, 'http://localhost/labb2-carolina/varukorg/', 0, 'page', '', 0),
(8, 1, '2023-04-19 09:40:04', '2023-04-19 07:40:04', '<!-- wp:shortcode -->[woocommerce_checkout]<!-- /wp:shortcode -->', 'Kassa', '', 'publish', 'closed', 'closed', '', 'kassan', '', '', '2023-04-19 09:40:04', '2023-04-19 07:40:04', '', 0, 'http://localhost/labb2-carolina/kassan/', 0, 'page', '', 0),
(9, 1, '2023-04-19 09:40:04', '2023-04-19 07:40:04', '<!-- wp:shortcode -->[woocommerce_my_account]<!-- /wp:shortcode -->', 'Mitt konto', '', 'publish', 'closed', 'closed', '', 'mitt-konto', '', '', '2023-04-19 09:40:04', '2023-04-19 07:40:04', '', 0, 'http://localhost/labb2-carolina/mitt-konto/', 0, 'page', '', 0),
(10, 1, '2023-04-19 09:40:04', '0000-00-00 00:00:00', '<!-- wp:paragraph -->\n<p><b>This is a sample page.</b></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h3>Overview</h3>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Our refund and returns policy lasts 30 days. If 30 days have passed since your purchase, we can’t offer you a full refund or exchange.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>To be eligible for a return, your item must be unused and in the same condition that you received it. It must also be in the original packaging.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Several types of goods are exempt from being returned. Perishable goods such as food, flowers, newspapers or magazines cannot be returned. We also do not accept products that are intimate or sanitary goods, hazardous materials, or flammable liquids or gases.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Additional non-returnable items:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul>\n<li>Gift cards</li>\n<li>Downloadable software products</li>\n<li>Some health and personal care items</li>\n</ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>To complete your return, we require a receipt or proof of purchase.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Please do not send your purchase back to the manufacturer.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>There are certain situations where only partial refunds are granted:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul>\n<li>Book with obvious signs of use</li>\n<li>CD, DVD, VHS tape, software, video game, cassette tape, or vinyl record that has been opened.</li>\n<li>Any item not in its original condition, is damaged or missing parts for reasons not due to our error.</li>\n<li>Any item that is returned more than 30 days after delivery</li>\n</ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<h2>Refunds</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Once your return is received and inspected, we will send you an email to notify you that we have received your returned item. We will also notify you of the approval or rejection of your refund.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are approved, then your refund will be processed, and a credit will automatically be applied to your credit card or original method of payment, within a certain amount of days.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<b>Late or missing refunds</b>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you haven’t received a refund yet, first check your bank account again.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Then contact your credit card company, it may take some time before your refund is officially posted.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Next contact your bank. There is often some processing time before a refund is posted.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you’ve done all of this and you still have not received your refund yet, please contact us at {email address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<b>Sale items</b>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Only regular priced items may be refunded. Sale items cannot be refunded.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Exchanges</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>We only replace items if they are defective or damaged. If you need to exchange it for the same item, send us an email at {email address} and send your item to: {physical address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Gifts</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If the item was marked as a gift when purchased and shipped directly to you, you’ll receive a gift credit for the value of your return. Once the returned item is received, a gift certificate will be mailed to you.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If the item wasn’t marked as a gift when purchased, or the gift giver had the order shipped to themselves to give to you later, we will send a refund to the gift giver and they will find out about your return.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Shipping returns</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>To return your product, you should mail your product to: {physical address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>You will be responsible for paying for your own shipping costs for returning your item. Shipping costs are non-refundable. If you receive a refund, the cost of return shipping will be deducted from your refund.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Depending on where you live, the time it may take for your exchanged product to reach you may vary.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are returning more expensive items, you may consider using a trackable shipping service or purchasing shipping insurance. We don’t guarantee that we will receive your returned item.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Need help?</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Contact us at {email} for questions related to refunds and returns.</p>\n<!-- /wp:paragraph -->', 'Återbetalnings- och returpolicy', '', 'draft', 'closed', 'closed', '', 'aterbetalning_returer', '', '', '2023-04-19 09:40:04', '0000-00-00 00:00:00', '', 0, 'http://localhost/labb2-carolina/?page_id=10', 0, 'page', '', 0),
(11, 1, '2023-04-19 09:48:23', '2023-04-19 07:48:23', '', 'hoodie-with-logo-2.jpg', '', 'inherit', 'open', 'closed', '', 'hoodie-with-logo-2-jpg', '', '', '2023-04-19 09:48:23', '2023-04-19 07:48:23', '', 0, 'http://localhost/labb2-carolina/wp-content/uploads/2023/04/hoodie-with-logo-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(12, 1, '2023-04-19 09:48:23', '2023-04-19 07:48:23', 'Hoodie in sweatshirt fabric made from a cotton blend.', 'AUTO-DRAFT', 'This is a simple product.', 'auto-draft', 'open', 'closed', '', 'hoodie-with-logo', '', '', '2023-04-19 09:48:23', '2023-04-19 07:48:23', '', 0, 'http://localhost/labb2-carolina/produkt/hoodie-with-logo/', 0, 'product', '', 0),
(14, 1, '2023-04-19 10:07:02', '2023-04-19 08:07:02', '', 'handel_2kg', '', 'inherit', 'open', 'closed', '', 'handel_2kg', '', '', '2023-04-19 12:10:27', '2023-04-19 10:10:27', '', 0, 'http://localhost/labb2-carolina/wp-content/uploads/2023/04/handel_2kg.png', 0, 'attachment', 'image/png', 0),
(15, 1, '2023-04-19 10:07:03', '2023-04-19 08:07:03', '', 'hantel_4kg', '', 'inherit', 'open', 'closed', '', 'hantel_4kg', '', '', '2023-04-19 12:12:43', '2023-04-19 10:12:43', '', 0, 'http://localhost/labb2-carolina/wp-content/uploads/2023/04/hantel_4kg.png', 0, 'attachment', 'image/png', 0),
(16, 1, '2023-04-19 10:07:05', '2023-04-19 08:07:05', '', 'hantel_5kg', '', 'inherit', 'open', 'closed', '', 'hantel_5kg', '', '', '2023-04-19 12:13:19', '2023-04-19 10:13:19', '', 0, 'http://localhost/labb2-carolina/wp-content/uploads/2023/04/hantel_5kg.png', 0, 'attachment', 'image/png', 0),
(17, 1, '2023-04-19 10:07:06', '2023-04-19 08:07:06', '', 'presentkort', '', 'inherit', 'open', 'closed', '', 'presentkort', '', '', '2023-04-19 10:07:06', '2023-04-19 08:07:06', '', 0, 'http://localhost/labb2-carolina/wp-content/uploads/2023/04/presentkort.png', 0, 'attachment', 'image/png', 0),
(20, 1, '2023-04-19 10:07:08', '2023-04-19 08:07:08', '', 'yogamatta', '', 'inherit', 'open', 'closed', '', 'yogamatta', '', '', '2023-04-19 11:38:04', '2023-04-19 09:38:04', '', 0, 'http://localhost/labb2-carolina/wp-content/uploads/2023/04/yogamatta.png', 0, 'attachment', 'image/png', 0),
(21, 1, '2023-04-19 10:07:10', '2023-04-19 08:07:10', '', 'yogamatta_pink', '', 'inherit', 'open', 'closed', '', 'yogamatta_pink', '', '', '2023-04-19 10:07:10', '2023-04-19 08:07:10', '', 0, 'http://localhost/labb2-carolina/wp-content/uploads/2023/04/yogamatta_pink.png', 0, 'attachment', 'image/png', 0),
(22, 1, '2023-04-19 10:08:15', '2023-04-19 08:08:15', 'Tights som passar perfekt till yoga, pilates och stretching.\r\n\r\nSpecifikationer:\r\n- Passform: Åtsittande\r\n- Material: 67 % återvunnen polyester, 28 % återvunnen polyamid, 5 % elastan\r\n- Andas: Ja\r\n- Leder bort fukt: Ja\r\n\r\nÖvriga detaljer:\r\n- Bred resår i midjan\r\n- Liten logo på vänster höft', 'Yogatights', 'Tights som passar perfekt till yoga, pilates och stretching.', 'publish', 'open', 'closed', '', 'yogatights', '', '', '2023-04-20 15:56:52', '2023-04-20 13:56:52', '', 0, 'http://localhost/labb2-carolina/?post_type=product&#038;p=22', 0, 'product', '', 0),
(23, 1, '2023-04-19 10:37:24', '2023-04-19 08:37:24', '', 'Yogatights - Large', 'Storlek: Large', 'publish', 'closed', 'closed', '', 'yogatights-large', '', '', '2023-04-19 10:43:18', '2023-04-19 08:43:18', '', 22, 'http://localhost/labb2-carolina/?post_type=product_variation&p=23', 1, 'product_variation', '', 0),
(24, 1, '2023-04-19 10:37:24', '2023-04-19 08:37:24', '', 'Yogatights - Medium', 'Storlek: Medium', 'publish', 'closed', 'closed', '', 'yogatights-medium', '', '', '2023-04-19 10:43:18', '2023-04-19 08:43:18', '', 22, 'http://localhost/labb2-carolina/?post_type=product_variation&p=24', 2, 'product_variation', '', 0),
(25, 1, '2023-04-19 10:37:24', '2023-04-19 08:37:24', '', 'Yogatights - Small', 'Storlek: Small', 'publish', 'closed', 'closed', '', 'yogatights-small', '', '', '2023-04-19 10:43:18', '2023-04-19 08:43:18', '', 22, 'http://localhost/labb2-carolina/?post_type=product_variation&p=25', 3, 'product_variation', '', 0),
(26, 1, '2023-04-19 11:32:28', '2023-04-19 09:32:28', 'Träningsmatta som säkerställer bra grepp och bra dämpning mot golvet och ger en bra grund för grundläggande flexibilitet och styrkeövningar. 5 mm tjock.\r\n\r\nSpecifikationer:\r\n- Tjocklek: 5 mm', 'Yogamatta', 'Träningsmatta som säkerställer bra grepp och bra dämpning mot golvet och ger en bra grund för grundläggande flexibilitet och styrkeövningar.', 'publish', 'open', 'closed', '', 'yogamatta', '', '', '2023-04-19 11:39:03', '2023-04-19 09:39:03', '', 0, 'http://localhost/labb2-carolina/?post_type=product&#038;p=26', 0, 'product', '', 0),
(27, 1, '2023-04-19 11:40:11', '2023-04-19 09:40:11', '', 'AUTO-DRAFT', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2023-04-19 11:40:11', '2023-04-19 09:40:11', '', 0, 'http://localhost/labb2-carolina/?post_type=product&p=27', 0, 'product', '', 0),
(28, 1, '2023-04-19 11:40:11', '2023-04-19 09:40:11', 'Träningsmatta som säkerställer bra grepp och bra dämpning mot golvet och ger en bra grund för grundläggande flexibilitet och styrkeövningar. 5 mm tjock.\n\nSpecifikationer:\n- Tjocklek: 5 mm', 'Yogamatta', '<p>Träningsmatta som säkerställer bra grepp och bra dämpning mot golvet och ger en bra grund för grundläggande flexibilitet och styrkeövningar.</p>', 'inherit', 'closed', 'closed', '', '26-autosave-v1', '', '', '2023-04-19 11:40:11', '2023-04-19 09:40:11', '', 26, 'http://localhost/labb2-carolina/?p=28', 0, 'revision', '', 0),
(29, 1, '2023-04-19 11:42:43', '2023-04-19 09:42:43', 'Teknisk träningströja i fukttransporterande och snabbtorkande material. Half Zip fram, Puma-logga och tumhål.\r\nPuma Runtrain 1/4 är ett utmärkt val för all slags av träning.\r\n\r\ndryCELL-tekniken håller dig torr och sval under aktivitet.\r\n\r\nHalv dragkedja framtill möjliggör ventilation.\r\n\r\nTumhålen vid muffen hindrar ärmarna från att glida upp.\r\n\r\nSpecifikationer:\r\n- Passform: Åtsittande\r\n- Material: 100 % återvunnen polyester\r\n- Material som andas: Ja\r\n- Fukttransporterande: Ja\r\n\r\nÖvriga detaljer:\r\n- Halv-Zip fram\r\n- Puma-logga vid vänster bröst\r\n- Hål för tummen', 'Träningstopp', 'Teknisk träningströja i fukttransporterande och snabbtorkande material. Half Zip fram, Puma-logga och tumhål.', 'publish', 'open', 'closed', '', 'traningstopp', '', '', '2023-04-20 15:58:23', '2023-04-20 13:58:23', '', 0, 'http://localhost/labb2-carolina/?post_type=product&#038;p=29', 0, 'product', '', 0),
(30, 1, '2023-04-19 11:46:24', '2023-04-19 09:46:24', '', 'Träningstopp - Rosa, Large', 'Färg: Rosa, Storlek: Large', 'publish', 'closed', 'closed', '', 'traningstopp-large-rosa', '', '', '2023-04-20 15:58:19', '2023-04-20 13:58:19', '', 29, 'http://localhost/labb2-carolina/?post_type=product_variation&p=30', 1, 'product_variation', '', 0),
(31, 1, '2023-04-19 11:46:24', '2023-04-19 09:46:24', '', 'Träningstopp - Rosa, Medium', 'Färg: Rosa, Storlek: Medium', 'publish', 'closed', 'closed', '', 'traningstopp-medium-rosa', '', '', '2023-04-20 15:58:19', '2023-04-20 13:58:19', '', 29, 'http://localhost/labb2-carolina/?post_type=product_variation&p=31', 2, 'product_variation', '', 0),
(32, 1, '2023-04-19 11:46:24', '2023-04-19 09:46:24', '', 'Träningstopp - Rosa, Small', 'Färg: Rosa, Storlek: Small', 'publish', 'closed', 'closed', '', 'traningstopp-small-rosa', '', '', '2023-04-20 15:58:19', '2023-04-20 13:58:19', '', 29, 'http://localhost/labb2-carolina/?post_type=product_variation&p=32', 3, 'product_variation', '', 0),
(33, 1, '2023-04-19 11:46:24', '2023-04-19 09:46:24', '', 'Träningstopp - Svart, Large', 'Färg: Svart, Storlek: Large', 'publish', 'closed', 'closed', '', 'traningstopp-large-svart', '', '', '2023-04-20 15:58:19', '2023-04-20 13:58:19', '', 29, 'http://localhost/labb2-carolina/?post_type=product_variation&p=33', 4, 'product_variation', '', 0),
(34, 1, '2023-04-19 11:46:24', '2023-04-19 09:46:24', '', 'Träningstopp - Svart, Medium', 'Färg: Svart, Storlek: Medium', 'publish', 'closed', 'closed', '', 'traningstopp-medium-svart', '', '', '2023-04-20 15:58:19', '2023-04-20 13:58:19', '', 29, 'http://localhost/labb2-carolina/?post_type=product_variation&p=34', 5, 'product_variation', '', 0),
(35, 1, '2023-04-19 11:46:24', '2023-04-19 09:46:24', '', 'Träningstopp - Svart, Small', 'Färg: Svart, Storlek: Small', 'publish', 'closed', 'closed', '', 'traningstopp-small-svart', '', '', '2023-04-20 15:58:19', '2023-04-20 13:58:19', '', 29, 'http://localhost/labb2-carolina/?post_type=product_variation&p=35', 6, 'product_variation', '', 0),
(36, 1, '2023-04-19 12:00:47', '2023-04-19 10:00:47', 'Hantel av gjutjärn med en flexibel gummiyta. Effektivt redskap för styrke- och konditionsträning. Gummiytan skyddar golvet mot nötning.\r\nEtt effektivt redskap för styrke- och konditionsträning. Tillverkade i gjutjärn med en flexibel gummiyta som skyddar golvet.\r\nNeopren-handtaget säkerställer ett fast grepp, även med svettiga handflator.\r\nStyrketräning är en av de mest effektiva metoderna för att minska kroppsfett, öka muskelmassan och bränna kalorier.\r\nAnvänd hantlarna för isolerade såväl som sammansatta rörelser, som extra vikt under knäböj eller armhävningar för extra motstånd.\r\n\r\nSpecifikationer:\r\n- Grepp: Sträv neoprenyta\r\n- Yttermaterial: Neopren\r\n- Innermaterial: Gjutjärn\r\n\r\nÖvriga detaljer:\r\n- Skyddar golvet mot slitage\r\n- Effektivt redskap för styrke- och konditionsträning\r\n- Handtaget säkerställer ett fast grepp', 'Hantel', 'Hantel av gjutjärn med en flexibel gummiyta. Effektivt redskap för styrke- och konditionsträning.', 'publish', 'open', 'closed', '', 'hantel', '', '', '2023-04-19 12:16:00', '2023-04-19 10:16:00', '', 0, 'http://localhost/labb2-carolina/?post_type=product&#038;p=36', 0, 'product', '', 0),
(38, 1, '2023-04-19 12:08:40', '2023-04-19 10:08:40', '', 'Hantel - 2kg', 'Vikt: 2kg', 'publish', 'closed', 'closed', '', 'hantel-2kg', '', '', '2023-04-19 12:14:52', '2023-04-19 10:14:52', '', 36, 'http://localhost/labb2-carolina/?post_type=product_variation&p=38', 1, 'product_variation', '', 0),
(39, 1, '2023-04-19 12:08:40', '2023-04-19 10:08:40', '', 'Hantel - 4kg', 'Vikt: 4kg', 'publish', 'closed', 'closed', '', 'hantel-4kg', '', '', '2023-04-19 12:13:53', '2023-04-19 10:13:53', '', 36, 'http://localhost/labb2-carolina/?post_type=product_variation&p=39', 2, 'product_variation', '', 0),
(40, 1, '2023-04-19 12:08:40', '2023-04-19 10:08:40', '', 'Hantel - 5kg', 'Vikt: 5kg', 'publish', 'closed', 'closed', '', 'hantel-5kg', '', '', '2023-04-19 12:13:53', '2023-04-19 10:13:53', '', 36, 'http://localhost/labb2-carolina/?post_type=product_variation&p=40', 3, 'product_variation', '', 0),
(41, 1, '2023-04-19 12:16:32', '2023-04-19 10:16:32', '', 'AUTO-DRAFT', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2023-04-19 12:16:32', '2023-04-19 10:16:32', '', 0, 'http://localhost/labb2-carolina/?post_type=product&p=41', 0, 'product', '', 0),
(42, 1, '2023-04-19 12:16:55', '2023-04-19 10:16:55', '', 'AUTO-DRAFT', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2023-04-19 12:16:55', '2023-04-19 10:16:55', '', 0, 'http://localhost/labb2-carolina/?post_type=product&p=42', 0, 'product', '', 0),
(43, 1, '2023-04-19 12:35:07', '2023-04-19 10:35:07', '', 'AUTO-DRAFT', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2023-04-19 12:35:07', '2023-04-19 10:35:07', '', 0, 'http://localhost/labb2-carolina/?post_type=product&p=43', 0, 'product', '', 0),
(44, 1, '2023-04-19 12:35:38', '2023-04-19 10:35:38', '', 'Träningsschema', '', 'inherit', 'open', 'closed', '', 'traningsschema', '', '', '2023-04-19 14:18:16', '2023-04-19 12:18:16', '', 0, 'http://localhost/labb2-carolina/wp-content/uploads/2023/04/Traningsschema.png', 0, 'attachment', 'image/png', 0),
(45, 1, '2023-04-19 13:59:11', '2023-04-19 11:59:11', 'Den kompletta guiden till optimal träning!', 'Träningsschema', 'Den kompletta guiden till optimal träning!', 'publish', 'open', 'closed', '', 'traningsschema', '', '', '2023-04-20 14:59:01', '2023-04-20 12:59:01', '', 0, 'http://localhost/labb2-carolina/?post_type=product&#038;p=45', 0, 'product', '', 0),
(46, 1, '2023-04-19 14:05:36', '2023-04-19 12:05:36', '', 'TräningsschemaPDF', '', 'inherit', 'open', 'closed', '', 'traningsschemapdf', '', '', '2023-04-19 14:05:36', '2023-04-19 12:05:36', '', 0, 'http://localhost/labb2-carolina/wp-content/uploads/2023/04/TraningsschemaPDF.pdf', 0, 'attachment', 'application/pdf', 0),
(47, 1, '2023-04-20 15:55:47', '2023-04-20 13:55:47', '', 'topp_pink', '', 'inherit', 'open', 'closed', '', 'topp_pink', '', '', '2023-04-20 15:57:26', '2023-04-20 13:57:26', '', 0, 'http://localhost/labb2-carolina/wp-content/uploads/2023/04/topp_pink.png', 0, 'attachment', 'image/png', 0),
(48, 1, '2023-04-20 15:55:49', '2023-04-20 13:55:49', '', 'topp_black', '', 'inherit', 'open', 'closed', '', 'topp_black', '', '', '2023-04-20 15:58:01', '2023-04-20 13:58:01', '', 0, 'http://localhost/labb2-carolina/wp-content/uploads/2023/04/topp_black.png', 0, 'attachment', 'image/png', 0),
(49, 1, '2023-04-20 15:56:23', '2023-04-20 13:56:23', '', 'yogatights', '', 'inherit', 'open', 'closed', '', 'yogatights-2', '', '', '2023-04-20 15:56:49', '2023-04-20 13:56:49', '', 0, 'http://localhost/labb2-carolina/wp-content/uploads/2023/04/yogatights.png', 0, 'attachment', 'image/png', 0),
(50, 1, '2023-04-21 09:56:04', '2023-04-21 07:55:43', ' ', '', '', 'publish', 'closed', 'closed', '', '50', '', '', '2023-04-21 09:56:04', '2023-04-21 07:56:04', '', 0, 'http://localhost/labb2-carolina/?p=50', 1, 'nav_menu_item', '', 0),
(51, 1, '2023-04-21 09:56:04', '2023-04-21 07:55:43', ' ', '', '', 'publish', 'closed', 'closed', '', '51', '', '', '2023-04-21 09:56:04', '2023-04-21 07:56:04', '', 0, 'http://localhost/labb2-carolina/?p=51', 2, 'nav_menu_item', '', 0),
(52, 1, '2023-04-21 09:56:04', '2023-04-21 07:55:43', ' ', '', '', 'publish', 'closed', 'closed', '', '52', '', '', '2023-04-21 09:56:04', '2023-04-21 07:56:04', '', 0, 'http://localhost/labb2-carolina/?p=52', 3, 'nav_menu_item', '', 0),
(53, 1, '2023-04-23 20:45:45', '2023-04-23 18:45:45', '', 'Automatiskt utkast', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-04-23 20:45:45', '2023-04-23 18:45:45', '', 0, 'http://localhost/labb2-carolina/?page_id=53', 0, 'page', '', 0),
(54, 1, '2023-04-23 20:45:51', '2023-04-23 18:45:51', '', 'Automatiskt utkast', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-04-23 20:45:51', '2023-04-23 18:45:51', '', 0, 'http://localhost/labb2-carolina/?page_id=54', 0, 'page', '', 0),
(55, 1, '2023-04-23 20:45:57', '2023-04-23 18:45:57', '', 'Automatiskt utkast', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-04-23 20:45:57', '2023-04-23 18:45:57', '', 0, 'http://localhost/labb2-carolina/?page_id=55', 0, 'page', '', 0),
(56, 1, '2023-04-23 20:46:31', '2023-04-23 18:46:31', '<!-- wp:paragraph -->\n<p>Detta är en exempelsida. Den skiljer sig från ett blogginlägg genom att den finns kvar på samma plats och kommer att visas i din webbplatsnavigering (i de flesta teman). De flesta börjar med en Om-sida som presenterar dem för potentiella besökare. Den skulle t.ex kunna ha följande innehåll:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hej där! Jag är cykelbud på dagen, blivande skådespelare på natten och detta är min blogg. Jag bor i Örebro, har en katt som heter Lurv och jag gillar Pina Coladas. (och att simma i Göta kanal).</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>... eller något liknande detta:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Företaget AB grundades 1971 och har sedan dess varit den största leverantören av grunk-manicker på den svenska marknaden. FAB finns i utkanten av Grönköping, har drygt 20&nbsp;000 anställda och läser veckobladet varje år.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Som ny WordPress-användare bör du gå till <a href="http://localhost/labb2-carolina/wp-admin/">din adminpanel</a> för att ta bort denna sida och skapa nya sidor för ditt innehåll. Lycka till!</p>\n<!-- /wp:paragraph -->', 'Exempelsida', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2023-04-23 20:46:31', '2023-04-23 18:46:31', '', 2, 'http://localhost/labb2-carolina/?p=56', 0, 'revision', '', 0),
(57, 1, '2023-04-23 20:46:35', '2023-04-23 18:46:35', '', 'Automatiskt utkast', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-04-23 20:46:35', '2023-04-23 18:46:35', '', 0, 'http://localhost/labb2-carolina/?page_id=57', 0, 'page', '', 0),
(58, 1, '2023-04-23 21:09:27', '2023-04-23 19:09:27', '', 'Hem', '', 'trash', 'closed', 'closed', '', 'hem__trashed', '', '', '2023-04-24 15:14:37', '2023-04-24 13:14:37', '', 0, 'http://localhost/labb2-carolina/?page_id=58', 0, 'page', '', 0),
(59, 1, '2023-04-23 21:09:46', '2023-04-23 19:09:46', '', 'Hem', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2023-04-23 21:09:46', '2023-04-23 19:09:46', '', 58, 'http://localhost/labb2-carolina/?p=59', 0, 'revision', '', 0),
(60, 1, '2023-04-23 21:35:32', '2023-04-23 19:35:32', '', 'sportbackground3', '', 'inherit', 'open', 'closed', '', 'sportbackground3', '', '', '2023-04-23 21:35:51', '2023-04-23 19:35:51', '', 58, 'http://localhost/labb2-carolina/wp-content/uploads/2023/04/sportbackground3.png', 0, 'attachment', 'image/png', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(12, 2, 0),
(12, 15, 0),
(22, 4, 0),
(22, 19, 0),
(22, 20, 0),
(22, 21, 0),
(22, 22, 0),
(22, 25, 0),
(26, 2, 0),
(26, 23, 0),
(26, 26, 0),
(29, 4, 0),
(29, 19, 0),
(29, 20, 0),
(29, 21, 0),
(29, 22, 0),
(29, 24, 0),
(29, 29, 0),
(29, 30, 0),
(36, 4, 0),
(36, 23, 0),
(36, 27, 0),
(36, 32, 0),
(36, 34, 0),
(36, 35, 0),
(45, 2, 0),
(45, 28, 0),
(50, 37, 0),
(51, 37, 0),
(52, 37, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'product_type', '', 0, 2),
(3, 3, 'product_type', '', 0, 0),
(4, 4, 'product_type', '', 0, 3),
(5, 5, 'product_type', '', 0, 0),
(6, 6, 'product_visibility', '', 0, 0),
(7, 7, 'product_visibility', '', 0, 0),
(8, 8, 'product_visibility', '', 0, 0),
(9, 9, 'product_visibility', '', 0, 0),
(10, 10, 'product_visibility', '', 0, 0),
(11, 11, 'product_visibility', '', 0, 0),
(12, 12, 'product_visibility', '', 0, 0),
(13, 13, 'product_visibility', '', 0, 0),
(14, 14, 'product_visibility', '', 0, 0),
(15, 15, 'product_cat', '', 0, 0),
(19, 19, 'pa_storlek', '', 0, 2),
(20, 20, 'pa_storlek', '', 0, 2),
(21, 21, 'pa_storlek', '', 0, 2),
(22, 22, 'product_cat', '', 0, 2),
(23, 23, 'product_cat', '', 0, 2),
(24, 24, 'product_cat', '', 22, 1),
(25, 25, 'product_cat', '', 22, 1),
(26, 26, 'product_cat', '', 23, 1),
(27, 27, 'product_cat', '', 23, 1),
(28, 28, 'product_cat', '', 0, 1),
(29, 29, 'pa_farg', '', 0, 1),
(30, 30, 'pa_farg', '', 0, 1),
(32, 32, 'pa_vikt', '', 0, 1),
(34, 34, 'pa_vikt', '', 0, 1),
(35, 35, 'pa_vikt', '', 0, 1),
(36, 36, 'product_shipping_class', '', 0, 0),
(37, 37, 'nav_menu', '', 0, 3) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#
INSERT INTO `wp_termmeta` ( `meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(3, 15, 'product_count_product_cat', '0'),
(4, 19, 'order', '0'),
(5, 20, 'order', '0'),
(6, 21, 'order', '0'),
(7, 22, 'order', '0'),
(8, 22, 'display_type', ''),
(9, 22, 'thumbnail_id', '0'),
(10, 23, 'order', '0'),
(11, 23, 'display_type', ''),
(12, 23, 'thumbnail_id', '0'),
(13, 24, 'order', '0'),
(14, 24, 'display_type', ''),
(15, 24, 'thumbnail_id', '0'),
(16, 25, 'order', '0'),
(17, 25, 'display_type', ''),
(18, 25, 'thumbnail_id', '0'),
(19, 26, 'order', '0'),
(20, 26, 'display_type', ''),
(21, 26, 'thumbnail_id', '0'),
(22, 27, 'order', '0'),
(23, 27, 'display_type', ''),
(24, 27, 'thumbnail_id', '0'),
(25, 28, 'order', '0'),
(26, 28, 'display_type', ''),
(27, 28, 'thumbnail_id', '0'),
(28, 22, 'product_count_product_cat', '2'),
(29, 25, 'product_count_product_cat', '1'),
(30, 23, 'product_count_product_cat', '2'),
(31, 26, 'product_count_product_cat', '1'),
(32, 29, 'order', '0'),
(33, 30, 'order', '0'),
(34, 24, 'product_count_product_cat', '1'),
(36, 32, 'order', '0'),
(38, 34, 'order', '0'),
(39, 35, 'order', '0'),
(40, 27, 'product_count_product_cat', '1'),
(41, 28, 'product_count_product_cat', '1') ;

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Okategoriserade', 'okategoriserade', 0),
(2, 'simple', 'simple', 0),
(3, 'grouped', 'grouped', 0),
(4, 'variable', 'variable', 0),
(5, 'external', 'external', 0),
(6, 'exclude-from-search', 'exclude-from-search', 0),
(7, 'exclude-from-catalog', 'exclude-from-catalog', 0),
(8, 'featured', 'featured', 0),
(9, 'outofstock', 'outofstock', 0),
(10, 'rated-1', 'rated-1', 0),
(11, 'rated-2', 'rated-2', 0),
(12, 'rated-3', 'rated-3', 0),
(13, 'rated-4', 'rated-4', 0),
(14, 'rated-5', 'rated-5', 0),
(15, 'Okategoriserad', 'okategoriserad', 0),
(19, 'Small', 'small', 0),
(20, 'Medium', 'medium', 0),
(21, 'Large', 'large', 0),
(22, 'Kläder', 'klader', 0),
(23, 'Utrustning', 'utrustning', 0),
(24, 'Överdel', 'overdel', 0),
(25, 'Underdel', 'underdel', 0),
(26, 'Yoga', 'yoga', 0),
(27, 'Gym', 'gym', 0),
(28, 'Träningsschema', 'traningsschema', 0),
(29, 'Svart', 'svart', 0),
(30, 'Rosa', 'rosa', 0),
(32, '5kg', '5kg', 0),
(34, '4kg', '4kg', 0),
(35, '2kg', '2kg', 0),
(36, 'Fragile', 'fragile', 0),
(37, 'Undermeny', 'undermeny', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'medie-admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:2:{s:64:"1e5c37091476c11d514fcb563e9088d388e0dcc2959aa1ec0dc78abba29a289e";a:4:{s:10:"expiration";i:1682445808;s:2:"ip";s:3:"::1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36";s:5:"login";i:1682273008;}s:64:"65a660dc3041f36595cb656aa63f87f4912718ff4f6dd247032cc5db7072d9a8";a:4:{s:10:"expiration";i:1682513251;s:2:"ip";s:3:"::1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36";s:5:"login";i:1682340451;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, '_woocommerce_tracks_anon_id', 'woo:+13kseB2Fs4eUKTwDg2/9/JO'),
(19, 1, 'last_update', '1682340741'),
(20, 1, 'woocommerce_admin_task_list_tracked_started_tasks', '{"products":1,"tax":2}'),
(21, 1, 'meta-box-order_product', 'a:3:{s:4:"side";s:84:"submitdiv,postimagediv,woocommerce-product-images,product_catdiv,tagsdiv-product_tag";s:6:"normal";s:55:"woocommerce-product-data,postcustom,slugdiv,postexcerpt";s:8:"advanced";s:0:"";}'),
(22, 1, 'wc_last_active', '1682294400'),
(23, 1, 'wp_user-settings', 'libraryContent=browse'),
(24, 1, 'wp_user-settings-time', '1681892394'),
(26, 1, '_woocommerce_persistent_cart_1', 'a:1:{s:4:"cart";a:1:{s:32:"0942388adaa4ecef4b8b87257f625e6c";a:11:{s:3:"key";s:32:"0942388adaa4ecef4b8b87257f625e6c";s:10:"product_id";i:29;s:12:"variation_id";i:32;s:9:"variation";a:2:{s:17:"attribute_pa_farg";s:4:"rosa";s:20:"attribute_pa_storlek";s:5:"small";}s:8:"quantity";i:3;s:9:"data_hash";s:32:"2090b92a59e0639d31f416571b905024";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:1:{i:1;d:179.400000000000005684341886080801486968994140625;}s:5:"total";a:1:{i:1;d:179.400000000000005684341886080801486968994140625;}}s:13:"line_subtotal";d:717.6000000000000227373675443232059478759765625;s:17:"line_subtotal_tax";d:179;s:10:"line_total";d:717.6000000000000227373675443232059478759765625;s:8:"line_tax";d:179;}}}'),
(27, 1, 'woocommerce_admin_help_panel_highlight_shown', '"yes"'),
(29, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(30, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:21:"add-post-type-product";i:1;s:12:"add-post_tag";i:2;s:15:"add-product_tag";}'),
(31, 1, 'nav_menu_recently_edited', '37'),
(32, 1, 'closedpostboxes_nav-menus', 'a:0:{}'),
(34, 1, 'wp_persisted_preferences', 'a:4:{s:14:"core/edit-site";a:3:{s:12:"welcomeGuide";b:0;s:26:"isComplementaryAreaVisible";b:1;s:18:"welcomeGuideStyles";b:0;}s:9:"_modified";s:24:"2023-04-23T19:27:31.752Z";s:14:"core/edit-post";a:3:{s:26:"isComplementaryAreaVisible";b:1;s:12:"welcomeGuide";b:0;s:10:"openPanels";a:9:{i:0;s:12:"post-excerpt";i:1;s:23:"taxonomy-panel-post_tag";i:2;s:14:"featured-image";i:3;s:23:"taxonomy-panel-category";i:4;s:26:"taxonomy-panel-antal_sidor";i:5;s:22:"taxonomy-panel-bokstil";i:6;s:16:"discussion-panel";i:7;s:15:"page-attributes";i:8;s:11:"post-status";}}s:17:"core/edit-widgets";a:4:{s:26:"isComplementaryAreaVisible";b:1;s:12:"welcomeGuide";b:0;s:20:"keepCaretInsideBlock";b:0;s:12:"fixedToolbar";b:0;}}'),
(36, 1, 'woocommerce_admin_homepage_stats', '{"installJetpackDismissed":true}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'medie-admin', '$P$B4GiNJhTMFeZZftDQNPSjWgCL.b7nW1', 'medie-admin', 'henrikutbildare@gmail.com', 'http://localhost/labb2-carolina', '2023-04-19 07:26:53', '', 0, 'medie-admin') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_admin_note_actions`
#

DROP TABLE IF EXISTS `wp_wc_admin_note_actions`;


#
# Table structure of table `wp_wc_admin_note_actions`
#

CREATE TABLE `wp_wc_admin_note_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `note_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `query` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `actioned_text` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `nonce_action` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `nonce_name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `note_id` (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=835 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_admin_note_actions`
#
INSERT INTO `wp_wc_admin_note_actions` ( `action_id`, `note_id`, `name`, `label`, `query`, `status`, `actioned_text`, `nonce_action`, `nonce_name`) VALUES
(60, 50, 'connect', 'Anslut', '?page=wc-addons&section=helper', 'unactioned', '', NULL, NULL),
(120, 51, 'customize-store-with-storefront', 'Nu kör vi!', 'http://localhost/labb2-carolina/wp-admin/themes.php?page=storefront-welcome', 'actioned', '', NULL, NULL),
(121, 52, 'visit-the-theme-marketplace', 'Besök temamarknadsplatsen', 'https://woocommerce.com/product-category/themes/?utm_source=inbox&utm_medium=product', 'actioned', '', NULL, NULL),
(122, 53, 'learn-more', 'Lär dig mer', 'https://woocommerce.com/posts/pre-launch-checklist-the-essentials/?utm_source=inbox&utm_medium=product', 'actioned', '', NULL, NULL),
(182, 54, 'day-after-first-product', 'Lär dig mer', 'https://woocommerce.com/document/woocommerce-customizer/?utm_source=inbox&utm_medium=product', 'actioned', '', NULL, NULL),
(183, 55, 'learn-more', 'Lär dig mer', 'https://woocommerce.com/mobile/?utm_medium=product', 'actioned', '', NULL, NULL),
(184, 56, 'online-clothing-store', 'Lär dig mer', 'https://woocommerce.com/posts/starting-an-online-clothing-store/?utm_source=inbox&utm_medium=product', 'actioned', '', NULL, NULL),
(775, 57, 'remove-legacy-coupon-menu', 'Ta bort äldre rabattkodsmeny', 'http://localhost/labb2-carolina/wp-admin/admin.php?page=wc-admin&action=remove-coupon-menu', 'actioned', '', NULL, NULL),
(776, 1, 'browse_extensions', 'Browse extensions', 'http://localhost/labb2-carolina/wp-admin/admin.php?page=wc-addons', 'unactioned', '', NULL, NULL),
(777, 2, 'wayflyer_bnpl_q4_2021', 'Level up with funding', 'https://woocommerce.com/products/wayflyer/?utm_source=inbox_note&utm_medium=product&utm_campaign=wayflyer_bnpl_q4_2021', 'actioned', '', NULL, NULL),
(778, 3, 'wc_shipping_mobile_app_usps_q4_2021', 'Get WooCommerce Shipping', 'https://woocommerce.com/woocommerce-shipping/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc_shipping_mobile_app_usps_q4_2021', 'actioned', '', NULL, NULL),
(779, 4, 'learn-more', 'Learn more', 'https://docs.woocommerce.com/document/woocommerce-shipping-and-tax/?utm_source=inbox', 'unactioned', '', NULL, NULL),
(780, 5, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/ecommerce-shipping-solutions-guide/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'actioned', '', NULL, NULL),
(781, 6, 'optimizing-the-checkout-flow', 'Learn more', 'https://woocommerce.com/posts/optimizing-woocommerce-checkout?utm_source=inbox_note&utm_medium=product&utm_campaign=optimizing-the-checkout-flow', 'actioned', '', NULL, NULL),
(782, 7, 'qualitative-feedback-from-new-users', 'Share feedback', 'https://automattic.survey.fm/wc-pay-new', 'actioned', '', NULL, NULL),
(783, 8, 'share-feedback', 'Share feedback', 'http://automattic.survey.fm/paypal-feedback', 'unactioned', '', NULL, NULL),
(784, 9, 'get-started', 'Get started', 'https://woocommerce.com/products/google-listings-and-ads?utm_source=inbox_note&utm_medium=product&utm_campaign=get-started', 'actioned', '', NULL, NULL),
(785, 10, 'update-wc-subscriptions-3-0-15', 'View latest version', 'http://localhost/labb2-carolina/wp-admin/&page=wc-addons&section=helper', 'actioned', '', NULL, NULL),
(786, 11, 'update-wc-core-5-4-0', 'How to update WooCommerce', 'https://docs.woocommerce.com/document/how-to-update-woocommerce/', 'actioned', '', NULL, NULL),
(787, 14, 'ppxo-pps-install-paypal-payments-1', 'View upgrade guide', 'https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/', 'actioned', '', NULL, NULL),
(788, 15, 'ppxo-pps-install-paypal-payments-2', 'View upgrade guide', 'https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/', 'actioned', '', NULL, NULL),
(789, 16, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(790, 16, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(791, 17, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(792, 17, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(793, 18, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(794, 18, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(795, 19, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(796, 19, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(797, 20, 'share-feedback', 'Share feedback', 'https://automattic.survey.fm/store-management', 'unactioned', '', NULL, NULL),
(798, 21, 'learn-more', 'Learn more', 'https://developer.woocommerce.com/2022/03/10/woocommerce-3-5-10-6-3-1-security-releases/', 'unactioned', '', NULL, NULL),
(799, 21, 'woocommerce-core-paypal-march-2022-dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(800, 22, 'learn-more', 'Learn more', 'https://developer.woocommerce.com/2022/03/10/woocommerce-3-5-10-6-3-1-security-releases/', 'unactioned', '', NULL, NULL),
(801, 22, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(802, 23, 'pinterest_03_2022_update', 'Update Instructions', 'https://woocommerce.com/document/pinterest-for-woocommerce/?utm_source=inbox_note&utm_medium=product&utm_campaign=pinterest_03_2022_update#section-3', 'actioned', '', NULL, NULL),
(803, 24, 'store_setup_survey_survey_q2_2022_share_your_thoughts', 'Tell us how it’s going', 'https://automattic.survey.fm/store-setup-survey-2022', 'actioned', '', NULL, NULL),
(804, 25, 'wc-admin-wisepad3', 'Grow my business offline', 'https://woocommerce.com/products/wisepad3-card-reader/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wisepad3', 'actioned', '', NULL, NULL),
(805, 26, 'learn-more', 'Find out more', 'https://developer.woocommerce.com/2022/08/09/woocommerce-payments-3-9-4-4-5-1-security-releases/', 'unactioned', '', NULL, NULL),
(806, 26, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(807, 27, 'learn-more', 'Find out more', 'https://developer.woocommerce.com/2022/08/09/woocommerce-payments-3-9-4-4-5-1-security-releases/', 'unactioned', '', NULL, NULL),
(808, 27, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(809, 28, 'google_listings_ads_custom_attribute_mapping_q4_2022', 'Learn more', 'https://woocommerce.com/document/google-listings-and-ads/?utm_source=inbox_note&utm_medium=product&utm_campaign=google_listings_ads_custom_attribute_mapping_q4_2022#attribute-mapping', 'actioned', '', NULL, NULL),
(810, 29, 'needs-update-eway-payment-gateway-rin-action-button-2022-12-20', 'See available updates', 'http://localhost/labb2-carolina/wp-admin/update-core.php', 'unactioned', '', NULL, NULL),
(811, 29, 'needs-update-eway-payment-gateway-rin-dismiss-button-2022-12-20', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(812, 30, 'updated-eway-payment-gateway-rin-action-button-2022-12-20', 'See all updates', 'http://localhost/labb2-carolina/wp-admin/update-core.php', 'unactioned', '', NULL, NULL),
(813, 30, 'updated-eway-payment-gateway-rin-dismiss-button-2022-12-20', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(814, 31, 'share-navigation-survey-feedback', 'Share feedback', 'https://automattic.survey.fm/new-ecommerce-plan-navigation', 'actioned', '', NULL, NULL),
(815, 32, 'google_listings_ads_pmax_i1_q1_2023_no_gla', 'Boost my business with Google', 'https://woocommerce.com/products/google-listings-and-ads/?utm_source=inbox_note&utm_medium=product&utm_campaign=google_listings_ads_pmax_i1_q1_2023_no_gla', 'actioned', '', NULL, NULL),
(816, 33, 'google_listings_ads_pmax_i1_q1_2023_with_gla', 'Create a new ad', 'https://woocommerce.com/products/google-listings-and-ads/?utm_source=inbox_note&utm_medium=product&utm_campaign=google_listings_ads_pmax_i1_q1_2023_with_gla', 'actioned', '', NULL, NULL),
(817, 34, 'woocommerce-wcpay-march-2023-update-needed-button', 'See Blog Post', 'https://developer.woocommerce.com/2023/03/23/critical-vulnerability-detected-in-woocommerce-payments-what-you-need-to-know', 'unactioned', '', NULL, NULL),
(818, 34, 'woocommerce-wcpay-march-2023-update-needed-dismiss-button', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(819, 35, 'tap_to_pay_iphone_q2_2023_no_wcpay', 'Simplify my payments', 'https://woocommerce.com/products/woocommerce-payments/?utm_source=inbox_note&utm_medium=product&utm_campaign=tap_to_pay_iphone_q2_2023_no_wcpay', 'actioned', '', NULL, NULL),
(820, 36, 'tap_to_pay_iphone_q2_2023_with_wcpay', 'Set up Tap to Pay on iPhone', 'https://woocommerce.com/document/woocommerce-payments/in-person-payments/woocommerce-in-person-payments-tap-to-pay-on-iphone-quick-start-guide/?utm_source=inbox_note&utm_medium=product&utm_campaign=tap_to_pay_iphone_q2_2023_with_wcpay', 'actioned', '', NULL, NULL),
(821, 37, 'extension-settings', 'See available updates', 'http://localhost/labb2-carolina/wp-admin/update-core.php', 'unactioned', '', NULL, NULL),
(822, 37, 'dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(823, 38, 'wc-admin-wcpay-denmark-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/denmark/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-denmark-Q2-2023', 'actioned', '', NULL, NULL),
(824, 39, 'wc-admin-wcpay-greece-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/greece/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-greece-Q2-2023', 'actioned', '', NULL, NULL),
(825, 40, 'wc-admin-wcpay-norway-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/norway/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-norway-Q2-2023', 'actioned', '', NULL, NULL),
(826, 41, 'wc-admin-wcpay-slovakia-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/slovakia/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-slovakia-Q2-2023', 'actioned', '', NULL, NULL),
(827, 42, 'wc-admin-wcpay-finland-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/finland/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-finland-Q2-2023', 'actioned', '', NULL, NULL),
(828, 43, 'wc-admin-wcpay-estonia-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/estonia/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-estonia-Q2-2023', 'actioned', '', NULL, NULL),
(829, 44, 'wc-admin-wcpay-lithuania-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/lithuania/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-lithuania-Q2-2023', 'actioned', '', NULL, NULL),
(830, 45, 'wc-admin-wcpay-slovenia-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/slovenia/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-slovenia-Q2-2023', 'actioned', '', NULL, NULL),
(831, 46, 'wc-admin-wcpay-latvia-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/latvia/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-latvia-Q2-2023', 'actioned', '', NULL, NULL),
(832, 47, 'wc-admin-wcpay-cyprus-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/cyprus/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-cyprus-Q2-2023', 'actioned', '', NULL, NULL),
(833, 48, 'wc-admin-wcpay-malta-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/malta/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-malta-Q2-2023', 'actioned', '', NULL, NULL),
(834, 49, 'wc-admin-wcpay-luxembourg-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/luxembourg/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-luxembourg-Q2-2023', 'actioned', '', NULL, NULL) ;

#
# End of data contents of table `wp_wc_admin_note_actions`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_admin_notes`
#

DROP TABLE IF EXISTS `wp_wc_admin_notes`;


#
# Table structure of table `wp_wc_admin_notes`
#

CREATE TABLE `wp_wc_admin_notes` (
  `note_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `locale` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `title` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content_data` longtext COLLATE utf8mb4_unicode_520_ci,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_reminder` datetime DEFAULT NULL,
  `is_snoozable` tinyint(1) NOT NULL DEFAULT '0',
  `layout` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `image` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `icon` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'info',
  PRIMARY KEY (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_admin_notes`
#
INSERT INTO `wp_wc_admin_notes` ( `note_id`, `name`, `type`, `locale`, `title`, `content`, `content_data`, `status`, `source`, `date_created`, `date_reminder`, `is_snoozable`, `layout`, `image`, `is_deleted`, `is_read`, `icon`) VALUES
(1, 'new_in_app_marketplace_2021', 'info', 'en_US', 'Customize your store with extensions', 'Check out our NEW Extensions tab to see our favorite extensions for customizing your store, and discover the most popular extensions in the WooCommerce Marketplace.', '[]', 'unactioned', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(2, 'wayflyer_bnpl_q4_2021', 'marketing', 'en_US', 'Grow your business with funding through Wayflyer', 'Fast, flexible financing to boost cash flow and help your business grow – one fee, no interest rates, penalties, equity, or personal guarantees. Based on your store’s performance, Wayflyer provides funding and analytical insights to invest in your business.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(3, 'wc_shipping_mobile_app_usps_q4_2021', 'marketing', 'en_US', 'Print and manage your shipping labels with WooCommerce Shipping and the WooCommerce Mobile App', 'Save time by printing, purchasing, refunding, and tracking shipping labels generated by <a href="https://woocommerce.com/woocommerce-shipping/">WooCommerce Shipping</a> – all directly from your mobile device!', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(4, 'woocommerce-services', 'info', 'en_US', 'WooCommerce Shipping & Tax', 'WooCommerce Shipping &amp; Tax helps get your store "ready to sell" as quickly as possible. You create your products. We take care of tax calculation, payment processing, and shipping label printing! Learn more about the extension that you just installed.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(5, 'your-first-product', 'info', 'en_US', 'Your first product', 'That’s huge! You’re well on your way to building a successful online store — now it’s time to think about how you’ll fulfill your orders.<br /><br />Read our shipping guide to learn best practices and options for putting together your shipping strategy. And for WooCommerce stores in the United States, you can print discounted shipping labels via USPS with <a href="https://href.li/?https://woocommerce.com/shipping" target="_blank">WooCommerce Shipping</a>.', '[]', 'unactioned', 'woocommerce.com', '2023-04-20 09:22:31', NULL, 0, 'plain', '', 0, 0, 'info'),
(6, 'wc-admin-optimizing-the-checkout-flow', 'info', 'en_US', 'Optimizing the checkout flow', 'It’s crucial to get your store’s checkout as smooth as possible to avoid losing sales. Let’s take a look at how you can optimize the checkout experience for your shoppers.', '[]', 'unactioned', 'woocommerce.com', '2023-04-23 17:59:21', NULL, 0, 'plain', '', 0, 0, 'info'),
(7, 'wc-payments-qualitative-feedback', 'info', 'en_US', 'WooCommerce Payments setup - let us know what you think', 'Congrats on enabling WooCommerce Payments for your store. Please share your feedback in this 2 minute survey to help us improve the setup process.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(8, 'share-your-feedback-on-paypal', 'info', 'en_US', 'Share your feedback on PayPal', 'Share your feedback in this 2 minute survey about how we can make the process of accepting payments more useful for your store.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(9, 'google_listings_and_ads_install', 'marketing', 'en_US', 'Drive traffic and sales with Google', 'Reach online shoppers to drive traffic and sales for your store by showcasing products across Google, for free or with ads.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(10, 'wc-subscriptions-security-update-3-0-15', 'info', 'en_US', 'WooCommerce Subscriptions security update!', 'We recently released an important security update to WooCommerce Subscriptions. To ensure your site’s data is protected, please upgrade <strong>WooCommerce Subscriptions to version 3.0.15</strong> or later.<br /><br />Click the button below to view and update to the latest Subscriptions version, or log in to <a href="https://woocommerce.com/my-dashboard">WooCommerce.com Dashboard</a> and navigate to your <strong>Downloads</strong> page.<br /><br />We recommend always using the latest version of WooCommerce Subscriptions, and other software running on your site, to ensure maximum security.<br /><br />If you have any questions we are here to help — just <a href="https://woocommerce.com/my-account/create-a-ticket/">open a ticket</a>.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(11, 'woocommerce-core-update-5-4-0', 'info', 'en_US', 'Update to WooCommerce 5.4.1 now', 'WooCommerce 5.4.1 addresses a checkout issue discovered in WooCommerce 5.4. We recommend upgrading to WooCommerce 5.4.1 as soon as possible.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(12, 'wcpay-promo-2020-11', 'marketing', 'en_US', 'wcpay-promo-2020-11', 'wcpay-promo-2020-11', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(13, 'wcpay-promo-2020-12', 'marketing', 'en_US', 'wcpay-promo-2020-12', 'wcpay-promo-2020-12', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(14, 'ppxo-pps-upgrade-paypal-payments-1', 'info', 'en_US', 'Get the latest PayPal extension for WooCommerce', 'Heads up! There’s a new PayPal on the block!<br /><br />Now is a great time to upgrade to our latest <a href="https://woocommerce.com/products/woocommerce-paypal-payments/" target="_blank">PayPal extension</a> to continue to receive support and updates with PayPal.<br /><br />Get access to a full suite of PayPal payment methods, extensive currency and country coverage, and pay later options with the all-new PayPal extension for WooCommerce.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(15, 'ppxo-pps-upgrade-paypal-payments-2', 'info', 'en_US', 'Upgrade your PayPal experience!', 'Get access to a full suite of PayPal payment methods, extensive currency and country coverage, offer subscription and recurring payments, and the new PayPal pay later options.<br /><br />Start using our <a href="https://woocommerce.com/products/woocommerce-paypal-payments/" target="_blank">latest PayPal today</a> to continue to receive support and updates.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(16, 'woocommerce-core-sqli-july-2021-need-to-update', 'update', 'en_US', 'Action required: Critical vulnerabilities in WooCommerce', 'In response to a critical vulnerability identified on July 13, 2021, we are working with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br />Our investigation into this vulnerability is ongoing, but <strong>we wanted to let you know now about the importance of updating immediately</strong>.<br /><br />For more information on which actions you should take, as well as answers to FAQs, please urgently review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(17, 'woocommerce-blocks-sqli-july-2021-need-to-update', 'update', 'en_US', 'Action required: Critical vulnerabilities in WooCommerce Blocks', 'In response to a critical vulnerability identified on July 13, 2021, we are working with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br />Our investigation into this vulnerability is ongoing, but <strong>we wanted to let you know now about the importance of updating immediately</strong>.<br /><br />For more information on which actions you should take, as well as answers to FAQs, please urgently review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(18, 'woocommerce-core-sqli-july-2021-store-patched', 'update', 'en_US', 'Solved: Critical vulnerabilities patched in WooCommerce', 'In response to a critical vulnerability identified on July 13, 2021, we worked with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br /><strong>Your store has been updated to the latest secure version(s)</strong>. For more information and answers to FAQs, please review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(19, 'woocommerce-blocks-sqli-july-2021-store-patched', 'update', 'en_US', 'Solved: Critical vulnerabilities patched in WooCommerce Blocks', 'In response to a critical vulnerability identified on July 13, 2021, we worked with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br /><strong>Your store has been updated to the latest secure version(s)</strong>. For more information and answers to FAQs, please review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(20, 'habit-moment-survey', 'marketing', 'en_US', 'We’re all ears! Share your experience so far with WooCommerce', 'We’d love your input to shape the future of WooCommerce together. Feel free to share any feedback, ideas or suggestions that you have.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(21, 'woocommerce-core-paypal-march-2022-updated', 'update', 'en_US', 'Security auto-update of WooCommerce', '<strong>Your store has been updated to the latest secure version of WooCommerce</strong>. We worked with WordPress to deploy PayPal Standard security updates for stores running WooCommerce (version 3.5 to 6.3). It’s recommended to disable PayPal Standard, and use <a href="https://woocommerce.com/products/woocommerce-paypal-payments/" target="_blank">PayPal Payments</a> to accept PayPal.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(22, 'woocommerce-core-paypal-march-2022-updated-nopp', 'update', 'en_US', 'Security auto-update of WooCommerce', '<strong>Your store has been updated to the latest secure version of WooCommerce</strong>. We worked with WordPress to deploy security updates related to PayPal Standard payment gateway for stores running WooCommerce (version 3.5 to 6.3).', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(23, 'pinterest_03_2022_update', 'marketing', 'en_US', 'Your Pinterest for WooCommerce plugin is out of date!', 'Update to the latest version of Pinterest for WooCommerce to continue using this plugin and keep your store connected with Pinterest. To update, visit <strong>Plugins &gt; Installed Plugins</strong>, and click on “update now” under Pinterest for WooCommerce.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(24, 'store_setup_survey_survey_q2_2022', 'survey', 'en_US', 'How is your store setup going?', 'Our goal is to make sure you have all the right tools to start setting up your store in the smoothest way possible.\r\nWe’d love to know if we hit our mark and how we can improve. To collect your thoughts, we made a 2-minute survey.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(25, 'wc-admin-wisepad3', 'marketing', 'en_US', 'Take your business on the go in Canada with WooCommerce In-Person Payments', 'Quickly create new orders, accept payment in person for orders placed online, and automatically sync your inventory – no matter where your business takes you. With WooCommerce In-Person Payments and the WisePad 3 card reader, you can bring the power of your store anywhere.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(26, 'woocommerce-payments-august-2022-need-to-update', 'update', 'en_US', 'Action required: Please update WooCommerce Payments', 'An updated secure version of WooCommerce Payments is available – please ensure that you’re using the latest patch version. For more information on what action you need to take, please review the article below.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(27, 'woocommerce-payments-august-2022-store-patched', 'update', 'en_US', 'WooCommerce Payments has been automatically updated', 'You’re now running the latest secure version of WooCommerce Payments. We’ve worked with the WordPress Plugins team to deploy a security update to stores running WooCommerce Payments (version 3.9 to 4.5). For further information, please review the article below.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(28, 'google_listings_ads_custom_attribute_mapping_q4_2022', 'marketing', 'en_US', 'Our latest improvement to the Google Listings & Ads extension: Attribute Mapping', 'You spoke, we listened. This new feature enables you to easily upload your products, customize your product attributes in one place, and target shoppers with more relevant ads. Extend how far your ad dollars go with each campaign.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(29, 'needs-update-eway-payment-gateway-rin-2022-12-20', 'update', 'en_US', 'Security vulnerability patched in WooCommerce Eway Gateway', 'In response to a potential vulnerability identified in WooCommerce Eway Gateway versions 3.1.0 to 3.5.0, we’ve worked to deploy security fixes and have released an updated version.\r\nNo external exploits have been detected, but we recommend you update to your latest supported version 3.1.26, 3.2.3, 3.3.1, 3.4.6, or 3.5.1', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(30, 'updated-eway-payment-gateway-rin-2022-12-20', 'update', 'en_US', 'WooCommerce Eway Gateway has been automatically updated', 'Your store is now running the latest secure version of WooCommerce Eway Gateway. We worked with the WordPress Plugins team to deploy a software update to stores running WooCommerce Eway Gateway (versions 3.1.0 to 3.5.0) in response to a security vulnerability that was discovered.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(31, 'ecomm-wc-navigation-survey-2023', 'info', 'en_US', 'Navigating WooCommerce on WordPress.com', 'We are improving the WooCommerce navigation on WordPress.com and would love your help to make it better! Please share your experience with us in this 2-minute survey.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(32, 'google_listings_ads_pmax_i1_q1_2023_no_gla', 'marketing', 'en_US', 'Create more engaging ads – without the hard work', 'Get in front of millions of shoppers searching for products like yours with Google Listings &amp; Ads. With new customization features, Google automatically tests multiple combinations of text and images to create the most engaging ad to boost your business. Plus, get up to $500 in ad credit – terms and conditions apply.', '[]', 'unactioned', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(33, 'google_listings_ads_pmax_i1_q1_2023_with_gla', 'marketing', 'en_US', 'New customization features to boost your business', 'You can now add custom images, messaging, and URLs to campaigns in Google Listings &amp; Ads. Google then automatically tests multiple combinations to create the most engaging version to help boost your business. Get more sales with dynamic content – edit an existing campaign or create a new ad now.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(34, 'woocommerce-wcpay-march-2023-update-needed', 'update', 'en_US', 'Action required: Security update for WooCommerce Payments', '<strong>Your store requires a security update for WooCommerce Payments</strong>. Please update to the latest version of WooCommerce Payments immediately to address a potential vulnerability discovered on March 22. For more information on how to update, visit this WooCommerce Developer Blog Post.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(35, 'tap_to_pay_iphone_q2_2023_no_wcpay', 'marketing', 'en_US', 'Accept in-person contactless payments on your iPhone', 'Tap to Pay on iPhone and WooCommerce Payments is quick, secure, and simple to set up — no extra terminals or card readers are needed. Accept contactless debit and credit cards, Apple Pay, and other NFC digital wallets in person.', '[]', 'unactioned', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(36, 'tap_to_pay_iphone_q2_2023_with_wcpay', 'marketing', 'en_US', 'New: accept in-person contactless payments on your iPhone', 'Tap to Pay on iPhone is quick, secure, and simple to set up in WooCommerce Payments — no extra terminals or card readers are needed. Accept contactless debit and credit cards, Apple Pay, and other NFC digital wallets in person in a few short steps!', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(37, 'woocommerce-WCPreOrders-april-2023-update-needed', 'update', 'en_US', 'Action required: Security update of WooCommerce Pre-Orders extension', '<strong>Your store requires a security update for the WooCommerce Pre-Orders extension</strong>. Please update the WooCommerce Pre-Orders extension immediately to address a potential vulnerability discovered on April 11.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(38, 'wc-admin-wcpay-denmark-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Denmark!', 'We’ve recently released WooCommerce Payments in Denmark. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(39, 'wc-admin-wcpay-greece-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Greece!', 'We’ve recently released WooCommerce Payments in Greece. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(40, 'wc-admin-wcpay-norway-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Norway!', 'We’ve recently released WooCommerce Payments in Norway. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(41, 'wc-admin-wcpay-slovakia-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Slovakia!', 'We’ve recently released WooCommerce Payments in Slovakia. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(42, 'wc-admin-wcpay-finland-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Finland!', 'We’ve recently released WooCommerce Payments in Finland. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(43, 'wc-admin-wcpay-estonia-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Estonia!', 'We’ve recently released WooCommerce Payments in Estonia. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(44, 'wc-admin-wcpay-lithuania-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Lithuania!', 'We’ve recently released WooCommerce Payments in Lithuania. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(45, 'wc-admin-wcpay-slovenia-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Slovenia!', 'We’ve recently released WooCommerce Payments in Slovenia. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(46, 'wc-admin-wcpay-latvia-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Latvia!', 'We’ve recently released WooCommerce Payments in Latvia. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(47, 'wc-admin-wcpay-cyprus-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Cyprus!', 'We’ve recently released WooCommerce Payments in Cyprus. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(48, 'wc-admin-wcpay-malta-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Malta!', 'We’ve recently released WooCommerce Payments in Malta. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(49, 'wc-admin-wcpay-luxembourg-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Luxembourg!', 'We’ve recently released WooCommerce Payments in Luxembourg. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-19 07:40:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(50, 'wc-admin-wc-helper-connection', 'info', 'en_US', 'Anslut till WooCommerce.com', 'Anslut och få viktiga produktmeddelanden och -uppdateringar.', '[]', 'unactioned', 'woocommerce-admin', '2023-04-19 07:40:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(51, 'storefront-customize', 'info', 'en_US', 'Designa din butik med Storefront 🎨', 'Besök Storefronts inställningssida för att börja med inställningar och anpassningar för din butik.', '[]', 'unactioned', 'storefront', '2023-04-19 07:46:46', NULL, 0, 'plain', '', 0, 0, 'info'),
(52, 'wc-admin-choosing-a-theme', 'marketing', 'en_US', 'Välj ett tema?', 'Kolla in olika teman som är kompatibla med WooCommerce och välj ett som passar ihop med ditt varumärke och dina företagsbehov.', '[]', 'unactioned', 'woocommerce-admin', '2023-04-20 09:22:30', NULL, 0, 'plain', '', 0, 0, 'info'),
(53, 'wc-admin-launch-checklist', 'info', 'en_US', 'Är du redo att lansera din butik?', 'Vi har sammanställt en omfattande checklista innan webbplatsen tas i bruk så att du aldrig får känslan av att ha glömt något.', '[]', 'unactioned', 'woocommerce-admin', '2023-04-20 09:22:30', NULL, 0, 'plain', '', 0, 0, 'info'),
(54, 'wc-admin-customizing-product-catalog', 'info', 'en_US', 'Så här anpassar du din produktkatalog', 'Du vill att din produktkatalog och dina bilder ska se fantastiska ut och vara i linje med ditt varumärke. Den här guiden ger dig alla tips du behöver för att få dina produkter att se fantastiska ut i din butik.', '[]', 'unactioned', 'woocommerce-admin', '2023-04-21 07:44:00', NULL, 0, 'plain', '', 0, 0, 'info'),
(55, 'wc-admin-mobile-app', 'info', 'en_US', 'Installera Woo-mobilappen', 'Installera WooCommerce-mobilappen och hantera beställningar, få säljnotiser och granska nyckeltal – var som helst.', '[]', 'unactioned', 'woocommerce-admin', '2023-04-21 07:44:00', NULL, 0, 'plain', '', 0, 0, 'info'),
(56, 'wc-admin-online-clothing-store', 'info', 'en_US', 'Starta din klädbutik online', 'Att starta en modewebbplats är spännande men det kan även kännas överväldigande ibland. I den här artikeln tar vi dig igenom konfigurationsprocessen, lär dig hur du skapar lyckade produktlistningar och visar dig hur du marknadsför mot din perfekta målgrupp.', '[]', 'unactioned', 'woocommerce-admin', '2023-04-21 07:44:00', NULL, 0, 'plain', '', 0, 0, 'info'),
(57, 'wc-admin-coupon-page-moved', 'update', 'en_US', 'Hantering av rabattkoder har flyttat!', 'Rabattkoder kan nu hanteras från Marknadsföring &gt; Rabattkoder. Klicka på knappen nedan för att ta bort det äldre menyobjektet WooCommerce &gt; Rabattkoder.', '[]', 'unactioned', 'woocommerce-admin', '2023-04-24 12:54:08', NULL, 0, 'plain', '', 0, 0, 'info') ;

#
# End of data contents of table `wp_wc_admin_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_category_lookup`
#

DROP TABLE IF EXISTS `wp_wc_category_lookup`;


#
# Table structure of table `wp_wc_category_lookup`
#

CREATE TABLE `wp_wc_category_lookup` (
  `category_tree_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`category_tree_id`,`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_category_lookup`
#
INSERT INTO `wp_wc_category_lookup` ( `category_tree_id`, `category_id`) VALUES
(15, 15),
(16, 16),
(16, 17),
(17, 17),
(22, 22),
(22, 24),
(22, 25),
(23, 23),
(23, 26),
(23, 27),
(24, 24),
(25, 25),
(26, 26),
(27, 27),
(28, 28) ;

#
# End of data contents of table `wp_wc_category_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_customer_lookup`
#

DROP TABLE IF EXISTS `wp_wc_customer_lookup`;


#
# Table structure of table `wp_wc_customer_lookup`
#

CREATE TABLE `wp_wc_customer_lookup` (
  `customer_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `username` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `first_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `date_last_active` timestamp NULL DEFAULT NULL,
  `date_registered` timestamp NULL DEFAULT NULL,
  `country` char(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `postcode` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_customer_lookup`
#

#
# End of data contents of table `wp_wc_customer_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_download_log`
#

DROP TABLE IF EXISTS `wp_wc_download_log`;


#
# Table structure of table `wp_wc_download_log`
#

CREATE TABLE `wp_wc_download_log` (
  `download_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `user_ip_address` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`download_log_id`),
  KEY `permission_id` (`permission_id`),
  KEY `timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_download_log`
#

#
# End of data contents of table `wp_wc_download_log`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_coupon_lookup`
#

DROP TABLE IF EXISTS `wp_wc_order_coupon_lookup`;


#
# Table structure of table `wp_wc_order_coupon_lookup`
#

CREATE TABLE `wp_wc_order_coupon_lookup` (
  `order_id` bigint(20) unsigned NOT NULL,
  `coupon_id` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `discount_amount` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_id`,`coupon_id`),
  KEY `coupon_id` (`coupon_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_order_coupon_lookup`
#

#
# End of data contents of table `wp_wc_order_coupon_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_product_lookup`
#

DROP TABLE IF EXISTS `wp_wc_order_product_lookup`;


#
# Table structure of table `wp_wc_order_product_lookup`
#

CREATE TABLE `wp_wc_order_product_lookup` (
  `order_item_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `variation_id` bigint(20) unsigned NOT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `product_qty` int(11) NOT NULL,
  `product_net_revenue` double NOT NULL DEFAULT '0',
  `product_gross_revenue` double NOT NULL DEFAULT '0',
  `coupon_amount` double NOT NULL DEFAULT '0',
  `tax_amount` double NOT NULL DEFAULT '0',
  `shipping_amount` double NOT NULL DEFAULT '0',
  `shipping_tax_amount` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  KEY `customer_id` (`customer_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_order_product_lookup`
#

#
# End of data contents of table `wp_wc_order_product_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_stats`
#

DROP TABLE IF EXISTS `wp_wc_order_stats`;


#
# Table structure of table `wp_wc_order_stats`
#

CREATE TABLE `wp_wc_order_stats` (
  `order_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_paid` datetime DEFAULT '0000-00-00 00:00:00',
  `date_completed` datetime DEFAULT '0000-00-00 00:00:00',
  `num_items_sold` int(11) NOT NULL DEFAULT '0',
  `total_sales` double NOT NULL DEFAULT '0',
  `tax_total` double NOT NULL DEFAULT '0',
  `shipping_total` double NOT NULL DEFAULT '0',
  `net_total` double NOT NULL DEFAULT '0',
  `returning_customer` tinyint(1) DEFAULT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `date_created` (`date_created`),
  KEY `customer_id` (`customer_id`),
  KEY `status` (`status`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_order_stats`
#

#
# End of data contents of table `wp_wc_order_stats`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_tax_lookup`
#

DROP TABLE IF EXISTS `wp_wc_order_tax_lookup`;


#
# Table structure of table `wp_wc_order_tax_lookup`
#

CREATE TABLE `wp_wc_order_tax_lookup` (
  `order_id` bigint(20) unsigned NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `shipping_tax` double NOT NULL DEFAULT '0',
  `order_tax` double NOT NULL DEFAULT '0',
  `total_tax` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_id`,`tax_rate_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_order_tax_lookup`
#

#
# End of data contents of table `wp_wc_order_tax_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_product_attributes_lookup`
#

DROP TABLE IF EXISTS `wp_wc_product_attributes_lookup`;


#
# Table structure of table `wp_wc_product_attributes_lookup`
#

CREATE TABLE `wp_wc_product_attributes_lookup` (
  `product_id` bigint(20) NOT NULL,
  `product_or_parent_id` bigint(20) NOT NULL,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `term_id` bigint(20) NOT NULL,
  `is_variation_attribute` tinyint(1) NOT NULL,
  `in_stock` tinyint(1) NOT NULL,
  PRIMARY KEY (`product_or_parent_id`,`term_id`,`product_id`,`taxonomy`),
  KEY `is_variation_attribute_term_id` (`is_variation_attribute`,`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_product_attributes_lookup`
#
INSERT INTO `wp_wc_product_attributes_lookup` ( `product_id`, `product_or_parent_id`, `taxonomy`, `term_id`, `is_variation_attribute`, `in_stock`) VALUES
(12, 12, 'pa_color', 18, 0, 1),
(25, 22, 'pa_storlek', 19, 1, 1),
(24, 22, 'pa_storlek', 20, 1, 1),
(23, 22, 'pa_storlek', 21, 1, 1),
(32, 29, 'pa_storlek', 19, 1, 1),
(35, 29, 'pa_storlek', 19, 1, 1),
(31, 29, 'pa_storlek', 20, 1, 1),
(34, 29, 'pa_storlek', 20, 1, 1),
(30, 29, 'pa_storlek', 21, 1, 1),
(33, 29, 'pa_storlek', 21, 1, 1),
(33, 29, 'pa_farg', 29, 1, 1),
(34, 29, 'pa_farg', 29, 1, 1),
(35, 29, 'pa_farg', 29, 1, 1),
(30, 29, 'pa_farg', 30, 1, 1),
(31, 29, 'pa_farg', 30, 1, 1),
(32, 29, 'pa_farg', 30, 1, 1),
(40, 36, 'pa_vikt', 32, 1, 1),
(39, 36, 'pa_vikt', 34, 1, 1),
(38, 36, 'pa_vikt', 35, 1, 1) ;

#
# End of data contents of table `wp_wc_product_attributes_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_product_download_directories`
#

DROP TABLE IF EXISTS `wp_wc_product_download_directories`;


#
# Table structure of table `wp_wc_product_download_directories`
#

CREATE TABLE `wp_wc_product_download_directories` (
  `url_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(256) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`url_id`),
  KEY `url` (`url`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_product_download_directories`
#
INSERT INTO `wp_wc_product_download_directories` ( `url_id`, `url`, `enabled`) VALUES
(1, 'file://C:/MAMP/htdocs/labb2-carolina/wp-content/uploads/woocommerce_uploads/', 1),
(2, 'http://localhost/labb2-carolina/wp-content/uploads/woocommerce_uploads/', 1),
(3, 'http://localhost/labb2-carolina/wp-content/uploads/2023/04/', 1) ;

#
# End of data contents of table `wp_wc_product_download_directories`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_product_meta_lookup`
#

DROP TABLE IF EXISTS `wp_wc_product_meta_lookup`;


#
# Table structure of table `wp_wc_product_meta_lookup`
#

CREATE TABLE `wp_wc_product_meta_lookup` (
  `product_id` bigint(20) NOT NULL,
  `sku` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `virtual` tinyint(1) DEFAULT '0',
  `downloadable` tinyint(1) DEFAULT '0',
  `min_price` decimal(19,4) DEFAULT NULL,
  `max_price` decimal(19,4) DEFAULT NULL,
  `onsale` tinyint(1) DEFAULT '0',
  `stock_quantity` double DEFAULT NULL,
  `stock_status` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT 'instock',
  `rating_count` bigint(20) DEFAULT '0',
  `average_rating` decimal(3,2) DEFAULT '0.00',
  `total_sales` bigint(20) DEFAULT '0',
  `tax_status` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT 'taxable',
  `tax_class` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`product_id`),
  KEY `virtual` (`virtual`),
  KEY `downloadable` (`downloadable`),
  KEY `stock_status` (`stock_status`),
  KEY `stock_quantity` (`stock_quantity`),
  KEY `onsale` (`onsale`),
  KEY `min_max_price` (`min_price`,`max_price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_product_meta_lookup`
#
INSERT INTO `wp_wc_product_meta_lookup` ( `product_id`, `sku`, `virtual`, `downloadable`, `min_price`, `max_price`, `onsale`, `stock_quantity`, `stock_status`, `rating_count`, `average_rating`, `total_sales`, `tax_status`, `tax_class`) VALUES
(12, '', 0, 0, '45.0000', '45.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(22, '', 0, 0, '399.0000', '399.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(23, 'yogatights-large', 0, 0, '399.0000', '399.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(24, 'yogatights-medium', 0, 0, '399.0000', '399.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(25, 'yogatights-small', 0, 0, '399.0000', '399.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(26, 'yogamatta', 0, 0, '499.0000', '499.0000', 0, '5', 'instock', 0, '0.00', 0, 'taxable', ''),
(29, '', 0, 0, '299.0000', '399.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(30, 'traningstopp-rosa-large', 0, 0, '299.0000', '299.0000', 1, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(31, 'traningstopp-rosa-medium', 0, 0, '299.0000', '299.0000', 1, '13', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(32, 'traningstopp-rosa-small', 0, 0, '299.0000', '299.0000', 1, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(33, 'traningstopp-svart-large', 0, 0, '399.0000', '399.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(34, 'traningstopp-svart-medium', 0, 0, '399.0000', '399.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(35, 'traningstopp-svart-small', 0, 0, '399.0000', '399.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(36, '', 0, 0, '149.0000', '299.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(38, 'hantel-2kg', 0, 0, '149.0000', '149.0000', 0, '6', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(39, 'hantel-4kg', 0, 0, '249.0000', '249.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(40, 'hantel-5kg', 0, 0, '299.0000', '299.0000', 0, '8', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(45, 'traningsschema', 1, 1, '29.0000', '29.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', '') ;

#
# End of data contents of table `wp_wc_product_meta_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_rate_limits`
#

DROP TABLE IF EXISTS `wp_wc_rate_limits`;


#
# Table structure of table `wp_wc_rate_limits`
#

CREATE TABLE `wp_wc_rate_limits` (
  `rate_limit_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rate_limit_key` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `rate_limit_expiry` bigint(20) unsigned NOT NULL,
  `rate_limit_remaining` smallint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`rate_limit_id`),
  UNIQUE KEY `rate_limit_key` (`rate_limit_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_rate_limits`
#

#
# End of data contents of table `wp_wc_rate_limits`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_reserved_stock`
#

DROP TABLE IF EXISTS `wp_wc_reserved_stock`;


#
# Table structure of table `wp_wc_reserved_stock`
#

CREATE TABLE `wp_wc_reserved_stock` (
  `order_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `stock_quantity` double NOT NULL DEFAULT '0',
  `timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `expires` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`order_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_reserved_stock`
#

#
# End of data contents of table `wp_wc_reserved_stock`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_tax_rate_classes`
#

DROP TABLE IF EXISTS `wp_wc_tax_rate_classes`;


#
# Table structure of table `wp_wc_tax_rate_classes`
#

CREATE TABLE `wp_wc_tax_rate_classes` (
  `tax_rate_class_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_class_id`),
  UNIQUE KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_tax_rate_classes`
#
INSERT INTO `wp_wc_tax_rate_classes` ( `tax_rate_class_id`, `name`, `slug`) VALUES
(1, 'Nedsatt moms', 'nedsatt-moms'),
(2, 'Momsfritt', 'momsfritt') ;

#
# End of data contents of table `wp_wc_tax_rate_classes`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_webhooks`
#

DROP TABLE IF EXISTS `wp_wc_webhooks`;


#
# Table structure of table `wp_wc_webhooks`
#

CREATE TABLE `wp_wc_webhooks` (
  `webhook_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `delivery_url` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `secret` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `topic` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT '0',
  `pending_delivery` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`webhook_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_webhooks`
#

#
# End of data contents of table `wp_wc_webhooks`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_api_keys`
#

DROP TABLE IF EXISTS `wp_woocommerce_api_keys`;


#
# Table structure of table `wp_woocommerce_api_keys`
#

CREATE TABLE `wp_woocommerce_api_keys` (
  `key_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `permissions` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `nonces` longtext COLLATE utf8mb4_unicode_520_ci,
  `truncated_key` char(7) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_access` datetime DEFAULT NULL,
  PRIMARY KEY (`key_id`),
  KEY `consumer_key` (`consumer_key`),
  KEY `consumer_secret` (`consumer_secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_api_keys`
#

#
# End of data contents of table `wp_woocommerce_api_keys`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_attribute_taxonomies`
#

DROP TABLE IF EXISTS `wp_woocommerce_attribute_taxonomies`;


#
# Table structure of table `wp_woocommerce_attribute_taxonomies`
#

CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_label` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `attribute_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_orderby` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`(20))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_attribute_taxonomies`
#
INSERT INTO `wp_woocommerce_attribute_taxonomies` ( `attribute_id`, `attribute_name`, `attribute_label`, `attribute_type`, `attribute_orderby`, `attribute_public`) VALUES
(2, 'storlek', 'Storlek', 'select', 'menu_order', 0),
(3, 'farg', 'Färg', 'select', 'menu_order', 0),
(4, 'vikt', 'Vikt', 'select', 'menu_order', 0) ;

#
# End of data contents of table `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_downloadable_product_permissions`
#

DROP TABLE IF EXISTS `wp_woocommerce_downloadable_product_permissions`;


#
# Table structure of table `wp_woocommerce_downloadable_product_permissions`
#

CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `download_id` varchar(36) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `order_key` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  KEY `order_id` (`order_id`),
  KEY `user_order_remaining_expires` (`user_id`,`order_id`,`downloads_remaining`,`access_expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_downloadable_product_permissions`
#

#
# End of data contents of table `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_log`
#

DROP TABLE IF EXISTS `wp_woocommerce_log`;


#
# Table structure of table `wp_woocommerce_log`
#

CREATE TABLE `wp_woocommerce_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`log_id`),
  KEY `level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_log`
#

#
# End of data contents of table `wp_woocommerce_log`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_order_itemmeta`
#

DROP TABLE IF EXISTS `wp_woocommerce_order_itemmeta`;


#
# Table structure of table `wp_woocommerce_order_itemmeta`
#

CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_order_itemmeta`
#

#
# End of data contents of table `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_order_items`
#

DROP TABLE IF EXISTS `wp_woocommerce_order_items`;


#
# Table structure of table `wp_woocommerce_order_items`
#

CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_order_items`
#

#
# End of data contents of table `wp_woocommerce_order_items`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_payment_tokenmeta`
#

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokenmeta`;


#
# Table structure of table `wp_woocommerce_payment_tokenmeta`
#

CREATE TABLE `wp_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_token_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `payment_token_id` (`payment_token_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_payment_tokenmeta`
#

#
# End of data contents of table `wp_woocommerce_payment_tokenmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_payment_tokens`
#

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokens`;


#
# Table structure of table `wp_woocommerce_payment_tokens`
#

CREATE TABLE `wp_woocommerce_payment_tokens` (
  `token_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gateway_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`token_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_payment_tokens`
#

#
# End of data contents of table `wp_woocommerce_payment_tokens`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_sessions`
#

DROP TABLE IF EXISTS `wp_woocommerce_sessions`;


#
# Table structure of table `wp_woocommerce_sessions`
#

CREATE TABLE `wp_woocommerce_sessions` (
  `session_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_key` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_expiry` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`session_id`),
  UNIQUE KEY `session_key` (`session_key`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_sessions`
#
INSERT INTO `wp_woocommerce_sessions` ( `session_id`, `session_key`, `session_value`, `session_expiry`) VALUES
(7, 't_9ac81a7a5eecc3377c94dcb083a3f3', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:716:"a:27:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"SE";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"SE";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";s:14:"shipping_phone";s:0:"";}";}', 1682513239),
(8, '1', 'a:13:{s:4:"cart";s:693:"a:1:{s:32:"0942388adaa4ecef4b8b87257f625e6c";a:11:{s:3:"key";s:32:"0942388adaa4ecef4b8b87257f625e6c";s:10:"product_id";i:29;s:12:"variation_id";i:32;s:9:"variation";a:2:{s:17:"attribute_pa_farg";s:4:"rosa";s:20:"attribute_pa_storlek";s:5:"small";}s:8:"quantity";i:3;s:9:"data_hash";s:32:"2090b92a59e0639d31f416571b905024";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:1:{i:1;d:179.400000000000005684341886080801486968994140625;}s:5:"total";a:1:{i:1;d:179.400000000000005684341886080801486968994140625;}}s:13:"line_subtotal";d:717.6000000000000227373675443232059478759765625;s:17:"line_subtotal_tax";d:179;s:10:"line_total";d:717.6000000000000227373675443232059478759765625;s:8:"line_tax";d:179;}}";s:11:"cart_totals";s:409:"a:15:{s:8:"subtotal";s:3:"718";s:12:"subtotal_tax";d:179;s:14:"shipping_total";s:1:"0";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:3:"718";s:17:"cart_contents_tax";d:179;s:19:"cart_contents_taxes";a:1:{i:1;d:179;}s:9:"fee_total";s:1:"0";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:3:"897";s:9:"total_tax";d:179;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:693:"a:1:{s:32:"50e00a73bd06bf61caf2e61e9c6387c7";a:11:{s:3:"key";s:32:"50e00a73bd06bf61caf2e61e9c6387c7";s:10:"product_id";i:29;s:12:"variation_id";i:30;s:9:"variation";a:2:{s:17:"attribute_pa_farg";s:4:"rosa";s:20:"attribute_pa_storlek";s:5:"large";}s:8:"quantity";i:1;s:9:"data_hash";s:32:"8d1712a48eacd2be4085361687811d90";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:1:{i:1;d:59.7999999999999971578290569595992565155029296875;}s:5:"total";a:1:{i:1;d:59.7999999999999971578290569595992565155029296875;}}s:13:"line_subtotal";d:239.19999999999998863131622783839702606201171875;s:17:"line_subtotal_tax";d:60;s:10:"line_total";d:239.19999999999998863131622783839702606201171875;s:8:"line_tax";d:60;}}";s:22:"shipping_for_package_0";s:1236:"a:2:{s:12:"package_hash";s:40:"wc_ship_d7d1c9574dab6d7dcc46ba5b127a4c8a";s:5:"rates";a:2:{s:15:"free_shipping:4";O:16:"WC_Shipping_Rate":4:{s:7:"\0*\0data";a:6:{s:2:"id";s:15:"free_shipping:4";s:9:"method_id";s:13:"free_shipping";s:11:"instance_id";i:4;s:5:"label";s:9:"Fri frakt";s:4:"cost";s:1:"0";s:5:"taxes";a:0:{}}s:12:"\0*\0meta_data";a:1:{s:8:"Artiklar";s:37:"Träningstopp - Rosa, Small &times; 3";}s:4:"data";a:6:{s:2:"id";s:15:"free_shipping:4";s:9:"method_id";s:13:"free_shipping";s:11:"instance_id";i:4;s:5:"label";s:9:"Fri frakt";s:4:"cost";s:1:"0";s:5:"taxes";a:0:{}}s:9:"meta_data";a:1:{s:8:"Artiklar";s:37:"Träningstopp - Rosa, Small &times; 3";}}s:11:"flat_rate:7";O:16:"WC_Shipping_Rate":4:{s:7:"\0*\0data";a:6:{s:2:"id";s:11:"flat_rate:7";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:7;s:5:"label";s:9:"Fast pris";s:4:"cost";s:2:"49";s:5:"taxes";a:1:{i:1;d:12.25;}}s:12:"\0*\0meta_data";a:1:{s:8:"Artiklar";s:37:"Träningstopp - Rosa, Small &times; 3";}s:4:"data";a:6:{s:2:"id";s:11:"flat_rate:7";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:7;s:5:"label";s:9:"Fast pris";s:4:"cost";s:2:"49";s:5:"taxes";a:1:{i:1;d:12.25;}}s:9:"meta_data";a:1:{s:8:"Artiklar";s:37:"Träningstopp - Rosa, Small &times; 3";}}}}";s:25:"previous_shipping_methods";s:66:"a:1:{i:0;a:2:{i:0;s:15:"free_shipping:4";i:1;s:11:"flat_rate:7";}}";s:23:"chosen_shipping_methods";s:33:"a:1:{i:0;s:15:"free_shipping:4";}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:2;}";s:8:"customer";s:893:"a:27:{s:2:"id";s:1:"1";s:13:"date_modified";s:25:"2023-04-24T14:52:21+02:00";s:8:"postcode";s:5:"84398";s:4:"city";s:10:"Sörbygden";s:9:"address_1";s:22:"HÅRDGÅRDSBODARNA 110";s:7:"address";s:22:"HÅRDGÅRDSBODARNA 110";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"SE";s:17:"shipping_postcode";s:5:"84398";s:13:"shipping_city";s:10:"Sörbygden";s:18:"shipping_address_1";s:22:"HÅRDGÅRDSBODARNA 110";s:16:"shipping_address";s:22:"HÅRDGÅRDSBODARNA 110";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"SE";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:1:"1";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:25:"henrikutbildare@gmail.com";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";s:14:"shipping_phone";s:0:"";}";s:21:"chosen_payment_method";s:3:"cod";s:10:"wc_notices";N;}', 1682513254) ;

#
# End of data contents of table `wp_woocommerce_sessions`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_shipping_zone_locations`
#

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_locations`;


#
# Table structure of table `wp_woocommerce_shipping_zone_locations`
#

CREATE TABLE `wp_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_id` bigint(20) unsigned NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `location_id` (`location_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_shipping_zone_locations`
#
INSERT INTO `wp_woocommerce_shipping_zone_locations` ( `location_id`, `zone_id`, `location_code`, `location_type`) VALUES
(1, 1, 'SE', 'country') ;

#
# End of data contents of table `wp_woocommerce_shipping_zone_locations`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_shipping_zone_methods`
#

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_methods`;


#
# Table structure of table `wp_woocommerce_shipping_zone_methods`
#

CREATE TABLE `wp_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) unsigned NOT NULL,
  `instance_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `method_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `method_order` bigint(20) unsigned NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`instance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_shipping_zone_methods`
#
INSERT INTO `wp_woocommerce_shipping_zone_methods` ( `zone_id`, `instance_id`, `method_id`, `method_order`, `is_enabled`) VALUES
(1, 4, 'free_shipping', 3, 1),
(1, 7, 'flat_rate', 4, 1) ;

#
# End of data contents of table `wp_woocommerce_shipping_zone_methods`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_shipping_zones`
#

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zones`;


#
# Table structure of table `wp_woocommerce_shipping_zones`
#

CREATE TABLE `wp_woocommerce_shipping_zones` (
  `zone_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `zone_order` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_shipping_zones`
#
INSERT INTO `wp_woocommerce_shipping_zones` ( `zone_id`, `zone_name`, `zone_order`) VALUES
(1, 'Sverige', 0) ;

#
# End of data contents of table `wp_woocommerce_shipping_zones`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_tax_rate_locations`
#

DROP TABLE IF EXISTS `wp_woocommerce_tax_rate_locations`;


#
# Table structure of table `wp_woocommerce_tax_rate_locations`
#

CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_tax_rate_locations`
#

#
# End of data contents of table `wp_woocommerce_tax_rate_locations`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_tax_rates`
#

DROP TABLE IF EXISTS `wp_woocommerce_tax_rates`;


#
# Table structure of table `wp_woocommerce_tax_rates`
#

CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) unsigned NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) unsigned NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`(2)),
  KEY `tax_rate_class` (`tax_rate_class`(10)),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_tax_rates`
#
INSERT INTO `wp_woocommerce_tax_rates` ( `tax_rate_id`, `tax_rate_country`, `tax_rate_state`, `tax_rate`, `tax_rate_name`, `tax_rate_priority`, `tax_rate_compound`, `tax_rate_shipping`, `tax_rate_order`, `tax_rate_class`) VALUES
(1, 'SE', '', '25.0000', '25% moms', 1, 0, 1, 0, '') ;

#
# End of data contents of table `wp_woocommerce_tax_rates`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

